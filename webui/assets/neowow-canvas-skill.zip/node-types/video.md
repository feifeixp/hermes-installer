# 节点类型：`video`（视频生成）

节点对象仓库版 api 契约文档（发布包不含），提交→轮询仓库版 api 契约文档（发布包不含），尺寸仓库版 api 契约文档（发布包不含）。

- **`type`**：`video` ｜ **输入 handle**：`image` ⚠️（字面是 image，接受视频） ｜ **输出 handle**：`video`
- **`data` 默认值**：
  ```json
  { "model":"", "modelName":"", "generationType":"TEXT_TO_VIDEO",
    "duration":"5", "aspectRatio":"16:9", "resolution":"1080p",
    "inputVideoUrls":[], "result":null }
  ```

> 生成参数的**真源在 `data` 顶层**：`prompt` / `aspectRatio` / `resolution` / `duration` / `generationType` / `model` / `modelName`（全能模式为 `universal*` 系列，视频延长为 `extend*`，视频编辑为 `editing*`）等直接挂在 `data` 上；历史 `data.params` 是前端不读的死键，勿写。CLI 的 `-s/--set` 与 `-u/--update` 都写顶层（[commands/node.md](../commands/node.md)）。

**模式 tab 由 `data.imageUploadMode` 决定**：`firstLastFrame`（首尾帧/文生视频，缺省）| `multiReference` | `universal` | `extend`（视频延长）| `editing`（视频编辑）| `motionControl`。每个 tab 各有一套设置键与**各自的手动引用键**（互不可见）：

| tab | 模型/设置键 | 手动引用键 | 输出选项键 |
| --- | --- | --- | --- |
| 首尾帧/多图参考 | `model`/`modelName`/`generationType`/`resolution`/`aspectRatio`/`duration` | `manualReferences` | `outputFormat`/`bitrateMode` |
| 全能参考 | `universalModel`/`universalResolution`/`universalAspectRatio`/`universalDuration` | `manualReferences` | `outputFormat`/`bitrateMode` |
| 视频延长 | `extendModel`/`extendResolution`/`extendAspectRatio`/`extendDuration` | `extendManualReferences` | `extendOutputFormat`/`extendBitrateMode` |
| 视频编辑 | `editingModel`/`editingResolution`/`editingAspectRatio` | `editingManualReferences` | `editingOutputFormat`/`editingBitrateMode` |

连线派生的 `connectedImageUrls/connectedVideoUrls/connectedAudioUrls` 五个 tab 共用（画布连线增删整体重算，勿手写）。

## 生成（提交字段）

`POST /agent/story-canvas/generate-video`，基础字段 `nodeKey/sessionId/modelName/prompt/aspectRatio/resolution/duration`，按模式追加顶层扁平参考字段 `imageUrls/referenceVideoUrls/audioUrl`（universal，⚠️ 不是嵌套 `references`）或 `imageUrls`（multiReference）或首尾帧 `firstFrameImageUrl/lastFrameImageUrl`（此模式不发 `imageUrls`）。

- 字段是 **`generationType`**（非 `modeType`）：`TEXT_TO_VIDEO | IMAGE_TO_VIDEO | REFERENCE_TO_VIDEO | UNIVERSAL_TO_VIDEO | VIDEO_EXTEND（视频延长，以模型配置为准，兜底 EXTEND_TO_VIDEO）| VIDEO_TO_VIDEO（视频编辑）`。延长/编辑与 universal 同用顶层扁平 `imageUrls/referenceVideoUrls/audioUrl`；编辑模式 `referenceVideoUrls[0]` 即待编辑视频、无 `videoReferType/totalDuration`。
- `generateAudio` 按模型 `supportAudio` 三态：`2`=恒 `true` / `1`=开关 / `0` 或未知=不带字段（universal 恒 `true`）；`audioUrl` 可选。
- **草稿（样片）**：`draft:true` 是草稿开关（仅普通模式、模型 `supportDraft`；CLI `--draft`），或直接选样片模型（`value` 以 `-draft` 结尾，不用传 `draft`）。结果节点写 **`data.draft:true`**（左上角「草稿」角标、工具栏「转正式」），生成完成以后端 `videoRef.draft` 校准；开关状态持久化在 `data.enableDraft`。转正式（`neowow gen formal`）会在右侧新建 video 节点：`draft:false` + `sourceNodeId`（草稿节点）+ `draftSourceTaskId`（草稿 taskId），并连线草稿 → 新节点。
- 模型与各 `generationType` 下可用 `resolution` 来自级联模型发现（`requestType='2'`），见 [model-schema/schema.md](../model-schema/schema.md)。

完整 body（含五种模式分支与输出格式/码率白名单）仓库版 api 契约文档（发布包不含）。动作模仿走单独的 `…/motion-control`。

## 结果

轮询到 `SUCCESS`，`resultData`（视频 URL 数组）回填到 **`data.inputVideoUrls`**。`data.result.videoUrl` 仅显示用旧字段。拿到视频宽高（封面 `naturalWidth/Height` 或 `videoWidth/videoHeight`）后按尺寸公式重算 `measured`。

## 素材来源

- **本地上传视频**：传 OSS 后创建 `data.type='upload'` 的 video 节点，URL 落 `data.inputVideoUrls`，仓库版 api 契约文档（发布包不含）。
- **连入参考**：video 作为目标的反向规则上游：`text`、`audio`、`uploadImage`、`uploadVideo`。video 作为源的正向规则可连到 `text/image/imageLayerEdit/video/videoComposition/sceneComposer/worldModel`（仓库版 api 契约文档（发布包不含））。
