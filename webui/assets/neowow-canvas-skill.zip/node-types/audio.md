# 节点类型：`audio`（语音 / 音乐生成）

节点对象仓库版 api 契约文档（发布包不含），提交→轮询仓库版 api 契约文档（发布包不含），尺寸仓库版 api 契约文档（发布包不含）。

- **`type`**：`audio` ｜ **输入 handle**：`prompt` ｜ **输出 handle**：`audio`
- **`data` 默认值**：
  ```json
  { "prompt":"", "soundId":null, "rate":1.0, "volume":1.0, "pitch":0,
    "emotion":"neutral", "tone":[], "inputAudioUrls":[], "result":null }
  ```

> 生成参数的**真源在 `data` 顶层**（历史 `data.params` 是前端不读的死键，勿写）。CLI 的 `-s/--set` 与 `-u/--update` 都写顶层（[commands/node.md](../commands/node.md)）。

## 状态词与面板持久化键（与 image/video 不同！）

- **状态词表**（`AudioGenerationNode.vue` 的 `isGenerating`/`isFailed` 只认这些词，语音/音乐共用）：生成中 **`status:'running'`**（配 `generationStartTime`，写 `PENDING` 不会显示生成动画）→ 成功 **`'SUCCESS'`**（清 `taskId`）/ 失败 **`'error'`**（小写！），与 image/video 的 `PENDING → SUCCESS/FAILED` 词表**不同**。
- **音乐面板键**：`musicPrompt` / `musicLyrics` / `instrumental`，tab 由 `audioMode`（`'voice' | 'music'`）恢复——音乐参数写 `prompt` 会污染语音 tab 的朗读框。
- **语音双引擎键**：`voiceModel` ∈ `'minimax' | 'seed-audio-1.0'`。minimax（v1）持久化 `prompt/soundId/rate/volume/pitch/emotion/tone`；seed-audio（v2）持久化 `seedAudioPrompt` + `seedAudioConfig`（`format ∈ wav|mp3|pcm|ogg_opus`、`sampleRate ∈ 8000…48000 六档枚举`、`speechRate/loudnessRate ∈ [-50,100]`、`pitchRate ∈ [-12,12]`，缺省 `wav/24000/0/0/0`）。
- **seed-audio 参考素材**：参考音频 = `connectedAudioUrls`（连线）＋`manualReferences`（手动，≤3 合计）；参考图（1 张）只有手动来源。**音频与图互斥**（SeedAudioPanel `hasConflict` / CLI 提交前拦截）。计费：130 积分/分钟、封顶 120 秒，`gen audio --dry-run` 返回 `estimate` 预估，详见 [commands/gen.md](../commands/gen.md)。

## 两种子模式

### 语音（VOICE）

`POST /agent/story-canvas/generate-audio`：
```json
{ "nodeKey","sessionId","type":"VOICE","soundId":"<音色id>","text":"...",
  "rate":"1.0","pitch":0,"volume":"1.0","emotion":"neutral","tone":[] }
```
`emotion ∈ happy|sad|angry|fearful|disgusted|surprised|neutral`。异步，取 `result.taskId` 轮询。

### 音乐（MUSIC）

`POST /agent/story-canvas/generate-music`：
```json
{ "nodeKey","sessionId","instrumental":false,"lyrics":"","audioUrl":"","prompt":"<曲风>" }
```
异步，取 `result.taskId` 轮询。

### 歌词（同步辅助）

`POST /agent/story-canvas/generate-lyrics { sessionId, prompt, lyrics:"", title:"" }` —— **同步**返回 `{ taskCode, songTitle, styleTags, lyrics }`，可先生成歌词再喂给音乐生成。

## 结果

轮询到 `SUCCESS`，`result.resultData?.audioUrl || result.resultData` 回填到 **`data.inputAudioUrls`**。

## 尺寸特例

audio 节点尺寸读取优先 `node.style.width`；**音频加载后前端会强制把节点压成高 120**（`updateMeasuredForAudio`，由 `onAudioLoaded` 触发，同时写 `style.height` 与 `measured.height`，非手动拖拽）。建节点给默认 `measured:{280,280}` 即可；若要固定宽写 `style.width` + `measured.width`，高度别自定义（仓库版 api 契约文档（发布包不含））。

## 素材来源 / 连线

- **本地上传音频**：传 OSS 后创建 `data.type='upload'` 的 audio 节点，URL 落 `data.inputAudioUrls`，仓库版 api 契约文档（发布包不含）（也可作音乐生成的参考曲 `audioUrl`）。
- **连线**：audio 作为目标**只接受 audio 上游**（反向规则 `audio:['audio']`）。作为源可连 `text/video/videoComposition/audio`（仓库版 api 契约文档（发布包不含））。
- **seed-audio 参考图**：正因入线仅限 audio，参考图**无法靠连线获得**——一律走手动引用（CLI `gen audio --ref-image <url>` 或网页端素材库），落 `data.manualReferences`。
