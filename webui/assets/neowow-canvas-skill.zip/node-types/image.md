# 节点类型：`image`（图片生成）

节点对象/创建仓库版 api 契约文档（发布包不含），提交→轮询仓库版 api 契约文档（发布包不含），尺寸仓库版 api 契约文档（发布包不含）。

- **`type`**：`image` ｜ **输入 handle**：`image` ｜ **输出 handle**：`image`
- **`data` 默认值**（`nodeFactory.js`）：
  ```json
  { "model":"", "modelName":"", "style":"", "negativePrompt":"", "inputImageUrls":[], "result":null }
  ```

> 生成参数的**真源在 `data` 顶层**：`prompt` / `aspectRatio` / `batchSize`（数字）/ `resolution` / `model` / `modelName` 等直接挂在 `data` 上（前端 watch 的就是这些顶层键）；历史 `data.params` 是前端不读的死键，勿写。CLI 的 `-s/--set` 与 `-u/--update` 都写顶层（[commands/node.md](../commands/node.md)）。

## 生成（提交字段）

`POST /agent/story-canvas/generate-image`，关键字段：

| 字段 | 说明 | 来源/合法值 |
| --- | --- | --- |
| `nodeKey` | 本节点 id | 节点 id |
| `sessionId` | 所在画布 | 仓库版 api 契约文档（发布包不含） |
| `prompt` | 提示词 | 文本 |
| `modelName` | 模型 | 模型发现 `model_name`，见 [model-schema/schema.md](../model-schema/schema.md) |
| `numImages` | 出图数（**字符串**） | `image_count_options:[min,max]` 内，如 `"1"` |
| `aspectRatio` | 长宽比 | `supported_aspect_ratios`，含 `'auto'` |
| `size` | 分辨率档 | `supported_sizes`，如 `"2K"` |
| `imageUrls` | 参考图（可选） | 上游 image/上传 URL 数组 |
| `transparentBackground` | 透明背景开关（仅 `gpt-image-2.5` 系列白名单模型恒带，其余不带） | 节点 `data.transparentBackground`（设置栏「透明」开关的持久化状态，默认 `false`）；CLI `--transparent` / `--no-transparent` |

完整 body 与可选项仓库版 api 契约文档（发布包不含）。

## 结果

轮询 `batch-query-status` 到 `SUCCESS`，`resultData`（URL 数组）回填到本节点 **`data.inputImageUrls`**。拿到首张图的宽高后，按 仓库版 api 契约文档（发布包不含） 重算 `measured`（短边 280、长边按比例）。

## 素材来源

- **本地上传图片**：传 OSS 后会创建一个 `data.type='upload'` 的 image 节点，URL 落 `data.inputImageUrls`，仓库版 api 契约文档（发布包不含）。
- **连入参考图**：可作为 image 输入上游的类型（反向规则）：`text`、`video`、`uploadImage`、`uploadVideo`（仓库版 api 契约文档（发布包不含））。
