# 画布节点类型

节点对象与 `batch-operation` 仓库版 api 契约文档（发布包不含）；handle/连线仓库版 api 契约文档（发布包不含）；尺寸仓库版 api 契约文档（发布包不含）。

> **用 CLI 时不必手搓这些**：建/改节点走 `neowow node create -t <type> …` / `neowow node update <nodeKey> …`（见 [commands/node.md](../commands/node.md)）。CLI 已自动：① 按短边 280 + 长宽比写 `measured`（只发 `measured`、**不发** `data._initialMeasured`——前端保存时会剥掉该键，画布加载时由 `measured` 重建，仓库版 api 契约文档（发布包不含））；② 把增删改组装成 `batch-operation` 的 `actions[]`。本页与各专页是**节点 `data` 字段的参考真源**——`-s/--set` 与 `-u/--update` **都写 `data.*` 顶层**（支持 `a.b=1` 深路径；生成参数真源就在顶层，如 `data.prompt`/`aspectRatio`/`batchSize`/`resolution`），共用拒写表：`params`/`params.*`（前端不读的死键）、`label`/`name`（用 `--name`）、运行期字段 `_initialMeasured`/`taskId`/`status`/`isGenerating`/`uploadProgress`/`uploadError`/`type`（确需覆写走 `--data '<json>'`）。合法键名以此为准。

## 类型枚举与 handle 一览

`serialization.js:7`（合法 `type`）、`nodeFactory.js:21-245`。

| `type` | 用途 | 输入 handle | 输出 handle | data.type | 专页 |
| --- | --- | --- | --- | --- | --- |
| `mediaInput` | 外部媒体输入（工厂存在，但上传链路不用它） | （无） | `media` | input | 上传见 upload.md |
| `text` | 文本/提示词生成 | `prompt` | `text` | text | [text.md](./text.md) |
| `image` | 图片生成 | `image` | `image` | generation | [image.md](./image.md) |
| `video` | 视频生成 | `image` ⚠️ | `video` | generation | [video.md](./video.md) |
| `audio` | 语音/音乐生成 | `prompt` | `audio` | generation | [audio.md](./audio.md) |
| `comment` | 批注便签 | （无） | （无） | comment | — |
| `videoComposition` | 视频合成 | `media` | `video` | composition | — |
| `sceneComposer` | 导演台（3D 场景/相机） | `media` | `image` | sceneComposer | — |
| `worldModel` | 世界模型/全景 | `media` | `image` | worldModel | — |
| `group` | 分组容器 | — | — | — | — |

> ⚠️ `video` 的**输入** handle 字面叫 `image` 但接受视频；video→video 边是 `sourceHandle:'video'` + `targetHandle:'image'`（仓库版 api 契约文档（发布包不含））。
>
> 枚举差异提醒：`nodeFactory` 内置 `worldModel`、无 `group`（group 由分组操作创建）；`serialization` 的合法表含 `group`。以本表为准。

## 通用约定

- 每个节点 `id` 自生成 uuid v4，**该 id 即生成请求里的 `nodeKey`**。
- `data` 里既放参数（生成前），也被回填结果 URL（生成后到 `inputImageUrls/inputVideoUrls/inputAudioUrls`）。
- **上传本地素材**：传 OSS 后创建的是 `image`/`video`/`audio` 节点并打 `data.type='upload'`（URL 同样落 `inputImageUrls/...`），**不是** `mediaInput`。仓库版 api 契约文档（发布包不含）。
- **引用素材两来源，生成时合并参与提交**：连线派生 `connectedImageUrls`/`connectedVideoUrls`/`connectedAudioUrls`/`inputTexts`（由 `edge` 命令维护，**不要手写**）+ 手动引用 `manualReferences: [{type:'image'|'video'|'audio', url, name}]`（网页端参考区/CLI `--ref*` 维护，已连线的 URL 不重复写入）。合并/回填语义见 [commands/gen.md](../commands/gen.md) 的「引用素材」一节。
- **尺寸统一仓库版 api 契约文档（发布包不含）**（短边 280、长边按媒体比例；`measured` 是唯一要写的尺寸字段，`_initialMeasured` 不发送、由画布加载时重建）——本目录各专页不重复尺寸细节。
