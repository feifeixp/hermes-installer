# 节点类型：`text`（文本 / 提示词）

节点对象仓库版 api 契约文档（发布包不含），尺寸仓库版 api 契约文档（发布包不含）。

- **`type`**：`text` ｜ **输入 handle**：`prompt` ｜ **输出 handle**：`text`
- **`data` 默认值**：
  ```json
  { "model":"gemini", "maxTokens":2048, "temperature":0.7, "systemPrompt":"", "result":"" }
  ```

## 用途

文本节点常作为图片/视频/音频生成的提示词来源（正向规则 `text → text/image/imageLayerEdit/video/audio`，仓库版 api 契约文档（发布包不含））。把 text 节点连到 image/video/audio 节点的输入 handle（`image`/`image`/`prompt`），其文本即作为下游提示词上游。

## 生成（跑 LLM）

真实端点：`POST /agent/story-canvas/generate-text`（前端 `src/api/textGeneration.js`，`TextGenerationNode` 在用）。异步，返回 `taskId` 走统一 `batch-query-status` 轮询。

CLI：`neowow gen text --node <nodeKey> --prompt "..."`：

- `--type`：生成类型，默认 `STORY_DESCRIPTION`；
- `--ref <图片URL>`（可重复）→ `imageUrls`；`--ref-video <视频URL>`（可重复，**≤5**）→ `videoUrls`；`--audio-url <音频URL>` → `audioUrl`；可选 `--model-config-id` → `textModelConfigId`；
- 提交即回填 `data.prompt` + `status:'PENDING'` + `isGenerating:true` + `taskId`；`--wait` 轮询到终态后回填 **`data.result`**（多段结果以空行连接）+ `status`（`SUCCESS`/`FAILED`）+ `isGenerating:false`（清 `taskId`）。

## 尺寸

无媒体，默认 `measured:{ width:280, height:280 }`（仓库版 api 契约文档（发布包不含））。文本较长时长边可按内容增高，但建/改时给默认 280×280 即可，渲染会自适应。
