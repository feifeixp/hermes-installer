# NeoWoW 画布 CLI Skill（neowow-canvas）

本包 = Claude Code / Codex 的 skill 手册（`SKILL.md` + `commands/` 等文档）+ 零依赖 `neowow` CLI（`bin/neowow.mjs`，Node ≥18）。用命令行完整驱动 NeoWoW 画布：项目 / 节点 / 连线 / 上传 / 图片·视频·音频生成。

## Agent 安装步骤（用户把本 zip 交给你安装时，照此执行）

> 适用于运行在用户本机的 agent（Claude Code / Codex CLI 等）。

1. 下载 zip 并解压到**临时目录**（保持目录结构，本文件应位于解压根目录）。
2. 运行包内安装脚本，落位 + 装命令一步完成：
   ```bash
   bash <解压目录>/scripts/setup.sh            # 装给 Claude Code（~/.claude/skills/neowow-canvas）
   # 可选：--codex 装给 Codex / --all 两者 / --project 装进当前项目 .claude/skills
   ```
   Windows：`powershell -ExecutionPolicy Bypass -File <解压目录>\scripts\setup.ps1`（仅落位；CLI 用 `node <skill>\bin\neowow.mjs` 调用）。
3. 验证：`~/.neowow/bin/neowow --help`（用户新开终端后可直接 `neowow --help`）。
4. 引导用户登录（API Key，用户在网页端「用户中心 → CLI」生成后粘回）：
   ```bash
   neowow login --api-key "<用户粘回的 Key>"   # 在线验证并落盘 ~/.neowow/config.json
   neowow whoami                     # 有用户信息即成功
   ```
5. 之后一切画布操作按 [SKILL.md](./SKILL.md) 使用 `neowow` CLI 完成。提醒用户：Claude Code 若是首次新建 skills 目录，需重启一次才会发现本 skill。

## 人类安装（一行，含 SHA-256 完整性校验）

```bash
curl -fsSL https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | bash
```

Windows / 更多方式（Codex、项目级、离线）见 [scripts/install.md](./scripts/install.md)。

## 快速上手

见 [SKILL.md](./SKILL.md)「30 秒上手」与 [examples/](./examples/)。
