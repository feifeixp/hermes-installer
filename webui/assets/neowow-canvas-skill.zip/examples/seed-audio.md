# SeedAudio：把画布模板用到 CLI

适用于纯文本声音场景、单人参考配音、双人对谈与剧情音频。完整参数见 [gen audio](../commands/gen.md)。以下写法提炼自仓库 `src/components/workflow/nodes/audio/seedAudioTemplates.js` 的 11 个模板（4 个参考音频、7 个纯文本），输出配置与 `SeedAudioPanel.vue` 对齐。模板是提示词示范，不保证模型准确执行所有角色、音效或时间安排。

## 1. 根据任务选择写法

| 任务 | 项目中的模板 | 迁移到 CLI 的要点 |
| --- | --- | --- |
| 单人叙述 | 李米的回忆 | 一条参考音频 + 声线、克制情绪、台词；模板 `speechRate:-10` |
| 双人对谈 | 播客聊天、带货双人 | 两条参考音频 + 角色分行、轮流说话；模板语速分别为 `10`、`20` |
| 纯文本对谈 | 双人播客对谈 | 无参考，分别描述两人的声线与说话方式；模板语速 `10` |
| 剧情场景 | 警局对峙、悬疑刑侦片、宫廷试药、未来科幻片 | 环境声 → 角色台词 → 声音变化，明确声音出现顺序 |
| 密集多角色 | 灵山宣战 | 可借鉴声线区分；长段难控制时按剧情段落拆分，沿用角色描述与参考素材 |
| 快节奏表达 | 古装喜剧片、电商直播带货 | 台词动作与节奏配合；模板语速分别为 `15`、`25` |

这些语速值是模板起点，不是场景固定要求。参考音频上限 3 条不等于最多 3 个文本角色。纯音乐需求使用 `gen music --instrumental`。

## 2. 提示词结构与参数分工

可按「环境声音 → 角色（声线、情绪、说话方式）→ 台词 → 下一声音事件」组织 `--text`。只保留想听到的内容；不产生声音的镜头、服装或肢体描写通常可以省略。对白用引号区分，角色分行，名称前后一致。

- **文本控制表演**：如“声音低沉，压低声音，迟疑片刻后回答”。Seed 的情绪写入文本，不用 MiniMax 的 `--emotion`。
- **参数控制整段输出**：`--speech-rate` / `--loudness-rate` / `--pitch-rate` 是全局设置，不能分别指定两位角色的数值。角色间差异放在文本中表达，效果需试听。
- **纯配音与场景音频按需求区分**：要干净配音可写“仅对白，无背景音乐与环境音”；需要场景音频再加入可辨识的环境声，避免背景声遮住台词。
- **计费预估读取整段文本**：`--dry-run` 会把角色说明、声音描述等一起纳入当前估算；`billedSeconds` 是估算计费秒数，不是精确成片时长。`gen audio` 没有用于指定 Seed 成片长度的已实现参数。

## 3. 纯文本双人对谈

前置：已登录，`SEED_PROJECT` / `SEED_NODE` 替换为真实项目和 audio 节点 id。后续参考素材示例沿用这两个变量；需要保留各次结果时，每个场景使用单独节点。创建节点见 [node.md](../commands/node.md)。写画布前遵循 [技能入口](../SKILL.md) 的并发约束。

```bash
SEED_PROJECT='替换为真实sessionId'
SEED_NODE='替换为真实audio节点id'
SEED_TEXT=$(cat <<'EOF'
仅对白，无背景音乐与环境音，两人轮流说话。
主持人（青年女性，嗓音亲切自然，带着好奇）问：“你是从什么时候开始，觉得这件事值得一直做下去的？”
嘉宾（青年男性，声音沉稳，略作停顿）答：“第一次有人告诉我，我的节目陪他度过了一段困难的日子。”
EOF
)
neowow gen audio -p "$SEED_PROJECT" --node "$SEED_NODE" \
  --engine seed --refs-only --text "$SEED_TEXT" \
  --format wav --sample-rate 24000 \
  --speech-rate 10 --loudness-rate 0 --pitch-rate 0 --dry-run
```

核对返回的 `body`、`refs`、`estimate` 后，按已有生成授权将 `--dry-run` 替换为 `--wait` 执行。上述引用为空时，`--refs-only` 保证本次纯文本生成不会悄悄带上节点旧素材。

带引号的 `<<'EOF'` 保留换行，并让正文中的 `$`、反引号保持字面文本。CLI 当前没有 `--text-file`，长文可先保存为 UTF-8 文件，再用 `--text "$(cat ./scene.txt)"`；不要把正文拼接成 shell 代码执行。

## 4. 单人参考与双人参考

单人参考：先用 `neowow upload ./voice.wav` 上传本地样本，取返回 `.url` 填入 `SEED_VOICE_URL`。只传本地文件路径到 `--ref-audio` 无效。

```bash
SEED_VOICE_URL='https://example.com/voice.wav'
neowow gen audio -p "$SEED_PROJECT" --node "$SEED_NODE" \
  --engine seed --refs-only --ref-audio "$SEED_VOICE_URL" \
  --text '沿用参考音频的音色。旁白情绪克制、语速稍慢，轻声说道：“那年夏天很长，我总以为，明天他还会来。”仅人声，无背景音乐。' \
  --format wav --sample-rate 24000 \
  --speech-rate -10 --loudness-rate 0 --pitch-rate 0 --dry-run
```

双人参考：分别传两条真实音频 URL，再用文字说明角色与素材的对应关系。要使用与画布 `@` 相同的表达，标签应是 `@[URL 最后一个路径段去掉最后一个扩展名]`，例如 `https://example.com/host.wav?token=…` 对应 `@[host]`。这是项目 `src/utils/mentionRef.js` 的序列化规则；素材显示名“主持人”不是实际序列化 id。CLI 原样传递文本，不会替你把 `@主持人` 改写为素材 id，也不会从文字标签自动附加参考 URL。

```bash
# URL 为占位；替换时同步替换正文中的 @[host] / @[guest] 标签。
SEED_HOST_URL='https://example.com/host.wav'
SEED_GUEST_URL='https://example.com/guest.wav'
SEED_DIALOGUE=$(cat <<'EOF'
主持人使用参考音频 @[host] 的音色，嘉宾使用参考音频 @[guest] 的音色。仅对白，两人轮流说话。
主持人（带着好奇，语气轻松）问：“为什么越忙，有时候反而越焦虑？”
嘉宾（沉稳，停顿一下）答：“因为我们常常把忙当成了进步。停下来想清楚，也是在往前走。”
EOF
)
neowow gen audio -p "$SEED_PROJECT" --node "$SEED_NODE" \
  --engine seed --refs-only \
  --ref-audio "$SEED_HOST_URL" --ref-audio "$SEED_GUEST_URL" \
  --text "$SEED_DIALOGUE" --format wav --sample-rate 24000 \
  --speech-rate 10 --loudness-rate 0 --pitch-rate 0 --dry-run
```

`--refs-only` 让本次参考集合和传参顺序明确；通过 `body.audioUrls` 确认实际提交素材。上述角色映射是提示词指令，不是接口提供的强制声轨绑定。需要独立角色音轨时，分别建 audio 节点生成。

## 5. 迁移画布模板时核对的字段

| 模板字段 | CLI 对应 | 说明 |
| --- | --- | --- |
| `payload.text` | `--text` | 保留角色、换行、情绪与声音描述 |
| `payload.audioConfig` | 五项输出配置 flag | 模板只填部分参数时，显式补齐期望值；画布套模板是部分覆盖，CLI 不继承节点配置 |
| `payload.referenceAudios[].url` | 重复 `--ref-audio` | 最多 3 条，不能同时带参考图 |
| `payload.referenceImage` | `--ref-image` | 最多 1 张；描述希望生成的声音，不代表图片包含可克隆的真实声线 |
| `referenceAudios[].name` | 正文角色描述 | CLI 没有参考素材命名 flag，名字不会作为独立字段提交给生成接口 |
| `previewAudio` / `cover` | 不作为生成输入 | 试听成品与卡片封面；尤其不能把纯文本模板的试听成品误当参考音频 |

当前没有 `--template` 命令；按上述字段迁移，不把模板 id 当作模型名。示例素材应换成当前任务选定的素材，无需自动下载或重用模板的试听成品。

复现时显式传 `--engine seed`、`--text` 及五项输出配置；不传配置时 CLI 依赖服务端默认值，可能与画布旧配置不同。`--refs-only` 只控制本次提交，回填仍追加手动引用，**不会清除旧参考或断开连线**。从参考音频切换到参考图片时，优先用新节点；复用节点则先清理不再使用的引用，避免回到画布后出现冲突。
