# 排错手册（CLI 视角）

出错时先看 stderr 的 `[neowow]` 行：`<message> | errCode=<码> | http=<状态>`。按下表对症；
成功的 stdout 永远是单行 JSON。开 `NEOWOW_DEBUG=1` 可在 stderr 看到每个请求的 method/path/body（凭据已脱敏）。

**退出码分级**（agent 据此决定要不要重试）：

| exit | 含义 | 该怎么办 |
| --- | --- | --- |
| 0 | 成功（⚠️ 含 `gen --wait` 任务 FAILED——判成败看 stdout 的 `status`/`phase`） | 解析 stdout |
| 2 | 用法/输入错误（缺参、漏值、未知 flag、非法 URL、未绑定项目、节点/任务不存在） | 改命令重跑，别原样重试 |
| 3 | 未登录 / token 失效（errCode 2001，**含 `--wait`/`poll` 轮询中途 token 过期**） | `neowow login` 后重跑（长视频 `--wait` 时 token 中途失效会立即以 3 上抛，不再盲重试 2 分钟） |
| 4 | 轮询超时/查询失败（任务**仍在后端跑**，仅网络/网关等瞬时故障） | 稍后 `neowow poll <taskId> --apply` 续查 |
| 1 | 其余错误（业务拒绝、网络、后端 5xx…） | 按 errCode 对症 |

## 错误码速查

| errCode | 含义 | 处理 |
| --- | --- | --- |
| `2001` | 未登录 / API Key 无效（网页端重新生成过 Key 会使旧 Key 立即失效） | 网页端「用户中心 → CLI」生成 Key → `neowow login --api-key <key>`，再重跑 |
| `2010` | 账号未激活 | 到网页端完成激活流程 |
| `3014` | 积分不足 | 充值，或降低出图数/分辨率/时长 |
| `4010` | 画布会话不存在 | sessionId 打错或已删除：`neowow project list` 核对后重新 `project use` |
| `5002` | 服务维护中 | 退避后重试（GET 类 CLI 已自动重试 2 次） |
| `CANVAS_NODE_TASK_IN_PROGRESS` | 该节点已有生成任务在跑 | `neowow node get <nodeKey>` 拿 `data.taskId`，`poll <taskId> --apply` 等它终态，或换节点 |
| `SESSION_NOT_BOUND` | CLI 本地错：没给 sessionId 也没绑定 | `-p <sessionId>` 或先 `neowow project use <sessionId>` |
| `NODE_NOT_FOUND` | CLI 本地错：会话里找不到该节点 | `neowow node list` 核对 nodeKey |
| `TASK_NOT_FOUND` | 轮询的 taskId 不存在/已失效 | 核对 taskId（提交时 stderr 有 `已提交 taskId=…`；或 `neowow gen history <nodeKey>` 从节点生成历史里找） |
| `POLL_TIMEOUT` | 轮询到 `--timeout` 仍未终态 | 任务仍在后端跑：错误信息里有现成的 `neowow poll … --apply` 续查命令 |
| `POLL_QUERY_FAILED` | 轮询查询连续 5 次**瞬时**失败（仅网络/网关 5xx/429） | 网络恢复后用 `neowow poll <taskId> --apply` 续查 |
| 登录 `1001` | 无效的 client_id | 用默认 demo client（不带 `--client-id`），或核对自己的 client 注册 |
| 非 JSON 502/503 | 网关发版/维护 | 稍后重试；轮询路径会自动退避重试 |
| `未知参数：--xxx` | flag 拼错 | gen/poll 系直接拒绝执行（防按默认值扣分）；照 `--help` 改正 |

## 生成链路常见问题

- **节点一直停在 `PENDING`/`running`**：提交时没带 `--wait`，也没人做终态回填。跑
  `neowow poll <taskId> --apply`（`--apply` 必带，否则只查不写节点）。
- **`gen --wait` 中途被杀（agent 的 Bash 默认 120s 超时 < 轮询 600s）**：任务没丢——taskId 在提交时的
  stderr 里（`已提交 taskId=…`）、节点 `data.taskId` 里（`neowow node get <nodeKey>`），都找不到就
  `neowow gen history <nodeKey>`（节点历次提交的 taskId/状态/结果都在）。续接：`neowow poll <taskId> --apply`。
  agent 跑长 `--wait` 请调大 Bash 超时或用后台运行。
- **想找回节点的历史生成结果**（节点 `data` 只存最近一次）：`neowow gen history <nodeKey>`，
  历次 `resultData` URL 都能拿到，挑一条 `node update <nodeKey> --data '{"inputImageUrls":[…]}'` 换回去。
- **只想查一次当前状态**：`neowow poll <taskId> --once`（非终态也 exit 0，不阻塞）。
- **生成 FAILED**：`tasks[].errorMessage` 有后端原因；失败回填不会清掉节点上已有的媒体结果。

## batch-operation 逐条核对

整体 200 不代表每个动作都成功——CLI 已自动核对 `results[]` 并在部分失败时报
`batch-operation 部分失败：<objectType>:<objectId> <errorMessage>`；按提示定位到具体节点/边。

## 连线被拒（本地先拦）

后端可能静默丢弃非法边，CLI 建边前先本地校验，报错语义与网页端一致：
`拒绝连接：自环 / 会形成闭环 / <type> 节点无输出口 / <src> → <tgt> 非法`。
确认前端已支持而表滞后时可 `--no-validate` 放行。清单详见 examples/connect-nodes.md。

## 网页端并发覆盖（重要）

**预防**：网页端开着同一画布时不要用 CLI 写（SKILL.md ⚠️）。网页端刷新/关闭会用它内存里的旧快照
全量覆盖后端（update-detail 回放），CLI 写入会被物理删除；同理不要对同一节点并发跑多个 CLI 写操作。

**已经被覆盖了怎么办**：
1. 先停手——让用户关掉网页端画布标签页（不要刷新）。
2. `neowow node get <nodeKey>` / `project get` 确认丢了什么（生成结果 URL 若还在 stdout/日志里可直接找回）。
3. 媒体 URL 都是 OSS 永久链接：重新 `node update <nodeKey> --data '{"inputImageUrls":["<url>"]}'`
   或重连边即可恢复引用；生成任务本身不受影响（taskId 仍可 `poll --apply` 回填）。
