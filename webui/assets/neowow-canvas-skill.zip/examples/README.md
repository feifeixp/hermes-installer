# 示例索引

按场景挑一个直接抄。所有命令以 `neowow`（即 `node <skill>/bin/neowow.mjs`）发起，输出契约见 [../SKILL.md](../SKILL.md)。

## 通用前置条件

各示例默认你已满足下面四条，单篇里不再复述（只列该篇特有的前置）：

1. **已装 `neowow`**（或能用 `node <skill目录>/bin/neowow.mjs`）。安装见 [../scripts/install.md](../scripts/install.md)。
2. **已登录**：网页端「用户中心 → CLI」生成 API Key → `neowow login --api-key "<key>"`（存 `~/.neowow/config.json`）。或 `export NEOWOW_API_KEY=<key>`。见 [../commands/login.md](../commands/login.md)。
3. **已绑定项目**：`neowow project create "<标题>" --use`（或 `neowow project use <sessionId>`），之后 `node`/`edge`/`gen` 自动用当前目录 `.neowow/project.json` 的 `sessionId`；也可每条命令带 `-p <sessionId>`。见 [../commands/project.md](../commands/project.md)。
4. **目标画布没在网页端打开**：网页端开着同一画布时 CLI 写入对它不可见，且网页端刷新会用旧快照全量覆盖后端、物理删除 CLI 写入——操作前确认网页端没开着它，做完再刷新查看。详见 [../SKILL.md](../SKILL.md) 核心模型「并发约束」。

## 全链路示例（CLI）

| 场景 | 文件 |
| --- | --- |
| 登录 → 建项目 → 加图片节点 → 出图（**最小起步，已实测**） | [create-and-run.md](./create-and-run.md) |
| 上传素材 → 建上传节点 → 连线 → 图生视频 | [upload-and-node.md](./upload-and-node.md) |
| 用 Claude Code / Codex 批量生产短剧（分镜图→图生视频→配音的流水线 + 可粘贴导演 prompt） | [short-drama.md](./short-drama.md) |

## 底层参考（HTTP 契约层）

下面几篇是 CLI **之下**的端点级参考——CLI 已封装这些细节，平时按上面的 CLI 示例即可；联调/排错或要看连线规则、错误码、尺寸公式时再查：

| 主题 | 文件 |
| --- | --- |
| 连线 handle id 与合法对（CLI 见 [../commands/edge.md](../commands/edge.md)） | [connect-nodes.md](./connect-nodes.md) |
| 错误码与生成冲突处理 | [errors.md](./errors.md) |
| 节点尺寸 measured 公式与落位（CLI 自动算，见 [../commands/node.md](../commands/node.md)） | [sizing.md](./sizing.md) |
