# 示例：连线（用 handle id + 合法对校验）

边对象/handle/规则仓库版 api 契约文档（发布包不含）。边和节点一样走 `batch-operation`。

## 场景：text 节点 → image 节点（文本作图片提示词上游）

- 源 `text` 的**输出** handle = `text`；目标 `image` 的**输入** handle = `image`。
- 正向规则 `text → [..., image, ...]` ✅ 合法。

```bash
curl -s "$BASE/agent/story-canvas/batch-operation" \
  -H "api-key: $API_KEY" -H 'Content-Type: application/json' \
  -d "{\"sessionId\":\"$SESSION\",\"actions\":[{\"action\":\"create\",\"edges\":[{
        \"id\":\"e-$TEXT_NODE-$IMAGE_NODE\",
        \"source\":\"$TEXT_NODE\",\"target\":\"$IMAGE_NODE\",
        \"sourceHandle\":\"text\",\"targetHandle\":\"image\"
      }]}]}"
```

## 场景：image 节点 → video 节点（图生视频）

- 源 `image` 输出 handle = `image`；目标 `video` 的**输入** handle 字面是 `image`。
- 正向规则 `image → [..., video, ...]` ✅。

```bash
... "edges":[{ "id":"e-$IMG-$VID","source":"$IMG","target":"$VID",
               "sourceHandle":"image","targetHandle":"image" }] ...
```

## ⚠️ 场景：video → video

video 输出 handle = `video`，但 video 输入 handle = `image`：

```json
{ "id":"e-A-B","source":"A","target":"B","sourceHandle":"video","targetHandle":"image" }
```

下游分类媒体时要靠 `sourceHandle==='video'` 识别这是视频而非图片（仓库版 api 契约文档（发布包不含））。

## 删边

```bash
... "actions":[{ "action":"delete","edges":[{ "id":"e-A-B","source":"A","target":"B",
                  "sourceHandle":"video","targetHandle":"image" }] }] ...
```

## 建边前自检清单

1. **handle 名对不对**：查 仓库版 api 契约文档（发布包不含） 表，源用输出 handle、目标用输入 handle。
2. **类型对合法吗**：源类型在目标的正向 allow-list 里（§3）。`audio` 作为目标只接 `audio`。
3. **不成环**：避免 A→B 又 B→A 间接成环（否则 `拒绝连接：会形成闭环`）。
4. **不重复素材**：同一目标不要重复连入相同媒体 URL（否则 `拒绝连接：已存在相同素材的连接`）。
5. **目标不是 upload/converted 节点**（这类无左输入）。
