# 全链路：上传本地素材 → 建上传节点 → 连线 → 图生视频 → 取结果

**覆盖**：`neowow upload <图> --create-node`（直传 OSS + 去重 + 回吐 measured + 直接建上传节点拿 `nodeKey`/`url`）/ `node create -t video` / `edge create`（image→video，handle `image`→`image`，把上游图同步进 target 的 `connectedImageUrls`）/ `models video` / `gen video --wait`（连线图或 `--ref` 触发 `IMAGE_TO_VIDEO`）。给出两种连法：**A) edge 连线后 gen（连线图自动作参考，无须 --ref）**、**B) 直接 gen video --ref `<url>`（不建连线）**。

**前置条件**（附加于 [README.md 的通用前置条件](./README.md) 之上）：已 `neowow login`，且已 `neowow project create "..." --use` 绑定当前目录（之后 `upload --create-node` / `node` / `edge` / `gen` 自动复用这个 sessionId，不传 `-p` 也行）。本地有一张图（如 `./first-frame.png`）。

```bash
# 1) 上传本地图片并直接建一个「上传节点」（data.type='upload'），一步拿到 nodeKey + OSS url
#    --create-node 仅支持 image/video/audio；图片会额外回吐 measured（短边 280、长边按比例）
UP=$(neowow upload ./first-frame.png --create-node --x 200 --y 160)
echo "$UP"
# → {"url":"https://…/<md5>.png","mediaType":"image","dataField":"inputImageUrls",
#    "reused":false,"measured":{"width":498,"height":280},
#    "nodeKey":"<imgUpload-uuid>","sessionId":"2070376818284032000"}
IMG_URL=$(echo "$UP"  | jq -r .url)        # OSS URL，后面 gen 的 --ref 用它
IMG_NODE=$(echo "$UP" | jq -r .nodeKey)    # 上传节点 id（只能作 source，不能作 target）

# 2) 选视频模型：视频取模型对象的 .value（注意图片是 .model_name，视频是 .value）
VMODEL=$(neowow models video | jq -r '.models[0].value')
echo "video model=$VMODEL"

# 3) 建一个 video 生成节点（CLI 自动算 measured；16:9 → {width:498,height:280}）
VID_NODE=$(neowow node create -t video --x 760 --y 160 --aspect 16:9 | jq -r .nodeKey)
echo "vid node=$VID_NODE"

# ── 连法 A：先 edge 连线，gen 自动用连线图（无须再 --ref）────────────────────────
# 4A) image → video：源 image 输出 handle=image；目标 video 的「输入」handle 字面就叫 image
#     ⚠️ source 必须是上传图节点、target 是 video 生成节点（反过来 video 无法作上传节点 target）
#     ⭐ edge create 会把上游上传图的 URL 写进 target 的 data.connectedImageUrls（见输出 connected 字段）
neowow edge create --source "$IMG_NODE" --target "$VID_NODE"
# → {"action":"create","edgeId":"e-<img>-<vid>","source":"<img>","target":"<vid>",
#    "sourceHandle":"image","targetHandle":"image",
#    "connected":{"connectedImageUrls":["https://…png"],"connectedVideoUrls":null,…},"results":[…]}
# 5A) 出视频：连线图已进 connectedImageUrls，gen video 自动拿它作首帧（IMAGE_TO_VIDEO），无须再 --ref
#     （提交前 CLI 还会按当前边现算刷新 connected*，故上游图始终新鲜——见 ../commands/gen.md）
neowow gen video --node "$VID_NODE" --model "$VMODEL" \
  --prompt "镜头缓慢推近，微风拂动" --ar 16:9 --resolution 1080p --duration 5 --wait
# stderr: [gen] 提交视频生成… / [poll] 1 个任务进行中，5s 后重试…
# stdout: {"kind":"video","nodeKey":"<vid>","taskId":"<id>","status":"SUCCESS",
#          "resultData":["https://…mp4"],"dataField":"inputVideoUrls","waited":true}

# ── 连法 B：跳过 edge，直接 gen video --ref <url>（最短路） ─────────────────────
# 5B) 不建可视连线，直接把上传图当首帧丢给生成（首尾帧：第 2 个 --ref 作 lastFrameImageUrl）
neowow gen video --node "$VID_NODE" --model "$VMODEL" \
  --prompt "镜头缓慢推近，微风拂动" --ar 16:9 --resolution 1080p --duration 5 \
  --ref "$IMG_URL" --wait
# stdout 同上：status=SUCCESS，resultData[0] 即视频 URL，已回填 inputVideoUrls

# 6) 取结果 / 校验回填（gen --wait 已把 status/taskId/inputVideoUrls 写回节点 data）
VURL=$(neowow gen video --node "$VID_NODE" --model "$VMODEL" --ref "$IMG_URL" --wait \
        | jq -r '.resultData[0]')   # 或直接复用上一步 stdout 的 resultData[0]
echo "视频地址：$VURL"
neowow node list -t video           # → nodes[].status=SUCCESS
```

**关键点**

- ⚠️ `upload --create-node` 建出的节点 `data.type='upload'`，**无左输入口，不能作连线 target**——`edge create` 把它当 `--target` 会被拒（`拒绝连接：目标节点 <id> 是 upload 节点，无左输入口`，见 [../commands/edge.md](../commands/edge.md)）。它只作 source 往下游供素材。想要一个可被连入的占位图片节点，请改用 `neowow node create -t image`（带左输入口）。
- 两种连法都产出图生视频，区别在参考图从哪来：**A** `edge create` 把上游图同步进 target 的 `connectedImageUrls`，`gen video` 提交前现算刷新后自动用它作首帧（**无须 `--ref`**，画布也能看到连线，便于复盘/协作）；**B** 不建连线，直接用 `--ref` 把 URL 丢进生成请求（脚本最短）。**边并非「只是可视连线」——它会把上游素材 URL 写进 target 的 `connected*`，`gen` 自动取用**（见 [../commands/edge.md](../commands/edge.md) 的 connected 同步、[../commands/gen.md](../commands/gen.md) 的提交前现算）。A 里再给 `--ref` 也可以，会与连线图去重合并、不重复。
- `--ref` 一给，`gen video` 就强制 `generationType=IMAGE_TO_VIDEO`，并把第 1 张作 `firstFrameImageUrl`、第 2 张（若有）作 `lastFrameImageUrl`（首尾帧，需模型支持；此模式**不发送 `imageUrls`**）；多张图作整组参考请改用 `--multi-ref`（`REFERENCE_TO_VIDEO`，全部 ref 走 `imageUrls`）；不给 `--ref` 才是默认 `TEXT_TO_VIDEO`（见 [../commands/gen.md](../commands/gen.md)）。
- 模型机器名取法有别：**图片**填 `neowow models image` 的 `.models[].model_name`；**视频**填 `neowow models video` 的 `.models[].value`。填错会被后端拒。
- `upload` 自带 MD5 去重：第二次传同一文件命中相同 MD5，stderr 打 `[upload] 命中相同 MD5，复用：<url>`、stdout `reused:true`，免传直接复用旧 URL。图片同时回吐 `measured`（视频/音频为 `null`）。
- 尺寸全自动：`upload`（图片）与 `node create`（`--aspect`/`--media-w/-h`）都按短边 280 自动算 `measured` 并落盘，无需手动 `node update` 改尺寸（见 [./sizing.md](./sizing.md)）。
- 没 `project use`、又不带 `-p <sessionId>` 时，`upload --create-node` / `node` / `edge` / `gen` 都会报 `SESSION_NOT_BOUND`；临时指定加 `-p <sessionId>` 即可。

换素材类型：把第 1 步换成 `neowow upload ./clip.mp4 --create-node`（视频）或 `./voice.mp3 --create-node`（音频）拿对应 `dataField`/`url`；换成图生图则第 3~5 步改用 `node create -t image` + `gen image --ref <url>`（参考图）即可（见 [./create-and-run.md](./create-and-run.md)）。

链路回顾：

```
本地图片 ──upload --create-node──▶ OSS url + measured + 上传节点(data.type='upload', nodeKey)
   │                                         （无左输入口，只作 source）
   ├─ A) edge create(image→video) → 上游图进 target.connectedImageUrls ─┐
   │                                                                   ├─▶ gen video --wait
   └─ B) 直接 gen video --ref <url> ────────────────────────────────────┘   （连线图/--ref ⇒ IMAGE_TO_VIDEO，首帧=图）
                                                                          └─▶ status=SUCCESS, resultData[0]=视频URL
                                                                              （已回填节点 inputVideoUrls）
```
