# 全链路：登录 → 建项目 → 加图片节点 → 出图

**覆盖**：`neowow login` / `whoami` / `project create --use` / `models image` / `node create -t image` / `gen image --wait` / 回填校验。

**前置条件**（附加于 [README.md 的通用前置条件](./README.md) 之上）：已装 `neowow`（或用 `node <skill>/bin/neowow.mjs`）。本示例的命令均已在 dev 实测跑通。

```bash
# 1) 登录（API Key，一次即可）：网页端「用户中心 → CLI」生成 Key
neowow login --api-key "<你的 Key>"            # 在线验证并存 ~/.neowow/config.json
neowow whoami                                 # 确认：{"userId":"...","nickname":"...","points":...}

# 2) 建项目并绑定当前目录（之后 node/gen 自动用这个 sessionId）
neowow project create "CLI 测试画布" -d "demo" --use
# → {"action":"create","sessionId":"2070376818284032000","title":"CLI 测试画布","bound":true}

# 3) 选模型：拿 model_name（图片填模型对象的 model_name）
neowow models image | jq -r '.models[] | "\(.model_name)\t\(.model_display_name)\t\(.supported_sizes)"'
# gemini-2.5-flash-image  Neo Nano       ["1K"]      ← 默认分镜模型，无会员门槛，便宜
# gemini-3-pro-image-preview  Neo Nano Pro  ["2K","4K"]

# 4) 建图片节点（CLI 自动写 measured；默认 280x280，给媒体后按比例）
NODE=$(neowow node create -t image --x 320 --y 120 | jq -r .nodeKey)
echo "nodeKey=$NODE"

# 5) 出图：--wait 一条命令跑完 提交→回填PENDING→轮询→回填终态
neowow gen image --node "$NODE" \
  --prompt "赛博朋克猫，霓虹灯，雨夜街头，电影感" \
  --model gemini-2.5-flash-image --ar 16:9 --size 1K --n 1 --wait
# stderr: [gen] 提交图片生成 …   [poll] 1 个任务进行中，5s 后重试…（约 25–30s）
# stdout: {"kind":"image","nodeKey":"...","taskId":"...","status":"SUCCESS",
#          "resultData":["https://...IMG_GEN_...png"],"dataField":"inputImageUrls","waited":true}

# 6) 校验回填：节点状态与结果已写回画布
neowow node list -t image
# → {"...","nodes":[{"nodeKey":"...","type":"image","status":"SUCCESS",...}]}
```

**关键点**

- `--wait` 把"提交→回填→轮询→回填"折成一条命令；省略它则只返回 `{"status":"PENDING","taskId":"..."}`，随后用 `neowow poll <taskId>` 轮询。
- 出图后 CLI 会把 `status/taskId/model/prompt/aspectRatio/batchSize/resolution/inputImageUrls` **回填进节点 `data`**，画布上才看得到提示词、设置与结果——这是必做且已内置，无需你手动 `node update`。
- 模型决定 `--size` / `--ar` 的合法取值：`gemini-2.5-flash-image` 只支持 `1K`，用 `2K` 会被拒；可选模型与可选项见 [../commands/models.md](../commands/models.md) 与 [../model-schema/schema.md](../model-schema/schema.md)。
- 不传 `-p`/未 `project use` 时，`node`/`gen` 会报 `SESSION_NOT_BOUND`；用 `-p <sessionId>` 临时指定或先 `neowow project use`。
