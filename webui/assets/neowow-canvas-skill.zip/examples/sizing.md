# 示例：节点尺寸（横/竖图、视频、text/audio、落位）

规范与公式仓库版 api 契约文档（发布包不含）。核心：**短边钉 280、长边按 `ar=mediaW/mediaH`、无上限**，只需写 `measured`——`data._initialMeasured` 由画布加载时从 measured 重建，wire 上不用带（CLI `node create` 也不发）。

```js
// 照抄
const calcMeasured = (w, h, base = 280) =>
  (!w || !h) ? { width: base, height: base }
  : (w / h > 1) ? { width: Math.round(base * (w / h)), height: base }
                : { width: base, height: Math.round(base / (w / h)) };
```

## 横图 1920×1080（16:9）→ 498×280

```json
{ "id":"<uuid>","type":"image","position":{"x":320,"y":120},
  "measured":{"width":498,"height":280},
  "data":{"type":"generation","inputImageUrls":["<url>"]} }
```

## 竖图 1080×1920（9:16）→ 280×498

```json
{ "measured":{"width":280,"height":498}, "data":{"...":"..."} }
```

## 方图 1024×1024 → 280×280；超宽 2048×858 → 668×280

| 媒体 | measured |
| --- | --- |
| 1024×1024 | `{280,280}` |
| 2048×858 | `{668,280}` |
| 1280×720 | `{498,280}` |
| 720×1280 | `{280,498}` |

## 视频 1280×720 → 498×280

视频取封面 `naturalWidth/Height` 或 `videoWidth/videoHeight` 当 `mediaW/H`，公式同图片。

```json
{ "type":"video","measured":{"width":498,"height":280},
  "data":{"type":"generation","inputVideoUrls":["<videoUrl>"]} }
```

## text / audio（无媒体）→ 280×280

```json
{ "type":"text","measured":{"width":280,"height":280},
  "data":{"type":"text"} }
```

audio 若要指定固定宽，需同时写 `style.width` + `measured` + `dimensions`（仓库版 api 契约文档（发布包不含））。

## 批量落位（避免重叠）

按网格排，列宽 ~320、行按各自 `measured.height + 40` 间距：

```js
let x = 0, y = 0, rowH = 0;
for (const n of nodes) {
  n.position = { x, y };
  x += Math.max(320, n.measured.width + 40);
  rowH = Math.max(rowH, n.measured.height);
  if (x > 1600) { x = 0; y += rowH + 40; rowH = 0; }  // 换行
}
```

媒体类在源节点右侧新建时常用 `position.x = 源.x + 420`（仓库版 api 契约文档（发布包不含））。
