# 全链路：用 Claude Code / Codex 生产短剧（CLI 版）

**覆盖**：`neowow login` / `whoami` / `project create --use` / `models image|video|voice` / `node create -t image|video|audio` / `gen image --wait` / `gen video --ref … --wait`（图生视频）/ **`gen video --universal`（全能参考——生视频默认首选，见第 4 节）** / `gen audio --wait`（VOICE，音色用 `models voice` 自洽）/ 用 `jq` 取 `nodeKey`、`resultData` / shell 数组循环批量跑多分镜 / `set -euo pipefail` + `&&` 保证顺序与失败即停。

**前置条件**（附加于 [README.md 的通用前置条件](./README.md) 之上）：已装 `neowow`（或用 `node <skill>/bin/neowow.mjs`）；已装 `jq`。短剧 = 一个项目（sessionId）下，按分镜成组排布 image/video/audio 节点。**先小后大**：先用下方「单分镜」跑通 token/模型/链路，再用「导演 prompt 循环」批量。

## 流水线（每个分镜一组节点）

```
分镜提示词数组 PROMPTS[]
  └─对每个分镜 i:
       image 节点 ──gen image──▶ 分镜图 url(resultData[0])
            │
            └──gen video --ref <分镜图>──▶ 视频 url（--ref 触发 IMAGE_TO_VIDEO，分镜图作首帧）
       (可选) audio 节点 ──gen audio--▶ 配音 url
  节点按分镜从左到右成列排布；measured 由 node create 自动算（短边 280，--aspect 决定长边）
```

> 当前 skill 覆盖到「逐分镜的图/视频/配音生成」。把多个分镜**合成为一条成片**（`videoComposition` 视频合成节点）暂未文档化——产出后在网页端画布做合成即可。

## 1. 单分镜：先跑通全链路

```bash
# 1) 登录（API Key，一次即可；已登录可跳过）：网页端「用户中心 → CLI」生成 Key
neowow login --api-key "<你的 Key>"                    # 在线验证并存 ~/.neowow/config.json
neowow whoami                                         # → {"userId":"...","nickname":"...","points":...}

# 2) 建项目并绑定当前目录（之后 node/gen/edge 自动用这个 sessionId）
neowow project create "雨夜追逐" -d "CLI 短剧 demo" --use
# → {"action":"create","sessionId":"2070376818284032000","title":"雨夜追逐","bound":true}

# 3) 选模型：图片取 .model_name，视频取 .value（视频顶层 model_name 为 null，别取错）
IMG_MODEL=$(neowow models image | jq -r '.models[0].model_name')   # 如 gemini-2.5-flash-image（仅 1K）
VID_MODEL=$(neowow models video | jq -r '.models[0].value')        # 如 doubao-seedance-1-0-pro-fast-251015
echo "img=$IMG_MODEL video=$VID_MODEL"

# 4) 建 image 节点 → 出分镜图（--wait 一条命令跑完 提交→回填PENDING→轮询→回填终态）
IMG_NODE=$(neowow node create -t image --x 0 --y 0 --aspect 16:9 --name 分镜1 | jq -r .nodeKey)
IMG_URL=$(neowow gen image --node "$IMG_NODE" \
  --prompt "雨夜，霓虹灯下的小巷，男人撑伞快步穿过积水，电影感，16:9" \
  --model "$IMG_MODEL" --ar 16:9 --size 1K --n 1 --wait | jq -r '.resultData[0]')
echo "分镜图=$IMG_URL"
# stdout(gen image): {"kind":"image","nodeKey":"...","status":"SUCCESS","resultData":["https://...png"],"dataField":"inputImageUrls","waited":true}

# 5) 建 video 节点 → 图生视频（--ref <分镜图> 自动转 IMAGE_TO_VIDEO，分镜图作首帧）
VID_NODE=$(neowow node create -t video --x 540 --y 0 --aspect 16:9 --name 分镜1视频 | jq -r .nodeKey)
VID_URL=$(neowow gen video --node "$VID_NODE" --model "$VID_MODEL" \
  --prompt "镜头缓慢推近，雨丝飞溅" --ar 16:9 --resolution 1080p --duration 5 \
  --ref "$IMG_URL" --wait | jq -r '.resultData[0]')
echo "视频=$VID_URL"
# stdout(gen video): {"kind":"video","nodeKey":"...","status":"SUCCESS","resultData":["https://...mp4"],"dataField":"inputVideoUrls","waited":true}

# 6) （可选）连一条 image→video 的边，画布上把分镜图与视频显式接起来
neowow edge create --source "$IMG_NODE" --target "$VID_NODE" \
  --source-handle image --target-handle image

# 7) （可选）建 audio 节点 → 旁白配音（type VOICE）；音色用 models voice 发现，取 .id
SND=$(neowow models voice --sex 1 | jq -r '.voices[0].id')   # 男声第一个；可按 --sex/--language 过滤
AUD_NODE=$(neowow node create -t audio --x 1080 --y 0 --name 分镜1配音 | jq -r .nodeKey)
AUD_URL=$(neowow gen audio --node "$AUD_NODE" --sound "$SND" \
  --text "那一夜，雨没有停。" --emotion sad --rate 1.0 --wait | jq -r '.resultData[0]')
echo "配音=$AUD_URL"
```

## 2. 导演 prompt 循环骨架：分镜数组 → 逐个生成（可直接粘贴）

把每个分镜的「画面提示词」「（可选）旁白」放进并列数组，shell 循环逐个跑全链路。`set -euo pipefail` + `&&` 保证任一步失败立即停、不继续往下糊。每列横向偏移避免重叠（image/video/audio 同分镜纵向成组）。

```bash
# 1) 严格模式：任一命令失败/未定义变量/管道中段失败 → 立即退出，绝不带病往下跑
set -euo pipefail

# 2) 绑定项目（已 project use 过可省）；模型只发现一次，循环里复用
neowow project use "${SID:-2070376818284032000}"
IMG_MODEL=$(neowow models image | jq -r '.models[0].model_name')
VID_MODEL=$(neowow models video | jq -r '.models[0].value')
SOUND_ID=$(neowow models voice --sex 1 | jq -r '.voices[0].id')   # 音色（配音用），取 .id

# 3) 分镜脚本：PROMPTS=画面提示词，VOICES=对应旁白（留空字符串则跳过配音）。两数组等长、按下标对齐
PROMPTS=(
  "雨夜，霓虹灯下的小巷，男人撑伞快步穿过积水，电影感，16:9"
  "巷口拐角，黑衣身影一闪而过，男人停步回望，紧张氛围，16:9"
  "雨幕中两人对峙，特写男人坚毅的眼神，冷色调，电影感，16:9"
)
VOICES=(
  "那一夜，雨没有停。"
  "他知道，有人在跟着他。"
  ""    # 此分镜无旁白 → 跳过配音
)

# 4) 逐分镜：建 image → 出图(取 resultData[0]) → 建 video → 图生视频(--ref 分镜图) → 连线 → 可选配音
#    ⚠️ 默认规则：非用户强行指定，生视频优先第 4 节的全能参考（--universal）；本节首尾帧写法仅当用户点名时用
for i in "${!PROMPTS[@]}"; do
  N=$((i + 1))
  COL_X=$((i * 600))        # 每个分镜往右挪一列，避免节点重叠
  echo "=== 分镜 $N / ${#PROMPTS[@]} ===" >&2

  IMG_NODE=$(neowow node create -t image --x "$COL_X" --y 0 --aspect 16:9 --name "分镜${N}图" | jq -r .nodeKey)
  IMG_URL=$(neowow gen image --node "$IMG_NODE" \
    --prompt "${PROMPTS[$i]}" --model "$IMG_MODEL" --ar 16:9 --size 1K --n 1 --wait \
    | jq -r '.resultData[0]')
  test -n "$IMG_URL" && test "$IMG_URL" != null   # 出图为空就停，别拿空 url 去生视频

  VID_NODE=$(neowow node create -t video --x "$COL_X" --y 360 --aspect 16:9 --name "分镜${N}视频" | jq -r .nodeKey)
  VID_URL=$(neowow gen video --node "$VID_NODE" --model "$VID_MODEL" \
    --prompt "${PROMPTS[$i]}" --ar 16:9 --resolution 1080p --duration 5 --ref "$IMG_URL" --wait \
    | jq -r '.resultData[0]') \
    && neowow edge create --source "$IMG_NODE" --target "$VID_NODE" \
         --source-handle image --target-handle image

  if [ -n "${VOICES[$i]}" ]; then
    AUD_NODE=$(neowow node create -t audio --x "$COL_X" --y 720 --name "分镜${N}配音" | jq -r .nodeKey)
    AUD_URL=$(neowow gen audio --node "$AUD_NODE" --sound "$SOUND_ID" \
      --text "${VOICES[$i]}" --emotion neutral --wait | jq -r '.resultData[0]')
    echo "分镜${N}: 图=$IMG_URL 视频=$VID_URL 配音=$AUD_URL"
  else
    echo "分镜${N}: 图=$IMG_URL 视频=$VID_URL"
  fi
done

echo "全部完成。sessionId=$(neowow project get | jq -r .sessionId)"
```

## 3. 提速变体：先全部提交（不 --wait），再一次性 poll

`--wait` 串行等每个分镜，分镜多时慢。可先对所有分镜 `gen image`（不带 `--wait`，只提交+回填 PENDING、拿 `taskId`），攒一把 `taskId` 后用 `neowow poll` 批量轮询；图都好了再批量提视频。

```bash
set -euo pipefail
declare -a TASK_IDS IMG_NODES
for i in "${!PROMPTS[@]}"; do
  NK=$(neowow node create -t image --x $((i*600)) --y 0 --aspect 16:9 | jq -r .nodeKey)
  TID=$(neowow gen image --node "$NK" --prompt "${PROMPTS[$i]}" \
        --model "$IMG_MODEL" --ar 16:9 --size 1K | jq -r .taskId)   # 不带 --wait → status PENDING
  IMG_NODES+=("$NK"); TASK_IDS+=("$TID")
done
neowow poll "${TASK_IDS[@]}" --apply \
  | jq -r '.tasks[] | "\(.nodeKey)\t\(.status)\t\(.resultData[0] // "")"'   # 默认 5s 间隔 / 600s 超时
# 注意：批量提交不带 --wait 时必须用 poll --apply 补终态回填，否则节点停在 PENDING；
# 图的 url 取 .tasks[].resultData[0]，再喂给 gen video --ref
```

## 4. 全能参考变体：用 universal 模型做多模态分镜视频

**默认规则：非用户强行指定其他模式/模型，生视频一律优先本节的全能参考模式**——把第 2 节的图生视频换成 `--universal`（全能模型如 `neo-video-2-0` / Seedance 2.0），可同时喂图 / 视频 / 音频参考，单张分镜图也照走 `--universal --ref <图>`。与普通 `--ref` 模式三点不同（已实测）：默认 **720p**、参考素材走**顶层扁平字段**（`imageUrls`/`referenceVideoUrls`/`audioUrl`）、回填节点写 `universal*` 字段 + `imageUploadMode:'universal'`（非连线参考另写 `manualReferences`）。带 `--ref-video` 时记得 `--total-duration <参考视频总秒数>`（仅模型 `refVideoBilling=1` 时参与计价，`models video --universal` 每项透出该字段，其余恒 0）。已有视频要接着往后生成用 `gen video --extend`，要改画面用 `gen video --edit`（模型分别来自 `models video --extend|--edit`）。详见 [../commands/gen.md](../commands/gen.md)。

```bash
set -euo pipefail
UV_MODEL=$(neowow models video --universal | jq -r '.models[0].value')   # 全能模型走独立端点，取 .value

for i in "${!PROMPTS[@]}"; do
  N=$((i + 1)); COL_X=$((i * 600))
  # 先出分镜图（同前）
  IMG_NODE=$(neowow node create -t image --x "$COL_X" --y 0 --aspect 16:9 --name "分镜${N}图" | jq -r .nodeKey)
  IMG_URL=$(neowow gen image --node "$IMG_NODE" --prompt "${PROMPTS[$i]}" \
    --model "$IMG_MODEL" --ar 16:9 --size 1K --wait | jq -r '.resultData[0]')

  # 全能参考图生视频：--universal + 分镜图作 --ref（进顶层 imageUrls）；不传 --resolution → 默认 720p
  VID_NODE=$(neowow node create -t video --x "$COL_X" --y 360 --aspect 16:9 --name "分镜${N}全能视频" | jq -r .nodeKey)
  VID_URL=$(neowow gen video --node "$VID_NODE" --universal --model "$UV_MODEL" \
    --prompt "${PROMPTS[$i]}" --ar 16:9 --duration 5 --ref "$IMG_URL" --wait | jq -r '.resultData[0]') \
    && neowow edge create --source "$IMG_NODE" --target "$VID_NODE" --source-handle image --target-handle image
  echo "分镜${N}: 图=$IMG_URL 全能视频=$VID_URL"
done
```

> 全能模式把设置回填到节点的 `universalModel/universalAspectRatio/universalResolution/universalDuration` + `imageUploadMode:'universal'`（而非常规字段），画布上该视频节点即以「全能参考」呈现。全能模型出片较慢（实测 Seedance 2.0 约 5 分钟/条），分镜多时建议配合第 3 节「先提交后 poll」。

**关键点**

- **图生视频靠 `--ref`**：`gen video --ref <分镜图url>` 会强制 `generationType=IMAGE_TO_VIDEO`，第 1 张 ref 作 `firstFrameImageUrl`（首帧）；再给第 2 张 ref 则作 `lastFrameImageUrl`（首尾帧）。没给 `--ref` 才是文生视频。详见 [../commands/gen.md](../commands/gen.md)。
- **生视频默认首选 `--universal` 全能参考**（非用户强行指定不用其他模式）：全能模型（`neo-video-2-0` 等，用 `models video --universal` 发现、取 `.value`）走 `--universal`，参考用 `--ref`/`--ref-video`/`--ref-audio` 进**顶层扁平字段**（`imageUrls`/`referenceVideoUrls`/`audioUrl`，不是嵌套 `references`），**默认 720p**，回填 `universal*` 字段（见第 4 节）。CLI 自动补 `generationType:UNIVERSAL_TO_VIDEO`；带 `--ref-video` 时用 `--total-duration` 传参考视频总秒数（仅 `refVideoBilling=1` 模型参与计价，见 gen.md）。
- **音色用 `models voice`**：`gen audio --sound` 的 soundId 由 `neowow models voice`（可 `--sex`/`--language` 过滤）取每项 `.id`，不必再去网页端找。配音链路还有两个可选升级：`gen audio --engine seed`（seed-audio-1.0，`--ref-audio` 喂参考音频克隆音色、无需 `--sound`），以及 `gen text --node <text节点> --prompt … --wait` 先让 LLM 生成旁白文案再喂给配音（见 [../commands/gen.md](../commands/gen.md)）。
- **Seed 场景配音**：需要双人对谈或对白配环境声时，可把角色声线、情绪、台词与声音先后顺序写进同一个 `--text`，不必一律按角色拆成独立生成。需要逐角色独立剪辑时再拆节点；参考音频最多 3 条，纯文本场景不受这个引用数量限制。写法和完整命令见 [seed-audio.md](./seed-audio.md)，角色一致性与混音效果需生成后试听确认。
- **取值用 `jq`**：`node create` 取 `.nodeKey`，`gen … --wait` 取 `.resultData[0]`（图/视频/音频 url），`poll` 取 `.tasks[].resultData[0]`。成功结果都是 stdout 单行 JSON，可直接 `| jq` / `$(...)`。
- **失败即停**：`set -euo pipefail` 让任一 `neowow`/`jq` 非 0 退出即中断；`&&` 把「出视频成功」与「连线」绑成原子顺序；空 url 用 `test -n` 拦住，避免拿空值去生视频。
- **模型别取错**：图片 `--model` 取 `models image` 的 `.model_name`；视频 `--model` 取 `models video` 的 `.value`（视频顶层 `model_name` 为 null）。模型决定 `--size`/`--ar` 合法值（如 `gemini-2.5-flash-image` 仅 `1K`）。见 [../commands/models.md](../commands/models.md)。
- **measured 自动算**：`node create --aspect 16:9` 即按短边 280 算好渲染尺寸（只发 `measured`，不发 `data._initialMeasured`——画布加载时自动重建），无需手动；横向 `--x` 拉开列距避免重叠。
- **回填是内置的**：`gen … --wait` 成功后 CLI 自动把 `status/taskId/model/prompt/结果url` 写回节点 `data`（image→`inputImageUrls`，video→`inputVideoUrls`，audio→`inputAudioUrls`），画布上才看得到；`poll` 默认只查状态，**带 `--apply` 才回填**——批量「先提交后 poll」的链路终点必须是 `poll … --apply`。
- **作用域**：循环前 `neowow project use <sid>` 绑定一次即可，循环里 `node/edge/gen` 复用 `.neowow/project.json`；未绑定会报 `SESSION_NOT_BOUND`，或对单条命令加 `-p <sessionId>` 临时指定。
- **断点续做**：每分镜的 `nodeKey`/`taskId`/`url` 都打到 stdout，中断后只补未完成分镜即可。错误码（2001 重登录、3014 积分不足、`CANVAS_NODE_TASK_IN_PROGRESS` 等）见 [./errors.md](./errors.md)。

相关链路：登录 [../commands/login.md](../commands/login.md)、项目 [../commands/project.md](../commands/project.md)、节点 [../commands/node.md](../commands/node.md)、连线 [../commands/edge.md](../commands/edge.md)、生成 [../commands/gen.md](../commands/gen.md)、模型 [../commands/models.md](../commands/models.md)；最简全链路见 [./create-and-run.md](./create-and-run.md)。
