---
name: neowow-canvas
description: >-
  NeoWoW 画布（story-canvas）官方命令行 neowow：在命令行里完整驱动画布——登录、项目（会话）、
  节点增删改、连线、素材上传、图片/视频/音频生成（提交→轮询→回填，一条 --wait 跑完）。
  适合用 Claude Code / Codex 批量生成分镜图、图生视频、配音，串成短剧/分镜。
  凡是和 NeoWoW 画布 / 项目 / 节点 / 连线 / 生成 / 短剧 相关的操作，一律用 neowow CLI 完成，
  不要自己捏造 HTTP 请求、也不要绕到网页端。⚠️ 网页端开着同一画布时先别动它——网页端刷新会用旧快照
  全量覆盖后端、物理删除 CLI 写入。本 skill 内即是完整命令手册；常见链路见 examples/，安装见 scripts/install.md。
  (EN: Official CLI "neowow" for the NeoWoW story-canvas — login, projects/sessions, nodes, edges,
  media upload, and image/video/audio generation, driven entirely from the command line.)
---

# NeoWoW 画布 CLI（`neowow`）

面向 Agent CLI 的**命令行**操作手册。画布的全部能力由本仓库自带的零依赖 Node CLI `neowow` 暴露——它把后端 `https://<host>/agent/story-canvas/*`（及 `/user/*`）的真实端点封装成子命令，你只发命令、不拼 HTTP。

> **真源顺序**：本 skill 的 `commands/*.md`（完整选项）＞ `neowow <cmd> --help`（离线速查）。文档与 CLI 实际行为冲突时，**以 CLI 实际输出为准**并回头修文档。仓库版另有实现源码 `lib/*.mjs` 与端点契约 `api/*.md`（发布包不含）。

## 怎么调用

- 入口：**`neowow <command>`**（安装到 PATH 后）。未装 PATH 时用 `node <skill目录>/bin/neowow.mjs <command>`。
- **输出契约**：成功 → stdout **单行 JSON**；进度/告警 → stderr（前缀 `[gen]`/`[poll]`/`[upload]`/`[login]`/`[retry]`/`[warn]`）；**致命错误统一是 stderr 的 `[neowow] <message> | errCode=… | http=…` 一行**，exit 非 0。可直接 `| jq`、`&&` 串联。排错对照 [examples/errors.md](./examples/errors.md)。
- **鉴权**：除 `login` 外都需先登录（API Key 存 `~/.neowow/config.json`，或 `NEOWOW_API_KEY` 环境变量；Key 在网页端「用户中心 → CLI」生成，请求头是字面 `api-key`）。
- **项目作用域**：`node`/`edge`/`gen` 用 `-p/--project <sessionId>`，或当前目录 `.neowow/project.json`（`neowow project use` 绑定）。
- **环境变量**：`NEOWOW_API_KEY` / `NEOWOW_BASE`（默认正式环境 `https://neowow.cn`）/ `NEOWOW_CONFIG_DIR` / `NEOWOW_DEBUG=1`（stderr 打印每个请求的 method/path/body，凭据已脱敏）/ `NEOWOW_NO_UPDATE_CHECK=1`（关新版提醒）。
- **自更新**：CLI 每 24h 自动检查一次新版，有则在 stderr 提醒 `[update] 新版本 … 可用：neowow update 一键更新`——**看到提醒告知用户，经确认执行 `neowow update`**（下载校验换装一条龙，批量任务跑完再更）。详见 [commands/update.md](./commands/update.md)。

## 核心模型（务必先读）

- **项目 = 会话**：一个"项目/画布" == 后端一个 **`sessionId`（字符串）**。没有 `projectUuid`/`canvasId`。`neowow project create` 直接返回 `sessionId`。
- **节点/边没有逐个 CRUD**：`node`/`edge` 子命令内部都翻译成 **`batch-operation`** 的 `actions[].action`。你只管发 `node create` / `edge create`，CLI 负责组装。
- **生成全是异步**：`gen image|video|audio|music|text` 提交拿 `taskId`，加 **`--wait`** 一条命令跑完「提交 → 回填 PENDING → 轮询 → 回填终态」整套状态机；不加 `--wait` 只提交返回 `taskId`，再用 `neowow poll <taskId> --apply`（`--apply` 把终态回填进节点，否则节点停在生成中）。唯一同步例外是 `gen lyrics`（歌词）。
- **生成前先让用户确认（默认工作流，生成扣积分）**：用户没明确指定模型/引用时，先 `gen … --dry-run` 预览（模型+引用清单+完整提交体+`estimate` 积分预估，不扣分）呈给用户确认或改选（换模型改 `--model`，挑部分引用用 `--refs-only --ref <url>`），确认后去掉 `--dry-run` 提交。**报积分以 `estimate` 为准**——模型列表里的 `points_cost_per_image` 只是兜底基础价，带尺寸/质量档时实际单价在 `size_pricing_config` 计价矩阵里，自己心算会报错价。完整流程见 [commands/gen.md](./commands/gen.md)「生成前确认」。
- **默认模型推荐（用户无特殊要求时，放确认选项第一位）**：生图 `gpt-image-2-official`（`--size 2K --quality medium`；备选 `gemini-3-pro-image-preview` 2K）；视频 `--universal --model neo-video-2-0`（Seedance 2.0，默认即 720p）。**生视频模式硬规则：除非用户强行指定其他模式/模型，一律走全能参考（`--universal`）**——只有一张分镜图也是 `--universal --ref <图>`，不要自行退回首尾帧图生视频。**已有视频要「接着往后生成」用 `gen video --extend`（模型 `models video --extend`），要「改画面/换风格」用 `gen video --edit --edit-video <url> --duration <原片秒数>`（模型 `models video --edit`）**——对应画布视频节点的「视频延长」「视频编辑」tab，别拿全能参考硬凑。参数细节与「列表 ≠ 可提交性」说明见 gen.md 同节。
- **节点尺寸 CLI 自动算**：`node create` 按短边 280 + 长宽比写 `measured`（`--aspect W:H` 或 `--media-w/--media-h`）；`data._initialMeasured` 不发送，画布加载时自动重建。你不用碰公式。
- **上传素材**：`neowow upload <文件>` 传 OSS（MD5 去重、图片回吐 `measured`），加 `--create-node` 直接落 `image`/`video`/`audio` 上传节点（`data.type='upload'`，无左输入口）。
- **SeedAudio 场景配音**：`gen audio --engine seed --text …` 的文本可写角色声线、情绪、台词与环境声；无需音色 id，也可以不带参考素材。做双人对谈、剧情配音或复用音频节点模板时，读 [examples/seed-audio.md](./examples/seed-audio.md)（含多行文本、参考音频映射、参数和素材字段区别）。
- **把现成文本放上画布（用户说「把脚本/分镜/文案上传到画布」这类）**：`node create -t text --content "<正文>"`——text 节点的正文在 **`data.result`**，画布展示它；**别塞 `--prompt`**（那是让 LLM 生成用的输入，塞错节点在画布上是空的）。要 LLM 现写内容才用 `gen text`（终态自动回填 `result`）。
- **并发约束（重要）**：网页端只在加载画布时拉一次后端（无轮询、CLI 也不进 Yjs 房间），CLI 写入对开着的网页端**不可见**；且网页端刷新/关闭会把「不含 CLI 写入的旧全量快照」存本地、下次打开回放 `update-detail` **全量覆盖后端**，CLI 期间写的节点被物理删除。**CLI 操作某画布前，确认网页端没开着它（协作项目确认房间无人）；操作完成后网页端重新打开/刷新即可看到。**

## 文档地图

| 主题 | 文件 |
| --- | --- |
| **登录 / 当前用户 / 登出**（`neowow login` / `whoami` / `logout`） | [commands/login.md](./commands/login.md) |
| **自更新**（`neowow update [--check]`，被动新版提醒机制） | [commands/update.md](./commands/update.md) |
| **项目（会话）** `create`/`list`(默认 v3，文件夹视图)/`get`/`update`/`delete`/`clone`/`use`/`unuse` + **文件夹** `neowow folder create\|delete\|rename\|move` | [commands/project.md](./commands/project.md) |
| **节点** `create`/`get`/`update`/`delete`/`list`（含尺寸与 `-s`/`-u` 双写通道） | [commands/node.md](./commands/node.md) |
| **连线** `edge create`/`delete`/`list`（handle 表 + 合法性/成环校验） | [commands/edge.md](./commands/edge.md) |
| **上传素材** `neowow upload`（OSS 直传 / 去重 / `--create-node`） | [commands/upload.md](./commands/upload.md) |
| **模型发现** `neowow models image\|video [--universal\|--extend\|--edit]` | [commands/models.md](./commands/models.md) |
| **生成 + 轮询 + 历史** `neowow gen image\|video\|audio\|music\|lyrics\|text\|formal\|history` / `poll`（`--wait` 状态机；`gen image --transparent` 透明底、`gen video --draft`/样片模型出草稿、`gen formal` 草稿转正式） | [commands/gen.md](./commands/gen.md) |
| **素材校验**（Seedance2.0 真人合规验证）`neowow review --node\|--url`（对应画布「批校验」弹框；首次需 `--agree`） | [commands/review.md](./commands/review.md) |
| 全链路示例：登录→建项目→加图片节点→出图 | [examples/create-and-run.md](./examples/create-and-run.md) |
| 全链路示例：上传素材→建上传节点→连线→图生视频 | [examples/upload-and-node.md](./examples/upload-and-node.md) |
| 用 Claude Code / Codex 生产短剧（CLI 流水线） | [examples/short-drama.md](./examples/short-drama.md) |
| SeedAudio 场景配音：纯文本 / 单人参考 / 双人对谈 / 模板迁移 | [examples/seed-audio.md](./examples/seed-audio.md) |
| **排错手册**（errCode 表 / 轮询中断续接 / 网页端覆盖止损） | [examples/errors.md](./examples/errors.md) |
| 画布节点类型枚举（`-t` 值、handle、`data` 字段） | [node-types/README.md](./node-types/README.md) |
| 模型 schema 字段（image/video 可选项来源） | [model-schema/schema.md](./model-schema/schema.md) |
| 安装与分发：一行安装、把 `neowow` 装上 PATH | [scripts/install.md](./scripts/install.md) |

## 30 秒上手（已实测）

```bash
# 1. 登录（API Key，一次）：网页端「用户中心 → CLI」生成 Key 后粘给下面命令
neowow login --api-key "<你的 Key>"         # 在线验证并存 ~/.neowow/config.json
neowow whoami                               # 确认登录

# 2. 建项目并绑定当前目录
neowow project create "我的短剧" -d demo --use   # → {"sessionId":"...","bound":true}

# 3. 选模型 → 建图片节点 → 出图（--wait 跑完整状态机）
neowow models image                          # 演示用轻量模型 gemini-2.5-flash-image（仅 1K，便宜）；正式给用户生成优先上面的默认推荐
NODE=$(neowow node create -t image --x 320 --y 120 | jq -r .nodeKey)
neowow gen image --node "$NODE" \
  --prompt "赛博朋克猫，霓虹灯，雨夜街头，电影感" \
  --model gemini-2.5-flash-image --ar 16:9 --size 1K --wait
# → stdout: {"status":"SUCCESS","resultData":["https://...png"],"dataField":"inputImageUrls",...}
```

不加 `--wait` 时 `gen` 只返回 `taskId`，随后 **`neowow poll <taskId> --apply`** 轮询到终态并回填节点（默认每 5s 一轮、600s 超时，可 `--interval`/`--timeout` 调；`--once` 只查一轮不阻塞）。等待偏久多半是**并发超限排队**：非终态项带 `queuedByConcurrencyLimit:true` / `aheadCount`（前方排队数），进度 stderr 会提示——排队=还没开始跑，别急着判失败，必要时加大 `--timeout`（仓库版 api 契约文档（发布包不含））。

## 术语对照（for English-speaking agents）

| 中文 | English / CLI 对应 |
| --- | --- |
| 项目 / 会话 | project / session（`sessionId`） |
| 节点 | node（`nodeKey`） |
| 连线 / 边 | edge |
| 引用素材（连线/手动） | reference media（`connected*` / `manualReferences`） |
| 回填 | backfill（write results back into node `data`） |
| 全能参考 | universal reference mode（`gen video --universal`） |
| 首尾帧 | first/last frame（`IMAGE_TO_VIDEO`） |
| 音色 | voice（`soundId`，from `models voice`） |
| 积分 | points / credits（generation costs credits） |
