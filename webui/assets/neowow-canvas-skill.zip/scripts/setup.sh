#!/usr/bin/env bash
#
# setup.sh —— 把「已解压的 skill 包」就地完成安装（macOS / Linux）。
#
# 与 install.sh 的区别：install.sh 负责「下载+校验+安装」；本脚本不下载，
# 从当前包所在位置拷贝落位——供 agent 拿到 zip 自行安装时用（包根 README.md
# 的 Agent 安装步骤即调用本脚本），也适合离线/内网分发。
#
# 做三件事：
#   1) 把 skill 拷到目标目录（目录名固定 neowow-canvas，Claude Code 靠它发现）
#   2) 安装 `neowow` 命令 wrapper 到 ~/.neowow/bin 并注入 PATH（幂等）
#   3) 校验可执行
#
# 用法：bash scripts/setup.sh [--codex | --all | --project]
#   （默认装给 Claude Code：~/.claude/skills/neowow-canvas）
# 环境变量同 install.sh：NEOWOW_CLI_INSTALL_DIR / NEOWOW_CLI_PROFILE / NEOWOW_CLI_SKIP_PROFILE=1
set -euo pipefail

NAME="neowow-canvas"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$(dirname "$SCRIPT_DIR")"
[ -f "$SRC/SKILL.md" ] || { echo "✗ $SRC 不是 skill 包根（缺 SKILL.md）" >&2; exit 1; }

MODE="claude"
for a in "$@"; do
  case "$a" in
    --codex)   MODE="codex" ;;
    --project) MODE="project" ;;
    --all)     MODE="all" ;;
    *) echo "未知参数: ${a}（可选 --codex / --project / --all）" >&2; exit 1 ;;
  esac
done
TARGETS=()
case "$MODE" in
  claude)  TARGETS+=("$HOME/.claude/skills/$NAME") ;;
  codex)   TARGETS+=("$HOME/.agents/skills/$NAME") ;;
  project) TARGETS+=("$PWD/.claude/skills/$NAME") ;;
  all)     TARGETS+=("$HOME/.claude/skills/$NAME" "$HOME/.agents/skills/$NAME") ;;
esac

# ---- 与 install.sh 相同的 wrapper/PATH 逻辑（保持两处同步修改）----
add_to_path() {
  local dir="$1"
  case ":$PATH:" in *":$dir:"*) echo "✓ $dir 已在 PATH"; return 0 ;; esac
  if [ "${NEOWOW_CLI_SKIP_PROFILE:-}" = "1" ] || [ "${NEOWOW_CLI_PROFILE:-}" = "/dev/null" ] || [ "${PROFILE:-}" = "/dev/null" ]; then
    echo "（按设置跳过写 PATH）手动加入：export PATH=\"$dir:\$PATH\""
    return 0
  fi
  local profile="${NEOWOW_CLI_PROFILE:-}"
  if [ -z "$profile" ]; then
    case "${SHELL:-}" in
      *zsh)  profile="$HOME/.zshrc" ;;
      *bash) if [ -f "$HOME/.bashrc" ]; then profile="$HOME/.bashrc"; else profile="$HOME/.bash_profile"; fi ;;
      *)     profile="$HOME/.profile" ;;
    esac
  fi
  local marker="# neowow-cli: PATH (install.sh)"
  if [ -f "$profile" ] && grep -qF "$marker" "$profile"; then
    echo "✓ PATH 注入已存在于 $profile"
    return 0
  fi
  if printf '\n%s\nexport PATH="%s:$PATH"\n' "$marker" "$dir" >> "$profile" 2>/dev/null; then
    echo "✓ 已写入 PATH 到 ${profile}（新开终端或 source 该文件后生效）"
  else
    echo "⚠ 写 $profile 失败，手动加入：export PATH=\"$dir:\$PATH\""
  fi
}

install_cli_wrapper() {
  local cli_src="$1"
  if ! command -v node >/dev/null; then
    echo "⚠ 未找到 node：neowow CLI 需要 Node ≥18。装好 node 后可直接用：node \"$cli_src\" --help" >&2
    return 0
  fi
  local major; major="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
  if [ "${major:-0}" -lt 18 ]; then
    echo "⚠ Node 版本偏低（需 ≥18），当前 $(node -v)。升级后用：node \"$cli_src\"" >&2
  fi
  local install_dir="${NEOWOW_CLI_INSTALL_DIR:-$HOME/.neowow/bin}"
  mkdir -p "$install_dir"
  local wrapper="$install_dir/neowow"
  printf '#!/usr/bin/env bash\nexec node "%s" "$@"\n' "$cli_src" > "$wrapper"
  chmod +x "$wrapper"
  echo "✓ 已安装 neowow 命令 → $wrapper"
  add_to_path "$install_dir"
}
# ------------------------------------------------------------------

for t in "${TARGETS[@]}"; do
  mkdir -p "$t"
  if [ "$(cd "$SRC" && pwd)" = "$(cd "$t" && pwd)" ]; then
    echo "✓ 包已在目标位置 $t，跳过拷贝"
  else
    # 干净替换（同 install.sh）：只覆盖不剪枝会残留旧版删掉的文件；先防误删再清空
    if [ -f "$t/SKILL.md" ] || [ -z "$(ls -A "$t" 2>/dev/null)" ]; then
      rm -rf "$t"; mkdir -p "$t"
    else
      echo "✗ $t 已存在且不像本 skill 的安装目录（无 SKILL.md），为防误删不清空。请确认后手动移走再装。" >&2; exit 1
    fi
    ( cd "$SRC" && tar --exclude='./.neowow' --exclude='./dist' --exclude='.DS_Store' -cf - . ) | ( cd "$t" && tar -xf - )
    echo "✓ 已安装到 ${t}（干净替换）"
  fi
done

echo ""
if [ "$MODE" = "project" ]; then
  echo "（project 模式未装全局 neowow 命令）用：node \"${TARGETS[0]}/bin/neowow.mjs\" --help"
else
  install_cli_wrapper "${TARGETS[0]}/bin/neowow.mjs"
fi

echo ""
echo "完成。Claude Code 输入 /$NAME 调用（新建 skills 目录需重启一次 Claude Code）。"
echo "首次使用先设置 API Key（网页端「用户中心 → CLI」生成）：neowow login --api-key \"<key>\" → neowow whoami"
