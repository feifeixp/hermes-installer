#!/usr/bin/env bash
#
# install.sh —— 一行安装 neowow-canvas skill + neowow CLI 到 Claude Code / Codex（macOS / Linux）。
#
# skill 文档与 CLI 在同一个包里：解压后 CLI 就在 <skill>/bin/neowow.mjs（零依赖，需 Node ≥18）。
# 本脚本装完 skill 文档后，再把一个 `neowow` wrapper 装到 PATH，使你能直接 `neowow <command>`。
#
# 一行安装（CDN 地址已内置为 https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas；如需更换见 install.md）：
#   curl -fsSL https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | bash
#   curl -fsSL https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | bash -s -- --codex      # 装给 Codex
#   curl -fsSL https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | bash -s -- --all        # Claude + Codex 都装
#   curl -fsSL https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | bash -s -- --project    # 装到当前项目 ./.claude/skills（不装全局 neowow 命令）
#
# 默认下载单个 zip（与 install.ps1 用同一个包）。也可改用 tar.gz：
#   NEOWOW_SKILL_URL=https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/neowow-canvas-skill.tar.gz curl -fsSL .../install.sh | bash
#
# CLI wrapper 相关环境变量：
#   NEOWOW_CLI_INSTALL_DIR  wrapper 安装目录（默认 ~/.neowow/bin）
#   NEOWOW_CLI_PROFILE      要写 PATH 的 shell profile（默认按 $SHELL 探测）；设为 /dev/null 跳过
#   NEOWOW_CLI_SKIP_PROFILE=1  跳过写 PATH，只打印手动指引
set -euo pipefail

NAME="neowow-canvas"
# 发布时把下面默认值改成你的 CDN 目录，或用环境变量 NEOWOW_CDN_BASE 覆盖。
CDN_BASE="${NEOWOW_CDN_BASE:-https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas}"
# 发布时 pack.sh 注入内容寻址文件名（neowow-canvas-skill-<sha8>.zip）：本脚本永远指向与自己
# 同批的 zip——发版先传新 zip（新对象名，不影响在途安装）再覆盖 install 脚本，天然无批次错配。
VERSIONED_ZIP="" # NEOWOW_PACK_INJECT_ZIPNAME
# 默认取注入的版本化 zip（仓库源码为空时回落稳定名）；可用 NEOWOW_SKILL_URL 指定任意 .zip / .tar.gz 地址。
ARCHIVE_URL="${NEOWOW_SKILL_URL:-$CDN_BASE/${VERSIONED_ZIP:-neowow-canvas-skill.zip}}"

case "$ARCHIVE_URL" in
  *YOUR-CDN.example.com*) echo "✗ 还没设置 CDN 地址。请用 NEOWOW_CDN_BASE=<你的CDN目录> 覆盖，或编辑本脚本的 CDN_BASE。详见 install.md" >&2; exit 1 ;;
esac

# 解析目标
MODE="claude"
for a in "$@"; do
  case "$a" in
    --codex)   MODE="codex" ;;
    --project) MODE="project" ;;
    --all)     MODE="all" ;;
    *) echo "未知参数: ${a}（可选 --codex / --project / --all）" >&2; exit 1 ;;
  esac
done
TARGETS=()
case "$MODE" in
  claude)  TARGETS+=("$HOME/.claude/skills/$NAME") ;;
  codex)   TARGETS+=("$HOME/.agents/skills/$NAME") ;;
  project) TARGETS+=("$PWD/.claude/skills/$NAME") ;;
  all)     TARGETS+=("$HOME/.claude/skills/$NAME" "$HOME/.agents/skills/$NAME") ;;
esac

command -v curl >/dev/null || { echo "✗ 需要 curl" >&2; exit 1; }

# 按扩展名选解压器：.zip 用 unzip（Linux 优先）或 tar（macOS bsdtar 也能解 zip）；.tar.gz 用 tar
extract() {  # $1=归档文件  $2=目标目录
  case "$1" in
    *.zip)
      if command -v unzip >/dev/null; then unzip -oq "$1" -d "$2"
      elif tar -xf "$1" -C "$2" 2>/dev/null; then :   # macOS/libarchive tar 可解 zip
      else echo "✗ 解压 zip 需要 unzip（或可解 zip 的 tar）。可改用 tar.gz：NEOWOW_SKILL_URL=$CDN_BASE/neowow-canvas-skill.tar.gz" >&2; return 1; fi ;;
    *.tar.gz|*.tgz)
      command -v tar >/dev/null || { echo "✗ 需要 tar" >&2; return 1; }
      tar -xzf "$1" -C "$2" ;;
    *) echo "✗ 不认识的归档类型: $1（支持 .zip / .tar.gz）" >&2; return 1 ;;
  esac
}

# 把 neowow CLI 包一层 wrapper 装到 PATH（指向解压出来的 <skill>/bin/neowow.mjs）
add_to_path() {  # $1=要加入 PATH 的目录
  local dir="$1"
  case ":$PATH:" in *":$dir:"*) echo "✓ $dir 已在 PATH"; return 0 ;; esac
  if [ "${NEOWOW_CLI_SKIP_PROFILE:-}" = "1" ] || [ "${NEOWOW_CLI_PROFILE:-}" = "/dev/null" ] || [ "${PROFILE:-}" = "/dev/null" ]; then
    echo "（按设置跳过写 PATH）手动加入：export PATH=\"$dir:\$PATH\""
    return 0
  fi
  local profile="${NEOWOW_CLI_PROFILE:-}"
  if [ -z "$profile" ]; then
    case "${SHELL:-}" in
      *zsh)  profile="$HOME/.zshrc" ;;
      *bash) if [ -f "$HOME/.bashrc" ]; then profile="$HOME/.bashrc"; else profile="$HOME/.bash_profile"; fi ;;
      *)     profile="$HOME/.profile" ;;
    esac
  fi
  local marker="# neowow-cli: PATH (install.sh)"
  if [ -f "$profile" ] && grep -qF "$marker" "$profile"; then
    echo "✓ PATH 注入已存在于 $profile"
    return 0
  fi
  if printf '\n%s\nexport PATH="%s:$PATH"\n' "$marker" "$dir" >> "$profile" 2>/dev/null; then
    echo "✓ 已写入 PATH 到 ${profile}（新开终端或 source 该文件后生效）"
  else
    echo "⚠ 写 $profile 失败，手动加入：export PATH=\"$dir:\$PATH\""
  fi
}

install_cli_wrapper() {  # $1=CLI 入口 bin/neowow.mjs 的绝对路径
  local cli_src="$1"
  if ! command -v node >/dev/null; then
    echo "⚠ 未找到 node：neowow CLI 需要 Node ≥18。装好 node 后可直接用：node \"$cli_src\" --help" >&2
    return 0
  fi
  local major; major="$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
  if [ "${major:-0}" -lt 18 ]; then
    echo "⚠ Node 版本偏低（需 ≥18），当前 $(node -v)。升级后用：node \"$cli_src\"" >&2
  fi
  local install_dir="${NEOWOW_CLI_INSTALL_DIR:-$HOME/.neowow/bin}"
  mkdir -p "$install_dir"
  local wrapper="$install_dir/neowow"
  printf '#!/usr/bin/env bash\nexec node "%s" "$@"\n' "$cli_src" > "$wrapper"
  chmod +x "$wrapper"
  echo "✓ 已安装 neowow 命令 → $wrapper"
  add_to_path "$install_dir"
}

# 发布包完整性校验：pack.sh 打包时把 zip 的 SHA-256 注入下一行（仓库源码中为空=跳过）。
# 防的是「zip 被换/传输损坏/缓存污染」——校验不过即拒装，一个文件都不落地。
EXPECTED_SHA256="" # NEOWOW_PACK_INJECT_SHA256

EXT="zip"; case "$ARCHIVE_URL" in *.tar.gz|*.tgz) EXT="tar.gz" ;; esac
TMP="$(mktemp -d)"; ARCHIVE="$TMP/neowow-canvas-skill.$EXT"
trap 'rm -rf "$TMP"' EXIT
echo "↓ 下载 $ARCHIVE_URL"
curl -fsSL --retry 3 "$ARCHIVE_URL" -o "$ARCHIVE" || { echo "✗ 下载失败：$ARCHIVE_URL" >&2; exit 1; }

# 无论是否校验都先算指纹（校验用 + 落 .install-meta 供日后对批次）
ACTUAL=""
if command -v sha256sum >/dev/null; then ACTUAL="$(sha256sum "$ARCHIVE" | awk '{print $1}')"
elif command -v shasum >/dev/null; then ACTUAL="$(shasum -a 256 "$ARCHIVE" | awk '{print $1}')"; fi

if [ -n "$EXPECTED_SHA256" ]; then
  if [ -n "${NEOWOW_SKILL_URL:-}" ]; then
    echo "… 自定义来源（NEOWOW_SKILL_URL），内置 checksum 只对应默认 zip，跳过校验"
  elif [ -z "$ACTUAL" ]; then
    echo "⚠ 系统无 sha256sum/shasum，跳过完整性校验" >&2
  elif [ "$ACTUAL" = "$EXPECTED_SHA256" ]; then
    echo "✓ 完整性校验通过（SHA-256）"
  else
    echo "✗ 完整性校验失败，拒绝安装！" >&2
    echo "  期望 $EXPECTED_SHA256" >&2
    echo "  实际 $ACTUAL" >&2
    echo "  可能原因：CDN 上 zip 与 install.sh 不是同一批（发版后两者必须一起传）/ 缓存未刷新 / 传输损坏 / 被篡改。" >&2
    exit 1
  fi
fi

# 先解压到临时目录校验，再干净替换目标——直接覆盖解压会让旧版删掉/改名的文件残留，
# agent 会继续读到过期文档（zip 解压只增不删）。
EXTRACTED="$TMP/extract"; mkdir -p "$EXTRACTED"
extract "$ARCHIVE" "$EXTRACTED" || exit 1
[ -f "$EXTRACTED/SKILL.md" ] || { echo "✗ 包内缺少 SKILL.md，请检查 zip 是否以 skill 内容为根（SKILL.md 在压缩包根目录，见 install.md 打包说明）" >&2; exit 1; }

for t in "${TARGETS[@]}"; do
  # 防误删：目标已存在、非空、又不像本 skill 的安装目录（无 SKILL.md）时拒绝清空
  if [ -d "$t" ] && [ ! -f "$t/SKILL.md" ] && [ -n "$(ls -A "$t" 2>/dev/null)" ]; then
    echo "✗ $t 已存在且不像本 skill 的安装目录（无 SKILL.md），为防误删不清空。请确认后手动移走再装。" >&2
    exit 1
  fi
  rm -rf "$t"
  mkdir -p "$t"
  cp -R "$EXTRACTED/." "$t/"
  {
    echo "build=$( [ -f "$t/VERSION" ] && cat "$t/VERSION" || echo unknown )"
    echo "zipSha256=${ACTUAL:-unknown}"
    echo "source=$ARCHIVE_URL"
    echo "installedAt=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  } > "$t/.install-meta"
  echo "✓ 已安装到 ${t}（干净替换，旧文件不残留）"
done

# 装 neowow CLI 命令（project 模式不装全局命令，只给本地调用提示）
echo ""
if [ "$MODE" = "project" ]; then
  echo "（project 模式未装全局 neowow 命令）用：node \"${TARGETS[0]}/bin/neowow.mjs\" --help"
else
  CLI_SRC="${TARGETS[0]}/bin/neowow.mjs"
  if [ -f "$CLI_SRC" ]; then
    install_cli_wrapper "$CLI_SRC"
  else
    echo "⚠ 包里没有 bin/neowow.mjs（旧版纯文档包？）；跳过 CLI 命令安装。" >&2
  fi
fi

echo ""
case "$MODE" in
  codex) echo "完成。Codex：已装到 ~/.agents/skills/$NAME/。若你的 Codex 不自动发现 skills，在项目 AGENTS.md 里指向该 SKILL.md（见 install.md）。" ;;
  all)   echo "完成。Claude Code 输入 /$NAME 调用；Codex 见 install.md（必要时在 AGENTS.md 指向 SKILL.md）。新建 skills 目录需重启一次 Claude Code。" ;;
  project) echo "完成。Claude Code 输入 /$NAME 调用（新建 skills 目录需重启一次 Claude Code）。" ;;
  *)     echo "完成。Claude Code 里输入 /$NAME 即可调用（若是新建的 skills 目录，重启一次 Claude Code 才会被监听）。" ;;
esac
echo ""
echo "使用前先设置 API Key（网页端「用户中心 → CLI」生成）："
echo "  neowow login --api-key \"<你的 Key>\"   # 保存并在线验证，存 ~/.neowow/config.json"
echo "  neowow whoami                      # 确认登录"
echo "（也可不落盘：export NEOWOW_API_KEY=<key>；NEOWOW_BASE 默认正式环境 https://neowow.cn）"
echo "上手与短剧用法见该 skill 的 examples/create-and-run.md、examples/short-drama.md。"
