#!/usr/bin/env bash
#
# neowow-upload.sh —— 把本地文件直传到 NeoWoW 画布的 OSS，返回可放进节点的 URL。
#
# 封装了源码 src/api/oss.js 的预签名直传链路，外部 Agent 无需自己实现 OSS 签名：
#   1) md5(file) + GET /agent/image-record/query?imageMd5=  去重，命中即复用
#   2) POST /agent/oss/upload-url {fileName:"{md5}.{ext}", bizType:"uploads"}
#          → {uploadUrl, method, objectKey, fileUrl, requiredHeaders, expiresIn}
#          （对象路径完全由后端按 bizType 分配，客户端不再持有 OSS 凭证、不再自签名）
#   3) PUT  <uploadUrl>，requiredHeaders 原样带上（它们参与预签名计算）+ Content-Type 兜底
#   4) POST /agent/image-record/save        登记 md5->url（url 取 fileUrl）
#   5) 图片再用 ?x-oss-process=image/info 取宽高，按 short=280 公式算出 measured
#
# 依赖：bash、curl、jq，以及 md5sum(Linux) 或 md5(macOS)
#
# 用法（NEOWOW_API_KEY/NEOWOW_BASE 为主，API_KEY/BASE 兼容；默认正式环境）：
#   NEOWOW_API_KEY=<key> [NEOWOW_BASE=https://neowow.cn] \
#     ./neowow-upload.sh <文件路径> [image|video|audio|worldModel]
#   （mediaType 省略时按扩展名/MIME 推断）
#
# 输出（stdout，单行 JSON）：
#   { "url": "...", "mediaType":"image", "dataField":"inputImageUrls",
#     "reused": false, "measured": {"width":498,"height":280} | null }
#
# 退出码：0 成功；非 0 失败（错误打到 stderr）。
set -euo pipefail

err() { echo "[neowow-upload] $*" >&2; }
die() { err "$*"; exit 1; }

# ---------- 参数 / 环境 ----------
# 环境变量 NEOWOW_BASE/NEOWOW_API_KEY 为主，BASE/API_KEY 兼容；默认正式环境。
BASE="${NEOWOW_BASE:-${BASE:-https://neowow.cn}}"
API_KEY="${NEOWOW_API_KEY:-${API_KEY:-}}"
FILE="${1:-}"
MEDIA_TYPE="${2:-}"
[ -n "$FILE" ] || die "用法: NEOWOW_API_KEY=<key> $0 <文件> [image|video|audio|worldModel]"
[ -f "$FILE" ] || die "文件不存在: $FILE"
[ -n "$API_KEY" ] || die "缺少 API Key。设置 NEOWOW_API_KEY（或 API_KEY）=<key>，见 api/auth.md"
for c in curl jq; do command -v "$c" >/dev/null || die "缺少依赖: $c"; done

# md5 工具（跨平台）
md5_of() {
  if command -v md5sum >/dev/null; then md5sum "$1" | cut -d' ' -f1
  elif command -v md5 >/dev/null; then md5 -q "$1"
  else die "缺少 md5sum / md5"; fi
}

EXT="${FILE##*.}"; EXT="$(printf '%s' "$EXT" | tr 'A-Z' 'a-z')"
[ "$EXT" = "$FILE" ] && EXT=""   # 无扩展名

# 推断 mediaType（与 mediaUploadLimits.js 的白名单一致）
if [ -z "$MEDIA_TYPE" ]; then
  case "$EXT" in
    jpg|jpeg|png|webp|gif) MEDIA_TYPE=image ;;
    mp4|webm|mov)          MEDIA_TYPE=video ;;
    mp3|wav|ogg|m4a|aac)   MEDIA_TYPE=audio ;;
    spz)                   MEDIA_TYPE=worldModel ;;
    *) die "无法按扩展名 .$EXT 推断类型，请显式指定 image|video|audio|worldModel" ;;
  esac
fi

# 节点数据字段（存储目录已由后端按 bizType 分配，客户端不再自拼 workflow/images 等路径）
case "$MEDIA_TYPE" in
  image)      DATA_FIELD="inputImageUrls" ;;
  video)      DATA_FIELD="inputVideoUrls" ;;
  audio)      DATA_FIELD="inputAudioUrls" ;;
  worldModel) DATA_FIELD="spzUrl" ;;
  *) die "未知 mediaType: $MEDIA_TYPE" ;;
esac

# Content-Type 兜底（requiredHeaders 里有同名头时以它为准）
case "$EXT" in
  jpg|jpeg) CT="image/jpeg" ;; png) CT="image/png" ;; webp) CT="image/webp" ;; gif) CT="image/gif" ;;
  mp4) CT="video/mp4" ;; webm) CT="video/webm" ;; mov) CT="video/quicktime" ;;
  mp3) CT="audio/mpeg" ;; wav) CT="audio/wav" ;; ogg) CT="audio/ogg" ;; m4a) CT="audio/x-m4a" ;; aac) CT="audio/aac" ;;
  *) CT="application/octet-stream" ;;
esac

AUTH_H="api-key: $API_KEY"

# ---------- 1. MD5 去重 ----------
MD5="$(md5_of "$FILE")"
FNAME="${MD5}${EXT:+.$EXT}"
QUERY="$(curl -sS "$BASE/agent/image-record/query?imageMd5=$MD5" -H "$AUTH_H" || true)"
HIT_URL="$(printf '%s' "$QUERY" | jq -r '.data.imageUrl // empty' 2>/dev/null || true)"
if [ -n "$HIT_URL" ]; then
  err "已存在相同 MD5，复用：$HIT_URL"
  URL="$HIT_URL"; REUSED=true
else
  REUSED=false
  # ---------- 2. 取预签名直传地址（对象路径由后端按 bizType 分配）----------
  # 后端按 fileName 扩展名做类型白名单：无后缀会被以「不支持的文件类型」拒绝
  PRESIGN="$(curl -sS "$BASE/agent/oss/upload-url" -H "$AUTH_H" -H 'Content-Type: application/json' \
    -d "{\"fileName\":\"$FNAME\",\"bizType\":\"uploads\"}")"
  UPLOAD_URL="$(printf '%s' "$PRESIGN" | jq -r '.data.uploadUrl // empty')"
  [ -n "$UPLOAD_URL" ] || die "获取上传地址失败：$PRESIGN"
  METHOD="$(printf '%s' "$PRESIGN" | jq -r '.data.method // "PUT"')"
  FILE_URL="$(printf '%s' "$PRESIGN" | jq -r '.data.fileUrl // empty')"

  # 已知后端瑕疵：uploadUrl 主机名可能重复拼桶名（bucket.bucket.oss-xxx），
  # OSS 通配符证书只覆盖一级子域名会直接 TLS 失败；V1 预签名不含 Host，改域名不影响签名。
  DUP_HOST="$(printf '%s' "$UPLOAD_URL" | sed -n 's#^https\{0,1\}://\([^./]*\)\.\1\.\(oss-[^/]*\).*#\1.\2#p')"
  if [ -n "$DUP_HOST" ]; then
    UPLOAD_URL="$(printf '%s' "$UPLOAD_URL" | sed "s#://[^./]*\.#://#")"
    err "预签名域名桶名重复，已修正：$DUP_HOST"
  fi

  # ---------- 3. 按预签名信息直传 ----------
  # requiredHeaders 参与预签名计算，必须原样发送（bash 3.2 下空数组要加 +"..." 守卫）
  REQ_H=()
  while IFS= read -r h; do
    [ -n "$h" ] && REQ_H+=(-H "$h")
  done < <(printf '%s' "$PRESIGN" | jq -r '.data.requiredHeaders // {} | to_entries[] | "\(.key): \(.value)"')

  err "预签名直传 → ${UPLOAD_URL%%\?*}"
  HTTP_CODE="$(curl -sS -o /dev/null -w '%{http_code}' -X "$METHOD" "$UPLOAD_URL" \
    -H "Content-Type: ${CT}" ${REQ_H[@]+"${REQ_H[@]}"} \
    --data-binary @"$FILE")"
  case "$HTTP_CODE" in
    2??) ;;
    *) die "OSS 直传失败，HTTP $HTTP_CODE（预签名可能已过期，或 requiredHeaders 未原样发送）" ;;
  esac
  # fileUrl 是后端给的访问地址；兜底剥掉预签名 query
  URL="${FILE_URL:-${UPLOAD_URL%%\?*}}"

  # ---------- 4. 登记记录 ----------
  curl -sS "$BASE/agent/image-record/save" -H "$AUTH_H" -H 'Content-Type: application/json' \
    -d "{\"imageMd5\":\"$MD5\",\"imageUrl\":\"$URL\"}" >/dev/null || err "image-record/save 失败（不影响 URL 可用）"
fi

# ---------- 5. 图片取尺寸算 measured ----------
MEASURED=null
if [ "$MEDIA_TYPE" = "image" ]; then
  SEP='?'; case "$URL" in *\?*) SEP='&' ;; esac
  INFO="$(curl -sS "${URL}${SEP}x-oss-process=image/info" || true)"
  W="$(printf '%s' "$INFO" | jq -r '.ImageWidth.value // empty' 2>/dev/null || true)"
  H="$(printf '%s' "$INFO" | jq -r '.ImageHeight.value // empty' 2>/dev/null || true)"
  if [ -n "$W" ] && [ -n "$H" ] && [ "$W" -gt 0 ] && [ "$H" -gt 0 ]; then
    # short=280：ar>1 → {round(280*ar),280}；否则 {280,round(280/ar)}（nodeMeasurement.js:13-42）
    MEASURED="$(awk -v w="$W" -v h="$H" 'BEGIN{b=280; ar=w/h;
      if(ar>1){printf "{\"width\":%d,\"height\":%d}", int(b*ar+0.5), b}
      else    {printf "{\"width\":%d,\"height\":%d}", b, int(b/ar+0.5)} }')"
  fi
fi

# ---------- 输出 ----------
jq -nc --arg url "$URL" --arg mt "$MEDIA_TYPE" --arg df "$DATA_FIELD" \
   --argjson reused "$REUSED" --argjson measured "$MEASURED" \
   '{url:$url, mediaType:$mt, dataField:$df, reused:$reused, measured:$measured}'
