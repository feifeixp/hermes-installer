#!/usr/bin/env bash
#
# pack.sh —— 把 neowow-canvas skill 打成可上传 CDN 的发布包（macOS / Linux）。
#
# 产出到 <skill>/dist/ ：
#   neowow-canvas-skill.zip   （install.sh / install.ps1 默认取它）
#   neowow-canvas-skill.tar.gz（无 zip 时的备选，tar 通常都在）
#   install.sh  install.ps1   （随包放一处，方便一起上传）
#
# 用法（在任意目录都行，按脚本自身位置定位 skill 根）：
#   ./scripts/pack.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"
NAME="neowow-canvas-skill"
DIST="$ROOT/dist"
# 不随包分发的内部/维护文档与开发工具（相对 skill 根；用户用不到、且暴露底层端点）。要调整在此增删。
# creative-skills/ 是仓库内的上层「创作工作法」示例 skill——安装器只装 neowow-canvas 主目录、无链接指向它们，
# 打进包只会给 agent 读的主 skill 增噪，故不随发布包分发（仍留在仓库供参考/单独安装）。
EXCLUDE_PATHS=(api DESIGN.md DEPLOY.md scripts/dev-smoke.mjs creative-skills)

[ -f "$ROOT/SKILL.md" ] || { echo "✗ 未找到 $ROOT/SKILL.md（本脚本应位于 skill 的 scripts/ 下）" >&2; exit 1; }

# 构建指纹：package.json 版本 + git 短哈希 + 打包时间（自动派生，无须手动升版）。
# 注入两处：CLI 的 --version（esbuild --define）与包内 VERSION 文件——用户报障时对批次用。
PKG_VERSION="$(node -p "require('$ROOT/package.json').version" 2>/dev/null || echo 0.0.0)"
GIT_HASH="$(git -C "$ROOT" rev-parse --short HEAD 2>/dev/null || echo nogit)"
BUILD_STR="v${PKG_VERSION}+${GIT_HASH}.$(date -u +%Y%m%dT%H%M%SZ)"

rm -rf "$DIST"; mkdir -p "$DIST"

# 暂存副本（源码保持完整，只在副本上剔除/改写）：剔除 dist/.git/.neowow + EXCLUDE_PATHS
STAGE_ROOT="$(mktemp -d)"; STAGE="$STAGE_ROOT/$NAME"; mkdir -p "$STAGE"
trap 'rm -rf "$STAGE_ROOT"' EXIT
TAR_EX=(--exclude='./dist' --exclude='./.git' --exclude='./.neowow' --exclude='./node_modules' --exclude='.DS_Store')
for p in "${EXCLUDE_PATHS[@]}"; do TAR_EX+=(--exclude="./$p"); done
( cd "$ROOT" && tar "${TAR_EX[@]}" -cf - . ) | ( cd "$STAGE" && tar -xf - )

# 抹平指向已剔除 api/ 的 markdown 链接：[text](.../api/...) → text（保留文字、去死链）
find "$STAGE" -name '*.md' -type f -exec perl -i -pe 's#\[([^\]]*)\]\((?:\.{1,2}/)*api/[^)]*\)#$1#g' {} + 2>/dev/null || \
  echo "… 无 perl，api/ 死链未抹平（不影响安装）" >&2
# 再抹纯文本指引残句（「见 api/xxx.md §n」这类非链接写法）——装好 skill 的 agent 按图索骥会扑空
find "$STAGE" -name '*.md' -type f -exec perl -i -pe 's#(?:(?:详见|端点契约见|端点见|见)\s*)?(?:\.\./|\./)?\bapi/[A-Za-z0-9._-]+\.md(\s*§[0-9]+(?:[./][0-9]+)*)?#仓库版 api 契约文档（发布包不含）#g' {} + 2>/dev/null || true
# SKILL.md 文档地图里的 api/ 行整行剔除
perl -i -ne 'print unless m{\|\s*api/\s*\|}' "$STAGE/SKILL.md" 2>/dev/null || true
echo "✓ 发布副本已剔除：${EXCLUDE_PATHS[*]}（并抹平 api/ 残留指引）"

printf '%s\n' "$BUILD_STR" > "$STAGE/VERSION"
echo "✓ 构建指纹：${BUILD_STR}（包内 VERSION 文件 + CLI --version）"

# 把 CLI 与上传助手 bundle+压缩混淆成单文件（端点/签名逻辑不再以明文出现），并从发布包剔除可读 lib/ 源码。
# 自动在 skill / 父项目 node_modules 与 PATH 里找 esbuild；找不到则保留源码并告警。设 NEOWOW_PACK_RAW=1 显式跳过。
obfuscate_mjs() {  # $1=源 .mjs  $2=发布副本内的目标路径
  local tmp="$STAGE_ROOT/$(basename "$2").cjs"
  "$ESBUILD" "$1" --bundle --minify --platform=node --format=cjs \
    --define:__NEOWOW_BUILD__="\"$BUILD_STR\"" --outfile="$tmp" >/dev/null 2>&1
  node -e '
    const fs=require("fs");
    const code=fs.readFileSync(process.argv[1],"utf8").replace(/^#![^\n]*\n/, "");
    const b64=Buffer.from(code,"utf8").toString("base64");
    fs.writeFileSync(process.argv[2], `#!/usr/bin/env node\nimport { createRequire } from "node:module";\nconst require = createRequire(import.meta.url);\nconst m = { exports: {} };\nnew Function("require","module","exports","__dirname","__filename", Buffer.from(${JSON.stringify(b64)},"base64").toString("utf8"))(require, m, m.exports, "", "");\n`);
  ' "$tmp" "$2"
}
if [ "${NEOWOW_PACK_RAW:-}" != "1" ]; then
  ESBUILD=""
  for c in "$ROOT/node_modules/.bin/esbuild" "$ROOT/../node_modules/.bin/esbuild" "$ROOT/../../node_modules/.bin/esbuild"; do
    [ -x "$c" ] && { ESBUILD="$c"; break; }
  done
  [ -z "$ESBUILD" ] && command -v esbuild >/dev/null 2>&1 && ESBUILD="esbuild"
  if [ -n "$ESBUILD" ]; then
    # ① CLI：混淆 + 剔除 lib/ 源码；冒烟 --help
    obfuscate_mjs "$ROOT/bin/neowow.mjs" "$STAGE/bin/neowow.mjs"
    rm -rf "$STAGE/lib"
    if node "$STAGE/bin/neowow.mjs" --help >/dev/null 2>&1; then
      echo "✓ CLI 已 bundle+混淆为单文件（$(wc -c <"$STAGE/bin/neowow.mjs" | tr -d ' ')B），lib/ 源码已从发布包剔除"
    else
      echo "✗ CLI 混淆产物冒烟测试失败，请检查 esbuild 版本或设 NEOWOW_PACK_RAW=1" >&2; exit 1
    fi
    # 全链路冒烟（桩后端，覆盖「提交成功后」的处理路径——--help 冒烟测不到这里）
    if SMOKE_OUT="$(node "$ROOT/scripts/dev-smoke.mjs" "$STAGE/bin/neowow.mjs" 2>&1)"; then
      echo "✓ 混淆产物全链路冒烟通过（桩后端：提交→回填→轮询→终态 + poll --apply）"
    else
      echo "✗ 混淆产物全链路冒烟失败（scripts/dev-smoke.mjs）：" >&2
      echo "$SMOKE_OUT" >&2; exit 1
    fi
    # ② 上传助手（零依赖单文件，同样可混淆）；无 --help，冒烟 = 无参运行应打印用法并退出非 0
    obfuscate_mjs "$ROOT/scripts/neowow-upload.mjs" "$STAGE/scripts/neowow-upload.mjs"
    UPLOAD_OUT="$(node "$STAGE/scripts/neowow-upload.mjs" 2>&1 || true)"
    case "$UPLOAD_OUT" in
      *用法*) echo "✓ neowow-upload.mjs 已混淆（$(wc -c <"$STAGE/scripts/neowow-upload.mjs" | tr -d ' ')B）" ;;
      *) echo "✗ neowow-upload.mjs 混淆产物冒烟测试失败：$UPLOAD_OUT" >&2; exit 1 ;;
    esac
  else
    echo "⚠ 未找到 esbuild：发布包将含可读 lib/ 与 neowow-upload.mjs 源码（端点/签名逻辑明文）。装 esbuild 后重打可混淆，或设 NEOWOW_PACK_RAW=1 显式保留源码。" >&2
  fi
fi

# zip（首选）。-X 去掉多余属性。
if command -v zip >/dev/null; then
  ( cd "$STAGE" && zip -rqX "$DIST/$NAME.zip" . -x '.DS_Store' '*/.DS_Store' )
  echo "✓ $DIST/$NAME.zip"
else
  echo "… 无 zip 命令，跳过 zip（仅出 tar.gz；用户需 NEOWOW_SKILL_URL 指向 tar.gz）" >&2
fi

# tar.gz（备选）
if tar -czf "$DIST/$NAME.tar.gz" -C "$STAGE" . 2>/dev/null; then
  echo "✓ $DIST/$NAME.tar.gz"
else
  echo "… tar.gz 生成失败（可忽略，只要有 zip）" >&2
fi

cp "$ROOT/scripts/install.sh" "$ROOT/scripts/install.ps1" "$DIST/"

# 把 zip 的 SHA-256 注入 dist/ 里的安装脚本（仓库源码保持空值+标记行）：
# 安装时下载 zip 后本地重算指纹比对，不符即拒装——所以每次发版 install.sh/ps1 必须和 zip 一起上传。
if [ -f "$DIST/$NAME.zip" ]; then
  if command -v sha256sum >/dev/null; then ZIP_SHA="$(sha256sum "$DIST/$NAME.zip" | awk '{print $1}')"
  else ZIP_SHA="$(shasum -a 256 "$DIST/$NAME.zip" | awk '{print $1}')"; fi
  # (\r?) 兼容 install.ps1 的 CRLF 行尾（Windows 脚本），并原样保留
  perl -i -pe "s|^EXPECTED_SHA256=.*# NEOWOW_PACK_INJECT_SHA256(\r?)\$|EXPECTED_SHA256=\"$ZIP_SHA\"\$1|" "$DIST/install.sh"
  perl -i -pe "s|^\\\$expectedSha256 = .*# NEOWOW_PACK_INJECT_SHA256(\r?)\$|\\\$expectedSha256 = '$ZIP_SHA'\$1|" "$DIST/install.ps1"
  grep -q "$ZIP_SHA" "$DIST/install.sh" && grep -q "$ZIP_SHA" "$DIST/install.ps1" \
    || { echo "✗ checksum 注入失败（标记行没匹配上？）" >&2; exit 1; }
  echo "✓ 已注入 zip SHA-256 到 dist/install.sh 与 dist/install.ps1：$ZIP_SHA"

  # 内容寻址 zip（发布原子性）：install 脚本内置指向与自己同批的 <name>-<sha8>.zip。
  # 发版顺序 = 先传版本化 zip（新对象，不影响在途安装）→ 再覆盖 install.sh/ps1 → 最后稳定别名 zip。
  # 旧版本化 zip 留在桶里即免费回滚（NEOWOW_SKILL_URL 指旧文件名）。
  SHA8="${ZIP_SHA:0:8}"
  VERSIONED="$NAME-$SHA8.zip"
  cp "$DIST/$NAME.zip" "$DIST/$VERSIONED"
  perl -i -pe "s|^VERSIONED_ZIP=.*# NEOWOW_PACK_INJECT_ZIPNAME(\r?)\$|VERSIONED_ZIP=\"$VERSIONED\"\$1|" "$DIST/install.sh"
  perl -i -pe "s|^\\\$versionedZip = .*# NEOWOW_PACK_INJECT_ZIPNAME(\r?)\$|\\\$versionedZip = '$VERSIONED'\$1|" "$DIST/install.ps1"
  grep -q "$VERSIONED" "$DIST/install.sh" && grep -q "$VERSIONED" "$DIST/install.ps1" \
    || { echo "✗ 版本化 zip 文件名注入失败（标记行没匹配上？）" >&2; exit 1; }
  echo "✓ 内容寻址包：$DIST/${VERSIONED}（install 脚本已内置指向它）"
fi
echo "✓ $DIST/install.sh  $DIST/install.ps1"

# 内容寻址 tar.gz + latest.json（`neowow update` 自更新用：CLI 拉 latest.json 比版本、下 tgz 校验 SHA 换装）
if [ -f "$DIST/$NAME.tar.gz" ]; then
  if command -v sha256sum >/dev/null; then TGZ_SHA="$(sha256sum "$DIST/$NAME.tar.gz" | awk '{print $1}')"
  else TGZ_SHA="$(shasum -a 256 "$DIST/$NAME.tar.gz" | awk '{print $1}')"; fi
  TGZ_VERSIONED="$NAME-${TGZ_SHA:0:8}.tar.gz"
  cp "$DIST/$NAME.tar.gz" "$DIST/$TGZ_VERSIONED"
  printf '{"version":"%s","tgz":"%s","tgzSha256":"%s","zip":"%s","zipSha256":"%s"}\n' \
    "$BUILD_STR" "$TGZ_VERSIONED" "$TGZ_SHA" "${VERSIONED:-$NAME.zip}" "${ZIP_SHA:-}" > "$DIST/latest.json"
  echo "✓ 自更新元数据：$DIST/latest.json（指向 ${TGZ_VERSIONED}）"
else
  echo "⚠ 无 tar.gz，跳过 latest.json——本批发布不支持 neowow update 自更新" >&2
fi

# 校验 SKILL.md 在压缩包根目录
# 注意：用 here-string（先让 unzip 跑完再喂 grep），避免 pipefail + grep -q 提前关管道
# 导致 unzip 收到 SIGPIPE、整条管道被判失败的误报。
if command -v unzip >/dev/null && [ -f "$DIST/$NAME.zip" ]; then
  if grep -qx 'SKILL.md' <<<"$(unzip -Z1 "$DIST/$NAME.zip")"; then
    echo "✓ 校验：SKILL.md 位于 zip 根目录"
  else
    echo "✗ SKILL.md 不在 zip 根目录，安装会失败（检查打包是否以 skill 内容为根）" >&2; exit 1
  fi
fi

CDN="https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas"
echo ""
echo "完成。按序上传到 $CDN/（顺序即原子性）："
echo "  ① $NAME-${SHA8:-XXXXXXXX}.zip  ${TGZ_VERSIONED:-}   ← 内容寻址新对象先传，不影响任何在途安装/更新"
echo "  ② install.sh  install.ps1                ← 内置指向 ①，传完即切到新版"
echo "  ③ $NAME.zip（稳定别名，「发 zip 链接给 agent」流程用）  可选 $NAME.tar.gz"
echo "  ④ latest.json                            ← 最后传：它是 neowow update 的更新触发器，先传会指向还没上桶的包"
echo "旧的 $NAME-<旧sha8>.zip/.tar.gz 留在桶里即可回滚：NEOWOW_SKILL_URL 指旧文件名安装旧版。"
echo "校验一行安装：curl -fsSL $CDN/install.sh | bash"
