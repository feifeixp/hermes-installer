<#
  pack.ps1 —— 把 neowow-canvas skill 打成可上传 CDN 的发布包（Windows）。

  产出到 <skill>\dist\ ：
    neowow-canvas-skill.zip   （install.sh / install.ps1 默认取它）
    install.sh  install.ps1   （随包放一处，方便一起上传）

  用法（仅 Windows 本机自测；对外发布必须用 scripts/pack.sh）：
    .\scripts\pack.ps1 -Dev
#>
param([switch]$Dev)
$ErrorActionPreference = 'Stop'
if (-not $Dev) {
  Write-Error '本脚本仅用于 Windows 本机自测打包：不剔除 api/DESIGN.md/DEPLOY.md、不混淆 CLI、不注入 checksum/版本（校验会被静默跳过）。对外发布必须在 macOS/Linux 用 scripts/pack.sh。确认只做本机测试请加 -Dev 重跑。'
}
Write-Warning '当前为本机自测包（-Dev）：含内部文档与明文源码，禁止上传 CDN 对外分发。'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $scriptDir
$name = 'neowow-canvas-skill'
$dist = Join-Path $root 'dist'

if (-not (Test-Path (Join-Path $root 'SKILL.md'))) {
  Write-Error "未找到 $root\SKILL.md（本脚本应位于 skill 的 scripts\ 下）"
}

if (Test-Path $dist) { Remove-Item -Recurse -Force $dist }
New-Item -ItemType Directory -Force -Path $dist | Out-Null

# 收集 skill 根下除 dist/.git 外的顶层项，打到 zip 根（SKILL.md 在根）
$items = Get-ChildItem -LiteralPath $root -Force | Where-Object { $_.Name -notin @('dist', '.git', '.neowow', 'node_modules') }
$zip = Join-Path $dist "$name.zip"
Compress-Archive -Path $items.FullName -DestinationPath $zip -Force
Write-Host "✓ $zip"

Copy-Item (Join-Path $root 'scripts\install.sh'), (Join-Path $root 'scripts\install.ps1') -Destination $dist
Write-Host "✓ $dist\install.sh  $dist\install.ps1"

# 校验 SKILL.md 在 zip 根
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead($zip)
$hasRoot = $archive.Entries | Where-Object { $_.FullName -eq 'SKILL.md' }
$archive.Dispose()
if (-not $hasRoot) { Write-Error "SKILL.md 不在 zip 根目录，安装会失败" }
Write-Host "✓ 校验：SKILL.md 位于 zip 根目录"

Write-Host ""
Write-Host "完成（本机自测包）。本地验证：`$env:NEOWOW_SKILL_URL='file:///$($zip -replace '\\','/')'; . .\scripts\install.ps1"
Write-Host "⚠ 此包不得上传 CDN 对外分发——对外发布用 scripts/pack.sh（macOS/Linux）。"
