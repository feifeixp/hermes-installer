# scripts

封装好的辅助脚本，省去外部 Agent 自己拼上传流程等繁琐步骤。**一行安装与 CDN 分发见 [install.md](./install.md)。**

## 平台矩阵（三平台全覆盖）

| 脚本 | 作用 | Windows | macOS | Linux |
| --- | --- | --- | --- | --- |
| [install.ps1](./install.ps1) | 一行安装 skill | ✅ 原生 | ✅ PS7 | ✅ PS7 |
| [install.sh](./install.sh) | 一行安装 skill | ✅ Git Bash/WSL | ✅ | ✅ |
| [neowow-upload.mjs](./neowow-upload.mjs) | 素材上传（**推荐**，单文件跨平台） | ✅ | ✅ | ✅ |
| [neowow-upload.sh](./neowow-upload.sh) | 素材上传（纯 shell 备选） | ✅ Git Bash/WSL | ✅ | ✅ |
| [pack.ps1](./pack.ps1) | **仅本机自测**打包（需 `-Dev`；对外发布必须用 pack.sh） | ✅ 原生 | ✅ PS7 | ✅ PS7 |
| [pack.sh](./pack.sh) | 打包**对外发布包** → dist/（混淆+剔除+注入 checksum/版本） | ✅ Git Bash/WSL | ✅ | ✅ |

- 上传助手优先用 **`.mjs`**（Node，三平台行为一致；Claude Code 本就依赖 Node）。无 Node 的纯 shell 环境用 `.sh`。
- 下面"用法"两版（Node / bash）等价，输出 JSON 相同。

## `neowow-upload.sh` —— 一行命令把本地文件传到画布 OSS

把源码 `src/api/oss.js` 的 **预签名直传链路**整条封装：MD5 去重 → `POST /agent/oss/upload-url` 取预签名地址 → 按 `requiredHeaders` PUT 直传 → 登记记录 → 图片回吐 `measured`。完整契约仓库版 api 契约文档（发布包不含）。

### 依赖

`bash`、`curl`、`jq`，以及 `md5sum`（Linux）或 `md5`（macOS）。无需安装阿里云 SDK / ossutil（改预签名后连 `openssl` 也不再需要——签名由后端算）。

### 用法

环境变量 **`NEOWOW_API_KEY` / `NEOWOW_BASE` 为主**（`API_KEY` / `BASE` 也兼容）。`NEOWOW_BASE` 缺省即正式环境（`https://neowow.cn`），无需设置。

```bash
# 跨平台（推荐，Win/mac/Linux 同样命令）：
NEOWOW_API_KEY=<key> [NEOWOW_BASE=https://neowow.cn] \
  node neowow-upload.mjs <文件路径> [image|video|audio|worldModel]

# 纯 shell 备选（mac/Linux / Git Bash）：
NEOWOW_API_KEY=<key> [NEOWOW_BASE=...] \
  ./neowow-upload.sh <文件路径> [image|video|audio|worldModel]
```

Windows PowerShell 设环境变量：`$env:NEOWOW_API_KEY='...'; node neowow-upload.mjs .\cat.png`

- `API_KEY`：网页端「用户中心 → CLI」生成的 API Key（仓库版 api 契约文档（发布包不含））。
- `BASE`：默认正式环境域名 `https://neowow.cn`；换环境需自行覆盖（仓库版 api 契约文档（发布包不含））。
- 存储路径完全由后端按 `bizType` 分配，客户端不再持有任何 OSS 凭证，也无需传 uid/目录。
- 第二参省略时按扩展名/MIME 推断类型（白名单与大小上限仓库版 api 契约文档（发布包不含））。

### 输出（stdout，单行 JSON）

```json
{ "url": "https://wlpaas.oss-accelerate.aliyuncs.com/<后端分配的路径>/<md5>.jpg",
  "mediaType": "image", "dataField": "inputImageUrls",
  "reused": false, "measured": { "width": 498, "height": 280 } }
```

- `reused:true` 表示命中 MD5 去重、未实际上传。
- `measured` 仅图片有（用 OSS `x-oss-process=image/info` 取宽高按短边 280 算）；视频/音频为 `null`，需自行读元数据。

### 拿到结果后怎么用

把它接到节点上（仓库版 api 契约文档（发布包不含） 的 `batch-operation`）：

```bash
export NEOWOW_API_KEY=<key>                  # NEOWOW_BASE 默认即正式环境
OUT=$(node neowow-upload.mjs ./cat.png)
URL=$(echo "$OUT"   | jq -r .url)
FIELD=$(echo "$OUT" | jq -r .dataField)     # inputImageUrls
MEAS=$(echo "$OUT"  | jq -c .measured)      # {"width":498,"height":280}
NODE=$(uuidgen | tr 'A-Z' 'a-z')

curl -s "${NEOWOW_BASE:-https://neowow.cn}/agent/story-canvas/batch-operation" \
  -H "api-key: $NEOWOW_API_KEY" -H 'Content-Type: application/json' \
  -d "{\"sessionId\":\"$SESSION\",\"actions\":[{\"action\":\"create\",\"nodes\":[{
        \"id\":\"$NODE\",\"type\":\"image\",\"position\":{\"x\":320,\"y\":120},
        \"measured\":$MEAS,
        \"data\":{\"type\":\"upload\",\"mediaSource\":\"upload\",\"status\":\"idle\",
                  \"$FIELD\":[\"$URL\"]}
      }]}]}"
```

> 上传节点 `data.type='upload'` **无左输入口**（仓库版 api 契约文档（发布包不含））。

### 退出码

`0` 成功；非 `0` 失败（错误信息打到 stderr，正常结果只在 stdout 输出 JSON，便于管道）。

### 不用脚本？

也可在 仓库版 api 契约文档（发布包不含） 选**路径 B**（`POST /agent/upload/image` multipart）纯 curl 上传（仅图片、未核验视频/音频），或自己走两步预签名流程：`POST /agent/oss/upload-url` 取地址 → `curl -X PUT` 带上 `requiredHeaders`。
