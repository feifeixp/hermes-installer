# 安装与分发（CDN 一行安装）

把 `neowow-canvas` skill 放上 CDN，让 Claude Code / Codex 用一行命令装好。

## 平台矩阵（scripts/ 各文件覆盖三平台）

| 脚本 | Windows | macOS | Linux | 说明 |
| --- | --- | --- | --- | --- |
| [install.ps1](./install.ps1) | ✅ 原生 | ✅ PowerShell 7 | ✅ PowerShell 7 | 安装器（Windows 用这个） |
| [install.sh](./install.sh) | ✅ Git Bash/WSL | ✅ 原生 | ✅ 原生 | 安装器（mac/Linux 用这个） |
| [neowow-upload.mjs](./neowow-upload.mjs) | ✅ | ✅ | ✅ | **跨平台**上传助手（Node，单文件三平台一致，推荐） |
| [neowow-upload.sh](./neowow-upload.sh) | ✅ Git Bash/WSL | ✅ | ✅ | 上传助手（纯 shell，无 Node 时用） |
| [pack.ps1](./pack.ps1) | ✅ 原生 | ✅ PowerShell 7 | ✅ PowerShell 7 | 打包发布包（Windows） |
| [pack.sh](./pack.sh) | ✅ Git Bash/WSL | ✅ 原生 | ✅ 原生 | 打包发布包（mac/Linux） |

> Windows 内置 PowerShell 即可跑 `install.ps1`；上传助手用 `.mjs`（Claude Code 本身依赖 Node，必然可用），避开 PowerShell 设置受限 `Date` 头的坑。

## 一、安装目标目录（自动发现，无需注册）

| 工具 | 个人级 | 项目级 |
| --- | --- | --- |
| Claude Code | `~/.claude/skills/neowow-canvas/` | `<项目>/.claude/skills/neowow-canvas/` |
| Codex | `~/.agents/skills/neowow-canvas/` | `<项目>/.agents/skills/neowow-canvas/` |

把 skill 内容（`SKILL.md` 在根）拷进上述任一目录即被发现。**目录名必须是 `neowow-canvas`**（决定 Claude Code 里 `/neowow-canvas` 命令名）。新建顶层 `skills` 目录后，Claude Code 需重启一次才会监听。

## 二、一行安装（终端用户）

CDN 地址已内置为 `https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/`（脚本里也已写死，见第四节）。命令可直接复制：

**macOS / Linux：**
```bash
curl -fsSL https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | bash                 # 装到 Claude Code（个人级）
curl -fsSL https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | bash -s -- --codex   # 装到 Codex
curl -fsSL https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | bash -s -- --all     # 两个都装
curl -fsSL https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | bash -s -- --project # 装到当前项目 ./.claude/skills
```

**Windows（PowerShell）：**
```powershell
irm https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.ps1 | iex                                            # Claude Code
& ([scriptblock]::Create((irm https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.ps1))) -Codex             # Codex
& ([scriptblock]::Create((irm https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.ps1))) -All               # 两个都装
```

安装器会下载 skill 包并解压到对应目录、校验 `SKILL.md` 存在。

## 三、安装后

1. **Claude Code**：重启一次（若是新建 skills 目录），输入 `/neowow-canvas` 应能调起；或直接说"用 neowow-canvas 技能…"。
2. **Codex**：装到 `~/.agents/skills/` 即可发现；或在项目 `AGENTS.md` 里加一行指向 `~/.agents/skills/neowow-canvas/SKILL.md`。
3. **登录**（API Key，一次）：用户在网页端「用户中心 → CLI」生成 Key，粘给 CLI：
   ```bash
   neowow login --api-key "<你的 Key>"  # 在线验证并存 ~/.neowow/config.json
   neowow whoami                       # 确认登录；neowow status 可离线自检
   ```
   也可不落盘：环境变量 `export NEOWOW_API_KEY=<key>`（Windows：`$env:NEOWOW_API_KEY='...'`）。`NEOWOW_BASE` 默认即正式环境 `https://neowow.cn`，换环境再覆盖。
   > 独立上传脚本 `neowow-upload.mjs` 也认 `NEOWOW_API_KEY`/`NEOWOW_BASE`（旧拼法 `API_KEY`/`BASE` 兼容）。
4. **后续更新不用重装**：CLI 每 24h 自动检查新版并在 stderr 提醒（`[update]` 行），执行 `neowow update` 一键升级（下载 + SHA-256 校验 + 换装，登录态不受影响）；详见 [../commands/update.md](../commands/update.md)。
5. **生产短剧**：见 [../examples/short-drama.md](../examples/short-drama.md)。

### 让 agent 自己装 / 自己跑

**适用边界先说清**：本 skill 面向**用户本机的 agent**（Claude Code 桌面/CLI/IDE 插件、Codex CLI）——它们有完整出网和持久文件系统。**云端沙盒 agent**（如网页版临时环境）出网走白名单代理、环境用完即弃，一行安装会被拦，属于预期外场景（见文末沙盒说明）。

本地 agent 自己跑需要过三关：

| 环节 | 情况 | 解法 |
| --- | --- | --- |
| 网络 | 本机不限出网 | 无需处理 |
| 执行权限 | Claude Code 对 Bash 命令逐条请求批准 | 用户点"允许"即可；想免批准，项目 `.claude/settings.json` 的 permissions.allow 加 `Bash(neowow *)` |
| 凭据 | API Key 须人参与一次（网页端生成并粘回） | agent 提示用户到网页端「用户中心 → CLI」生成 Key、用户粘回后执行 `neowow login --api-key <key>` 一步到位 |

**推荐话术（三档）**：

- **零上下文（对任何本地 agent 直接说）**：
  ```
  帮我安装 Neowow CLI Skill：https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/neowow-canvas-skill.zip
  ```
  zip 是自足安装入口：包根 `README.md` 写明了 Agent 安装步骤（解压 → `bash scripts/setup.sh` 落位+装命令 → 引导登录），agent 解压后照做即可，无需知道 install.sh 的存在。`setup.sh` 是「已解压包就地完成安装」脚本，与 install.sh 的区别是不下载、无 checksum（zip 本身经 HTTPS 获取）。

- **半自动（最稳）**——人花 2 分钟装好+登录，之后全部由 agent 驱动：
  ```
  终端：curl -fsSL <CDN>/install.sh | bash
        neowow login --api-key "<网页端「用户中心 → CLI」生成的 Key>"
  然后对 Claude Code 说：帮我用 neowow 画布做一个 10 秒介绍视频
  ```
- **全自动**——把安装命令和任务一起发给本地 Claude Code：它执行安装（弹一次 Bash 批准）、自动过 checksum 校验，登录时提示你到网页端生成 API Key、你粘回后继续。唯一绕不开人的就是生成并粘回 Key 那一下（凭据应由用户亲手交付，不应绕过）。

**零安装分发（对沙盒也生效）**：`--project` 模式把 skill 装进 `<项目>/.claude/skills/neowow-canvas` 并提交进 git——之后任何人/任何环境 clone 该仓库，agent 立即可用，无需联网安装。云端沙盒剩下的唯一障碍是运行时 API 出网：需平台白名单放行 `neowow.cn`（API）与 `wlpaas.oss-accelerate.aliyuncs.com`（上传直传），并以 secret 注入 `NEOWOW_API_KEY`；做不到就明确告知仅支持本地 agent。

## 四、发布到 CDN（你，分发者）

### 4.1 打包成发布包（推荐用 pack 脚本）

**传 CDN 的是「一个 zip 包」，不是把散文件夹整个传上去。** 用打包脚本一条命令生成 `dist/`（含 zip + 两个 install 脚本，自动以 skill 内容为根、排除 dist/.git/.DS_Store，并校验 `SKILL.md` 在 zip 根）：

```bash
./scripts/pack.sh        # 对外发布唯一入口（macOS/Linux）→ dist/{neowow-canvas-skill-<sha8>.zip, neowow-canvas-skill.zip, .tar.gz, install.sh, install.ps1}
```
```powershell
.\scripts\pack.ps1 -Dev   # ⚠ 仅 Windows 本机自测：不剔除内部文档、不混淆、不注 checksum/版本，禁止对外分发
```

> `dist/` 是构建产物，可随时删除/重新生成（若纳入 git 建议加进 `.gitignore`）。

**手动打包（不用脚本）** —— 务必以 skill 内容为根、并排除 `dist`：

```bash
cd neowow-canvas-skill && zip -rqX ../neowow-canvas-skill.zip . -x 'dist/*' '*/.DS_Store' && cd ..
```
```powershell
Remove-Item .\neowow-canvas-skill\dist -Recurse -Force -ErrorAction SilentlyContinue
Compress-Archive -Path .\neowow-canvas-skill\* -DestinationPath .\neowow-canvas-skill.zip -Force
```

> install.sh 与 install.ps1 **默认都取同一个 `neowow-canvas-skill.zip`**（install.sh 按扩展名自动选 `unzip`/`tar` 解压）。想用 tar.gz 也行（pack.sh 已顺带生成），让用户用 `NEOWOW_SKILL_URL=https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/neowow-canvas-skill.tar.gz` 覆盖。

> **能不能直接把散文件夹（每个文件一个对象）传 OSS？** 技术上可以，但 HTTP 没有"下载整个文件夹"——安装器得先维护一份全文件清单再逐个 `curl`，复杂且容易漏文件。**不推荐**，用单个 zip 最省事。（散文件适合"在线浏览/预览"，不适合一行安装。）

### 4.2 上传到 CDN

**按序**传到 CDN 目录 `https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/`（**公开可读**；顺序即原子性）：
1. `neowow-canvas-skill-<sha8>.zip` —— 内容寻址新对象，先传（不影响任何在途安装）；
2. `install.sh`、`install.ps1` —— 内置指向 ①，传完即切到新版；
3. `neowow-canvas-skill.zip`（稳定别名，「发 zip 链接给 agent」流程用）＋可选 `neowow-canvas-skill.tar.gz`。

> 旧的 `-<旧sha8>.zip` 留在桶里即免费回滚：`NEOWOW_SKILL_URL=<旧文件名地址>` 安装旧版。

> 地址已内置进 `install.sh`（`CDN_BASE`）和 `install.ps1`（`$cdnBase`）。如果以后换地址，改这两处或让用户用 `NEOWOW_CDN_BASE` 覆盖即可——无需改动 zip 内容。

**完整性校验（防包被换/损坏）**：`pack.sh` 会把 zip 的 SHA-256 注入 `dist/` 里的 `install.sh`/`install.ps1`（仓库源码保持空值），安装时下载 zip 后本地重算指纹比对，**不符即拒装**。两个要点：① install 脚本同时内置了**指纹**与**内容寻址文件名**（`-<sha8>.zip`），按上面顺序上传即可保证任意时刻脚本指向的都是与自己同批的 zip；② 用 `NEOWOW_SKILL_URL` 指定自定义来源（如 tar.gz / file://）时自动跳过校验——tar.gz 路径**无完整性校验**，只适合内网/离线；且 `install.ps1` 只解 zip，Windows 不支持 tar.gz。

> **安全边界说清楚**：CLI 的 esbuild 混淆只挡「扫一眼看到端点」，不防认真逆向、更不防篡改；checksum 与 zip 由同一 OSS 目录同通道下发（同源信任），**能防**批次错配/缓存偏斜/传输损坏/单文件被换，**不能防**拿到 OSS 写权限的攻击者。真正要守的是 **OSS 写凭证**。

**确保三件事**：
1. 文件在**同一目录** `…/agent/neowow-canvas/` 下，含版本化 zip（`neowow-canvas-skill-<sha8>.zip`，install 脚本实际取它）与稳定别名 zip。
2. 该目录**公开可读**（终端用户无鉴权即可 `curl` 到）。
3. `install.sh` / `install.ps1` 用合适的 `Content-Type`（如 `text/plain` 或 `application/x-sh`）和 zip 用 `application/zip`；别被网关当成需要登录的接口拦掉。

> ⚠️ 这是**分发 skill 文件**用的公开地址，和 仓库版 api 契约文档（发布包不含） 里**用户素材**的预签名私有桶是两回事，别混用。
> **为什么用 OSS 直连域名做分发入口**：直传直读、对象覆盖**即时生效**、零缓存坑。⚠️ 同一目录也能通过网关域名 `neoai-online.neodomain.cn/agent/neowow-canvas/` 访问，但该路径**有缓存**——已实测过发新版后网关仍返回旧 zip、且 install.sh 与 zip 缓存自不同批次（一行安装会报完整性校验失败）。**不要把网关域名当分发入口**，除非每次发版都刷新它的缓存。
> 上传后自验（应输出与本批 dist 一致的指纹）：
> ```bash
> curl -s https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/neowow-canvas-skill.zip | shasum -a 256
> curl -s https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.sh | grep EXPECTED_SHA256
> ```

**备选：GitHub Releases**
- 把 `neowow-canvas-skill.zip`（可选再加 tar.gz）作为 release 资产上传，`install.sh`/`install.ps1` 也作为资产或仓库 raw。
- `<CDN>` 用 `https://github.com/<user>/<repo>/releases/latest/download`（压缩包）；脚本本身用 `https://raw.githubusercontent.com/<user>/<repo>/<ref>/neowow-canvas-skill/scripts`。
- 注意 release 资产名要与脚本里取的文件名一致。

**备选：jsDelivr（套在 GitHub 上的免费 CDN）**
- `https://cdn.jsdelivr.net/gh/<user>/<repo>@<ref>/neowow-canvas-skill/scripts/install.sh` 等。

## 五、手动安装（不走 CDN）

直接拷目录即可：
```bash
cp -r neowow-canvas-skill ~/.claude/skills/neowow-canvas    # mac/Linux
```
```powershell
Copy-Item -Recurse .\neowow-canvas-skill "$env:USERPROFILE\.claude\skills\neowow-canvas"  # Windows
```

## 六、升级与卸载

**升级 = 重跑一行安装**：安装脚本是干净替换（旧文件不残留），装完 `neowow --version` 或看 `<安装目录>/.install-meta` 确认批次。

**卸载**（skill 目录 + `neowow` 命令 + 登录凭据三部分）：

```bash
rm -rf ~/.claude/skills/neowow-canvas ~/.agents/skills/neowow-canvas   # ① skill 本体
rm -rf ~/.neowow                       # ② neowow wrapper（~/.neowow/bin）与登录凭据 config.json 一起删
# ③ shell profile（~/.zshrc 或 ~/.bashrc）里删掉 "# neowow-cli: PATH (install.sh)" 标记行及其下一行
# ④ 各项目目录下如跑过 project use，另有 .neowow/project.json 绑定文件，可按需删
```
```powershell
Remove-Item -Recurse -Force "$env:USERPROFILE\.claude\skills\neowow-canvas","$env:USERPROFILE\.agents\skills\neowow-canvas" -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "$env:USERPROFILE\.neowow" -ErrorAction SilentlyContinue   # wrapper + 凭据
# 用户 PATH 里如加过 %USERPROFILE%\.neowow\bin，到「编辑环境变量」里移除
```
