<#
  setup.ps1 —— 把「已解压的 skill 包」就地落位（Windows）。
  与 install.ps1 的区别：不下载，从当前包位置拷贝——供 agent 拿到 zip 自行安装时用。
  用法：powershell -ExecutionPolicy Bypass -File scripts\setup.ps1 [-Codex|-All|-Project]
  落位后调用 CLI：node "$env:USERPROFILE\.claude\skills\neowow-canvas\bin\neowow.mjs" --help
#>
param(
  [switch]$Codex,
  [switch]$Project,
  [switch]$All
)
$ErrorActionPreference = 'Stop'
$name = 'neowow-canvas'
$src = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
if (-not (Test-Path (Join-Path $src 'SKILL.md'))) { Write-Error "$src 不是 skill 包根（缺 SKILL.md）" }

$targets = @()
if ($All)         { $targets += "$env:USERPROFILE\.claude\skills\$name"; $targets += "$env:USERPROFILE\.agents\skills\$name" }
elseif ($Codex)   { $targets += "$env:USERPROFILE\.agents\skills\$name" }
elseif ($Project) { $targets += (Join-Path (Get-Location) ".claude\skills\$name") }
else              { $targets += "$env:USERPROFILE\.claude\skills\$name" }

foreach ($t in $targets) {
  New-Item -ItemType Directory -Force -Path $t | Out-Null
  if ((Resolve-Path $src).Path -eq (Resolve-Path $t).Path) {
    Write-Host "✓ 包已在目标位置 $t，跳过拷贝"
  } else {
    Copy-Item -Path (Join-Path $src '*') -Destination $t -Recurse -Force -Exclude '.neowow','dist','.DS_Store'
    Write-Host "✓ 已安装到 $t"
  }
}

Write-Host ""
Write-Host "完成。Claude Code 输入 /$name 调用（新建 skills 目录需重启一次 Claude Code）。"
Write-Host "CLI 调用：node `"$($targets[0])\bin\neowow.mjs`" --help"
Write-Host "首次使用先设置 API Key（网页端「用户中心 → CLI」生成）：node ...neowow.mjs login --api-key `"<key>`""
