<#
  install.ps1 —— 一行安装 neowow-canvas skill 到 Claude Code / Codex（Windows）。

  一行安装（CDN 地址已内置为 https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas；如需更换见 install.md）：
    irm https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.ps1 | iex
    # 带参数（装给 Codex / 全装 / 装到项目）：
    & ([scriptblock]::Create((irm https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.ps1))) -Codex
    & ([scriptblock]::Create((irm https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.ps1))) -All
    & ([scriptblock]::Create((irm https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.ps1))) -Project

  也可指定来源：$env:NEOWOW_CDN_BASE='https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas'; irm https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas/install.ps1 | iex
#>
param(
  [switch]$Codex,
  [switch]$Project,
  [switch]$All
)
$ErrorActionPreference = 'Stop'
$name = 'neowow-canvas'

# 发布时把默认值改成你的 CDN 目录，或用环境变量 NEOWOW_CDN_BASE 覆盖。
$cdnBase = if ($env:NEOWOW_CDN_BASE) { $env:NEOWOW_CDN_BASE } else { 'https://wlpaas.oss-cn-shanghai.aliyuncs.com/agent/neowow-canvas' }
# 发布时 pack.sh 注入内容寻址文件名（与本脚本同批的 zip），杜绝 CDN 上批次错配
$versionedZip = '' # NEOWOW_PACK_INJECT_ZIPNAME
$zipName = if ($versionedZip) { $versionedZip } else { 'neowow-canvas-skill.zip' }
$zipUrl  = if ($env:NEOWOW_SKILL_URL) { $env:NEOWOW_SKILL_URL } else { "$cdnBase/$zipName" }

if ($zipUrl -like '*YOUR-CDN.example.com*') {
  Write-Error "还没设置 CDN 地址。请设置 `$env:NEOWOW_CDN_BASE=<你的CDN目录>，或编辑本脚本。详见 install.md"
}

# 目标目录
$targets = @()
if ($All)          { $targets += "$env:USERPROFILE\.claude\skills\$name"; $targets += "$env:USERPROFILE\.agents\skills\$name" }
elseif ($Codex)    { $targets += "$env:USERPROFILE\.agents\skills\$name" }
elseif ($Project)  { $targets += (Join-Path (Get-Location) ".claude\skills\$name") }
else               { $targets += "$env:USERPROFILE\.claude\skills\$name" }

# 发布包完整性校验：pack.sh 打包时注入 zip 的 SHA-256（仓库源码中为空=跳过）
$expectedSha256 = '' # NEOWOW_PACK_INJECT_SHA256

$tmp = Join-Path $env:TEMP ("neowow-canvas-" + [Guid]::NewGuid().ToString() + ".zip")
Write-Host "↓ 下载 $zipUrl"
Invoke-WebRequest -Uri $zipUrl -OutFile $tmp

# 无论是否校验都先算指纹（校验用 + 落 .install-meta 供日后对批次）
$actual = (Get-FileHash -Path $tmp -Algorithm SHA256).Hash.ToLower()

if ($expectedSha256) {
  if ($env:NEOWOW_SKILL_URL) {
    Write-Host "… 自定义来源（NEOWOW_SKILL_URL），内置 checksum 只对应默认 zip，跳过校验"
  } else {
    if ($actual -ne $expectedSha256.ToLower()) {
      Remove-Item $tmp -ErrorAction SilentlyContinue
      Write-Error "完整性校验失败，拒绝安装！期望 $expectedSha256，实际 $actual。可能原因：CDN 上 zip 与 install.ps1 不是同一批（发版后必须一起传）/ 缓存未刷新 / 传输损坏 / 被篡改。"
    }
    Write-Host "✓ 完整性校验通过（SHA-256）"
  }
}

# 先解压到临时目录校验，再干净替换目标——直接覆盖解压会让旧版删掉/改名的文件残留
$extracted = Join-Path $env:TEMP ("neowow-canvas-extract-" + [Guid]::NewGuid().ToString())
New-Item -ItemType Directory -Force -Path $extracted | Out-Null
Expand-Archive -Path $tmp -DestinationPath $extracted -Force
if (-not (Test-Path (Join-Path $extracted 'SKILL.md'))) {
  Remove-Item $tmp -ErrorAction SilentlyContinue
  Remove-Item $extracted -Recurse -Force -ErrorAction SilentlyContinue
  Write-Error "包内缺少 SKILL.md，请检查 zip 是否以 skill 内容为根（见 install.md 打包说明）"
}

foreach ($t in $targets) {
  # 防误删：目标已存在、非空、又不像本 skill 的安装目录（无 SKILL.md）时拒绝清空
  if ((Test-Path $t) -and -not (Test-Path (Join-Path $t 'SKILL.md')) -and (Get-ChildItem -LiteralPath $t -Force -ErrorAction SilentlyContinue | Select-Object -First 1)) {
    Write-Error "$t 已存在且不像本 skill 的安装目录（无 SKILL.md），为防误删不清空。请确认后手动移走再装。"
  }
  if (Test-Path $t) { Remove-Item $t -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $t | Out-Null
  Copy-Item -Path (Join-Path $extracted '*') -Destination $t -Recurse -Force
  $buildFile = Join-Path $t 'VERSION'
  $build = if (Test-Path $buildFile) { (Get-Content $buildFile -First 1).Trim() } else { 'unknown' }
  @(
    "build=$build"
    "zipSha256=$actual"
    "source=$zipUrl"
    "installedAt=$((Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ'))"
  ) | Set-Content -Path (Join-Path $t '.install-meta')
  Write-Host "✓ 已安装到 $t（干净替换，旧文件不残留）"
}
Remove-Item $tmp -ErrorAction SilentlyContinue
Remove-Item $extracted -Recurse -Force -ErrorAction SilentlyContinue

# 装 neowow 命令（镜像 install.sh 的 wrapper 行为；-Project 模式不装全局命令）
if (-not $Project) {
  $cliSrc = Join-Path $targets[0] 'bin\neowow.mjs'
  if (Test-Path $cliSrc) {
    if (Get-Command node -ErrorAction SilentlyContinue) {
      $binDir = Join-Path $env:USERPROFILE '.neowow\bin'
      New-Item -ItemType Directory -Force -Path $binDir | Out-Null
      Set-Content -Path (Join-Path $binDir 'neowow.cmd') -Value "@echo off`r`nnode `"$cliSrc`" %*" -Encoding ASCII
      Write-Host "✓ 已安装 neowow 命令 → $binDir\neowow.cmd"
      $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
      if (-not $userPath) { $userPath = '' }
      if (($userPath -split ';') -notcontains $binDir) {
        [Environment]::SetEnvironmentVariable('Path', ($binDir + ';' + $userPath), 'User')
        Write-Host "✓ 已把 $binDir 加入用户 PATH（新开终端生效）"
      } else {
        Write-Host "✓ $binDir 已在用户 PATH"
      }
    } else {
      Write-Host "⚠ 未找到 node：neowow CLI 需要 Node ≥18。装好后可直接用：node `"$cliSrc`" --help"
    }
  }
}

Write-Host ""
if ($Codex)     { Write-Host "完成。Codex：已装到 ~/.agents/skills/$name/。若 Codex 不自动发现 skills，在项目 AGENTS.md 里指向该 SKILL.md（见 install.md）。" }
elseif ($All)   { Write-Host "完成。Claude Code 输入 /$name 调用；Codex 见 install.md（必要时在 AGENTS.md 指向 SKILL.md）。新建 skills 目录需重启一次 Claude Code。" }
elseif ($Project) { Write-Host "完成。Claude Code 输入 /$name 调用（新建 skills 目录需重启一次 Claude Code）。CLI 用：node .\.claude\skills\$name\bin\neowow.mjs --help" }
else            { Write-Host "完成。Claude Code 里输入 /$name 即可调用（新建的 skills 目录需重启 Claude Code 才会被监听）。" }
Write-Host ""
Write-Host "使用前先设置 API Key（网页端「用户中心 → CLI」生成）："
Write-Host "  neowow login --api-key '<你的 Key>'    # 保存并在线验证，存 ~/.neowow/config.json"
Write-Host "  neowow whoami                         # 确认登录"
Write-Host "（也可不落盘：`$env:NEOWOW_API_KEY='<key>'；NEOWOW_BASE 默认正式环境 https://neowow.cn）"
Write-Host "短剧用法见该 skill 的 examples/short-drama.md。"
