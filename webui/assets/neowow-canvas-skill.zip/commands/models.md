# `neowow models` — 列出画布可用的图片 / 视频生成模型与音色

`models` 在提交生成（`gen`）前先把可用模型/音色与其参数枚举拉下来，让你知道 `--model`（图片/视频）或 `--sound`（音频）该填什么、支持哪些长宽比/分辨率/生成类型。三个子命令：`models image`（画布图片模型）、`models video`（画布视频模型，级联结构；加 `--universal` / `--extend` / `--edit` 分别拉全能参考 / 视频延长 / 视频编辑模式的专属列表）、`models voice`（语音音色，供 `gen audio --sound`）。都是只读 `GET`，不依赖项目作用域（不需要 `-p/--project`），但需要先登录（token 决定端点是否走 `/byLogin` 变体并返回更完整的可用模型，见 [./login.md](./login.md)）。

> 入口与全局约定（输出契约、鉴权、环境变量）见 [./project.md](./project.md) 顶部说明，本篇不复述。
> 本文件即完整选项真源；速查用 `neowow models --help`（离线，不发请求）。仓库版另有 `lib/models.mjs` 源码与 api/ 端点契约，发布包不含。

**输出默认是精简投影（slim）**：原始 payload 很大（视频级联 ~88KB、音色 ~56KB），默认只保留选型必需字段并带 `slim:true` 与 `count`；加 **`--full`** 返回后端原样数据（计价矩阵、会员档、素材约束、音色试听 `audioUrl` 等在 full 里）。

默认参数：**图片用 `scenarioType=1`（图片工具全量列表——画布 UI 的 scenario 2 只是过滤子集，后端提交不按场景硬校验，全量列表里的模型画布节点都能用）**，**视频用 `requestType=2`（画布）**，一般无需手动指定。token 存在时端点自动切到 `/byLogin` 变体。

## 子命令
| 子命令 | 作用 |
| --- | --- |
| `neowow models image` | 拉图片模型全量列表（`scenarioType=1`），取每项的 `model_name` 当作 `gen image --model` 的值 |
| `neowow models video` | 拉画布视频模型（`requestType=2`，级联结构），取每项的 `value` 当作 `gen video --model` 的值 |
| `neowow models video --universal` | 拉**全能（universal）模式**专属模型列表（独立端点，`gen video --universal` 选模型用这个） |
| `neowow models video --extend` | 拉**视频延长**模式专属模型列表（独立端点 `…/models/extend`，`requestType=1`；`gen video --extend` 选模型用这个） |
| `neowow models video --edit` | 拉**视频编辑**模式专属模型列表（独立端点 `…/models/editing`，`requestType=2`；`gen video --edit` 选模型用这个） |
| `neowow models voice` | 拉语音音色列表，取每项的 `id` 当作 `gen audio --sound` 的值（可按 `--language`/`--sex` 过滤） |

### `neowow models image [flags]`

GET `/agent/ai-image-generation/models/by-scenario[/byLogin]?scenarioType=<n>`。返回放在输出的 `models` 字段里，模型机器名在 `model_name`（如 `gemini-2.5-flash-image`、`gemini-3-pro-image-preview`）。

**选项**
| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--scenarioType <n>` | 否 | 场景类型，默认 `1`（图片工具，全量）。其它取值：`2` 画布 UI 子集 / `3` 重绘 / `4` 设计 / `5` 分镜。 |
| `--scenario <n>` | 否 | `--scenarioType` 的同义写法。 |
| `--full` | 否 | 返回后端原样数据（含计价/会员档等全部字段） |

**输出**：stdout 单行 JSON，含 `kind`（固定 `"image"`）/ `scenarioType` / `count` / `models`。默认 slim 每项保留：`model_name` / `model_display_name` / `model_description` / `max_reference_images` / `supported_sizes` / `supported_aspect_ratios` / `quality`（质量档枚举）/ 计价字段（`points_cost_per_image` 兜底基础价、`size_pricing_config` 计价矩阵——已解析成对象、`points_cost_per_reference_image` / `free_reference_image_count` / `reference_image_billing_mode` 参考图超额费）/ `membership_required` / `maintenance`。

> ⚠️ **`points_cost_per_image` 不是实际单价**：带尺寸/质量档时单价来自 `size_pricing_config`，匹配顺序 `quality_size` 组合键（如 `medium_2k`）> `size` 键 > 基础价兜底。给用户报积分用 `gen image --dry-run` 输出的 `estimate`（CLI 已按网页端口径算好），不要自己从列表心算。

`gen image` 的 `--model` 取这里某项的 **`model_name`**。例如 `gemini-2.5-flash-image` 是默认分镜模型，仅支持 size `1K`、长宽比含 `16:9`。✅ 提交前先 `models image` 核对该模型支持的 `--ar` / `--size`，避免参数被拒。

### `neowow models video [flags]`

GET `/agent/user/video/models/cascading/v2[/byLogin]?requestType=<n>`。返回的视频模型是**级联结构**：顶层 `model_name` 多为 `null`，真正的模型 id 在每项的 **`value`**（如 `doubao-seedance-1-0-pro-fast-251015`、`kling-v3`）。

**选项**
| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--requestType <n>` | 否 | 请求类型，默认 `2`（画布）。其它取值：`1` 图片工具。 |
| `--request <n>` | 否 | `--requestType` 的同义写法（源码里 `args.requestType \|\| args.request \|\| '2'`）。 |
| `--universal` | 否 | **全能模式模型走独立端点**：GET `/agent/user/video/models/universal[/byLogin]?requestType=<n>`（网页端 universal tab 同源端点，`creation.js` `getUniversalVideoModels`）。含 universal 专属的时长范围/计价/`supportAudioGeneration` 配置。⚠️ 从级联列表里挑 `isUniversalModel=true` **不等价**——级联项缺这些 universal 专属配置。 |
| `--extend` | 否 | **视频延长模型走独立端点**：GET `/agent/user/video/models/extend[/byLogin]?requestType=<n>`（`creation.js` `getVideoExtendModels`，网页端 ExtendSection 同源；`requestType` 缺省 `1`，镜像网页端实际调用）。与 `--universal`/`--edit` 互斥。 |
| `--edit` | 否 | **视频编辑模型走独立端点**：GET `/agent/user/video/models/editing?requestType=<n>`（`creation.js` `getVideoEditingModels`，网页端 EditingSection 同源；`requestType` 缺省 `2`；该端点**无 `/byLogin` 变体**）。与 `--universal`/`--extend` 互斥。 |

**输出**：stdout 单行 JSON，含 `kind`（固定 `"video"`）/ `requestType` / `count` / `models`（模型 id 在每项 `value`）；带 `--universal` 时另含 `universal: true`，带 `--extend`/`--edit` 时另含 `mode: "extend"|"edit"`。默认 slim：级联版每项保留 `value`/`name`/`tags`/`supportAudio`/`supportAudioUpload`/`supportFirstLastFrame`/`supportReferenceToVideo(Size)`/`durationRange`/`membershipRequired`/`isUniversalModel`/**`supportDraft`**（`true` 才能用 `gen video --draft` 草稿开关）+ `generationTypes`（每项 `value`/`name`/`resolutions` 值数组/`aspectRatios` 并集）；**样片模型**（`value` 以 `-draft` 结尾 / 显示名含「样片」，如 `doubao-seedance-2-5-260628-draft`）另派生 **`draftModel:true`** + **`formalModel`**（去掉后缀的正式模型 value）——选它生成的都是草稿（样片），完成后 `gen formal` 转正式；四个列表（级联/universal/extend/edit）都带这两个派生位。universal / extend / edit 三个模式端点同构，每项保留 `value`/`name`/`description`/`tags`/`durationRange`/`membershipRequired`/**`refVideoBilling`**（`1`=带参考视频时参考视频时长计入计费，`gen` 的 `--total-duration` 只对它生效）/**`generationType`**（`generationTypes[0].value`，即提交体 `generationType` 的取值：延长通常 `EXTEND_TO_VIDEO`、编辑 `VIDEO_TO_VIDEO`）/`resolutions` + `featureConfig` 关键位（`supportAudioGeneration`/`supportFirstLastFrame`/`supportReferenceAudio`/`supportAudioUpload`/`maxReference*`/**`comboLimits`** 参考素材组合上限）。计价矩阵在 `--full` 里。

❌ 视频模型不要取 `model_name`（顶层为 null）；✅ 取 `value` 传给 `gen video --model`。全能模式（`gen video --universal`）选模型用 `models video --universal` 的返回；延长 / 编辑模式分别用 `--extend` / `--edit` 的返回（三个列表不通用——延长/编辑模型不一定在全能列表里，反之亦然）。

### `neowow models voice [flags]`

GET `/agent/v1/sound/list?language=&sex=&type=1`。返回音色数组，每项含 `id`（**这就是 `gen audio --sound` 要的 soundId**，数字）/ `name`（如 `男性-青年-阿诺德`）/ `sex`（`1` 男 / `2` 女）/ `language`（如 `zh_CN`）/ `languageName` / `supplier`（如 `minimax`）/ `audioUrl`（试听，仅 `--full`）。共约 195 个，建议用 `--sex`/`--language` 过滤或 `jq` 挑选。

**选项**
| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--sex <n>` | 否 | 性别过滤，`1` 男 / `2` 女。默认不过滤（空） |
| `--language <lang>` | 否 | 语言过滤，如 `zh_CN`。默认不过滤（空） |
| `--type <n>` | 否 | 音色类型，默认 `1` |

**输出**：stdout 单行 JSON，含 `kind`（固定 `"voice"`）/ `count`（音色数）/ `voices`（soundId 在每项 `id`）。默认 slim 每项保留 `id`/`name`/`languageName`/`sex`/`supplier`/`type`；试听 `audioUrl` 等在 `--full` 里。

✅ `gen audio` 的 `--sound` 取这里某项的 **`id`**（数字，如 `329`）；CLI 会原样提交，后端接受。

## 示例
```bash
# case 1: 最简 —— 列图片模型全量列表（scenarioType 默认 1）
neowow models image

# case 2: 列画布视频模型（requestType 默认 2）
neowow models video

# case 3: 只取图片模型机器名（配合 jq）
neowow models image | jq -r '.models[].model_name'

# case 4: 取视频模型 id（级联结构，id 在 value）
neowow models video | jq -r '.models[].value'

# case 5: 换场景 —— 只看画布 UI 展示的子集（scenarioType=2）
neowow models image --scenario 2

# case 5b: 拉全能（universal）模式专属模型列表（gen video --universal 用）
neowow models video --universal | jq -r '.models[].value'

# case 5c: 拉视频延长 / 视频编辑模型（gen video --extend / --edit 用），顺手看 refVideoBilling 与 generationType
neowow models video --extend | jq -r '.models[] | [.value, .generationType, .refVideoBilling] | @tsv'
neowow models video --edit | jq -r '.models[].value'

# case 5d: 找样片模型（出草稿便宜、满意后 gen formal 转正式）与可开草稿开关的模型
neowow models video | jq -r '.models[] | select(.draftModel==true) | [.value, .formalModel] | @tsv'
neowow models video | jq -r '.models[] | select(.supportDraft==true) | .value'

# case 6: 串起来 —— 拿到模型名后直接提交画布图片生成（仓库版 api 契约文档（发布包不含））
M=$(neowow models image | jq -r '.models[] | select(.model_name=="gemini-2.5-flash-image") | .model_name')
neowow gen image --node <nodeKey> \
  --prompt "赛博朋克猫，霓虹灯，雨夜街头，电影感" \
  --model "$M" --ar 16:9 --size 1K --n 1 --wait

# case 7: 列男声音色，取第一个 id 作 gen audio 的 --sound（音频自洽，无需网页端）
SND=$(neowow models voice --sex 1 | jq -r '.voices[0].id')
neowow gen audio --node <nodeKey> --sound "$SND" --text "那一夜，雨没有停。" --wait
```

> `gen` 的提交→轮询→回填阶段（含 `--wait` 的 submit→回填 PENDING→轮询→回填终态）见 [./gen.md](./gen.md) 与 仓库版 api 契约文档（发布包不含）。
