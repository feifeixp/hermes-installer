# `neowow login` — API Key 登录、查当前用户、登出

`login` / `whoami` / `logout` 三个顶层命令共同管理 NeoWoW 画布的本地凭据（都在 `lib/auth.mjs`）。核心是 **API Key**：用户在网页端「用户中心 → CLI」生成一把 Key → `neowow login --api-key <key>` 保存到 `~/.neowow/config.json`（权限 0600）→ 之后每个请求自动带 `api-key` 头，可直接驱动 `/agent/story-canvas/*` 与 `/user/*`。

登录是除自身外所有命令的前置：Key 存在 `~/.neowow/config.json`（或环境变量 `NEOWOW_API_KEY`），鉴权头是字面 `api-key`（非 `Authorization`/`Bearer`，也不是旧版的 `accessToken`）。每个账号同一时间仅有一把有效 Key，网页端重新生成会使旧 Key 立即失效（CLI 表现为 `errCode=2001`，重新 login 即可）。`whoami` 查当前用户资料，`logout` 删除本地凭据（幂等）。

> 入口统一写 `neowow <command>`（实为 `node bin/neowow.mjs <command>`，安装后可直接 `neowow`）。成功 → stdout 单行 JSON、exit 0；进度/错误 → stderr（前缀 `[login]`）、exit 非 0。
> 本文件即完整选项真源；速查用 `neowow login --help`（离线，不发请求）。仓库版另有 `lib/auth.mjs` 源码与 api/ 端点契约，发布包不含。

## 子命令

| 子命令 | 作用 |
| --- | --- |
| `neowow login` | 无参：TTY 下交互式提示输入 API Key；非 TTY（agent 管道）打印引导并返回 `step:"need-key"` |
| `neowow login --api-key <key>` | 直接保存 API Key（`--key` 同义） |
| `neowow whoami` | 打印当前登录用户资料（`GET /user/profile`） |
| `neowow logout` | 清空本地保存的 API Key（幂等；Key 本身不失效，作废需网页端重新生成） |

---

### `neowow login [flags]`

保存前会先用该 Key 调一次 `GET /user/profile` **在线验证**：Key 无效当场报错（`errCode=2001`，exit 3）且**不落盘**，不会把坏 Key 留到下一条命令才暴露。验证通过后把 `base` / `apiKey` / `userId` / `nickname` 一并写盘，并顺手清掉旧 OAuth 时代的 `accessToken` 等字段。

**Key 从哪来**：网页端 → 右上角头像 → 用户中心 → 左侧「CLI」→「生成 / 更换 Key」。Key 仅在生成时完整展示一次，请当场复制。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--api-key <key>` | 否 | 要保存的 API Key（`--key` 同义）。缺省且在 TTY 下则交互式提示输入 |
| `--base <url>` | 否 | 覆盖 base URL。默认取 `NEOWOW_BASE` → config → 正式环境 `https://neowow.cn` |

**输出**：stdout 单行 JSON，按模式不同——

- 有 Key（`step: "key"`）：含 `step` / `apiKey`（已打码，形如 `abc123…wxyz`）/ `userId` / `nickname` / `configPath`。
- 无 Key 且非 TTY（`step: "need-key"`）：含 `step` / `next`（下一步命令提示）。同时 stderr 打印两行 `[login]` 引导，agent 应把生成 Key 的路径转告用户。

> stdout 里的 `apiKey` 始终是**打码**值（前 6 + … + 后 4），真实 Key 只写进 `configPath` 指向的 `~/.neowow/config.json`。

---

### `neowow whoami`

打印当前登录用户资料。需先登录：无 Key 时直接报错（`errCode=2001` 未登录），exit 3。

**选项**：无。

**输出**：stdout 单行 JSON，即 `GET /user/profile` 的内层 `data`，含 `userId` / `nickname` / `points` 等用户字段（具体字段由后端返回，原样透传）。

---

### `neowow logout`

清空 `~/.neowow/config.json` 里本地保存的 API Key（连同随之落盘的 `userId`/`nickname`；`base` 等非凭据配置保留）。幂等：即使未登录也正常 exit 0。若设置了 `NEOWOW_API_KEY` 环境变量，logout 不影响它（stderr 会提醒）。

> API Key 没有服务端会话可注销：logout 只清本地。要让 Key 本身作废，去网页端「用户中心 → CLI」重新生成一把（旧 Key 立即失效）。

**选项**：无。

**输出**：stdout 单行 JSON，含 `loggedOut`（固定 `true`）/ `hadKey`（清之前本地是否有 Key）/ `clearedKey`（本次是否真的清掉了 Key）/ `configPath`（配置文件绝对路径）。

---

## 示例

```bash
# case 1: 直接带 Key 登录（agent 场景推荐：把 Key 问用户要来后执行这条）
neowow login --api-key "<你的 API Key>"
# stdout:
#   {"step":"key","apiKey":"abc123…wxyz","userId":"...","nickname":"...","configPath":"/Users/you/.neowow/config.json"}

# case 2: 无参 —— TTY 下交互式输入（提示打到 stderr，输入不回显进 stdout JSON）
neowow login
# stderr: 请输入 API Key（网页端「用户中心 → CLI」里生成）:

# case 3: 无参且非 TTY（agent 管道）—— 返回引导，转告用户去网页端生成 Key
echo | neowow login
# stdout: {"step":"need-key","next":"neowow login --api-key \"<key>\""}

# case 4: 指向别的 base（默认即正式环境 https://neowow.cn，一般无需指定）
neowow login --api-key "<你的 API Key>" --base https://<其他环境域名>

# case 5: 查当前用户（需先登录）
neowow whoami
# stdout: {"userId":"...","nickname":"...","points":123, ...}

# case 6: 临时用环境变量 Key，不落盘，直接 whoami
NEOWOW_API_KEY="<你的 API Key>" neowow whoami

# case 7: 清空本地保存的 API Key（幂等，未登录也 exit 0；base 等配置保留）
neowow logout
# stdout:
#   {"loggedOut":true,"hadKey":true,"clearedKey":true,"configPath":"/Users/you/.neowow/config.json"}
```

> 登录成功后即可创建项目并生成：见 [./project.md](./project.md)、仓库版 api 契约文档（发布包不含）、仓库版 api 契约文档（发布包不含）。
