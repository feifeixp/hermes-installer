# `neowow gen` / `neowow poll` — 画布生成（图/视/音/乐/词/文）与任务轮询

入口与全局约定（输出契约、鉴权、项目作用域、环境变量）见 [./project.md](./project.md) 顶部说明，本篇不复述；本组命令的 stderr 前缀是 `[gen]` / `[poll]`。

`neowow gen` 把「画布生成」收敛成一条命令。**画布生成全是异步**（唯一例外是歌词）：先有一个已创建的画布节点（节点 id 即生成请求里的 `nodeKey`），`gen` 负责 ①提交对应 `generate-*` 端点拿 `taskId` → ②立刻把「生成中」状态 + 提示词/模型/设置回填进节点 `data`（image/video/text 写 `PENDING`；audio/music 写 `running`，见下「状态词表分家」）→ ③加 `--wait` 时轮询到终态，再把结果 URL 回填进节点。不加 `--wait` 只做①②、返回生成中状态即退出，后续可用 `neowow poll` 接着轮。前置：需要一个节点，建节点见 [./node.md](./node.md)；模型机器名先用 [./models.md](./models.md) 发现。

> 本文件即完整选项真源；速查用 `neowow gen --help`（离线，不发请求）。仓库版另有 `lib/generate.mjs` 源码与 api/ 端点契约，发布包不含。

## 子命令

| 子命令 | 作用 |
| --- | --- |
| `neowow gen image ...` | 文/图生图，提交 `generate-image`，结果回填 `inputImageUrls` |
| `neowow gen video ...` | 文/图生视频（首尾帧 / 多图参考 / 全能参考 / **视频延长** / **视频编辑** 五种模式），提交 `generate-video`，结果回填 `inputVideoUrls` |
| `neowow gen audio ...` | 语音合成**双引擎**：默认 minimax v1 提交 `generate-audio`；`--engine seed` 或带 `--ref-audio`/`--ref-image` 走 `generate-audio-v2`（seed-audio-1.0）。结果回填 `inputAudioUrls` |
| `neowow gen music ...` | 音乐生成，提交 `generate-music`，结果回填 `inputAudioUrls` |
| `neowow gen lyrics ...` | 歌词生成，提交 `generate-lyrics`，**同步返回、不轮询**；可选 `--node` 把结果按音乐面板键回填 |
| `neowow gen text ...` | 文本生成（text 节点跑 LLM），提交 `generate-text`，结果回填 `result` |
| `neowow gen formal ...` | **草稿（样片）视频转正式**：核对草稿 → 预估积分 → 在草稿节点右侧新建「正式视频」节点并连线 → 提交 `draft-to-formal`，结果回填新节点 `inputVideoUrls` |
| `neowow gen history <nodeKey>` | **节点生成历史**（网页端「历史生成」弹框同源，只读免费）：该节点每次提交的 `taskId`/状态/模型/prompt/结果 URL |
| `neowow poll <taskId>...` | 对已有 taskId 批量轮询 `batch-query-status` 到终态；`--apply` 把终态回填进节点（等价 `gen --wait` 的最后一步） |

## `--wait` 四阶段状态机

`gen image/video/audio/music/text` 都走同一条状态机。`--wait` 控制是否走到阶段 3–4；不加则止于阶段 2。

| 阶段 | 动作 | 节点 `data` 写入 | 何时发生 |
| --- | --- | --- | --- |
| 1. submit | `POST /agent/story-canvas/generate-*` 拿 `taskId` | — | 总是 |
| 2. 回填生成中 | `batch-operation` update 节点 | image/video：`status:'PENDING'` + `taskId` + `prompt` + `model`/`modelName` + 各设置 + `createdAt`；text：`status:'PENDING'` + `isGenerating:true` + `taskId` + `prompt`；audio/music：`status:'running'` + `generationStartTime` + `taskId` + 各面板键 + `createdAt` | 总是（提交成功后立刻） |
| 3. 轮询 | `POST /agent/story-canvas/batch-query-status` 直到 `SUCCESS`/`FAILED`（wire 层词表统一大写） | — | 仅 `--wait` |
| 4. 回填终态 | `batch-operation` update 节点 | 按节点类型分家，见下表 | 仅 `--wait` |

### 状态词表按节点类型分家（回填层）

轮询接口（wire 层）统一 `PENDING → SUCCESS/FAILED`，但**写回节点 `data.status` 的词表按前端节点组件分家**：

- **image / video / text 节点**：`PENDING → SUCCESS / FAILED`（大写）。
- **audio 节点（语音/音乐共用）**：`running → SUCCESS / error`——`AudioGenerationNode` 的 `isGenerating` 只认 `'running'`、`isFailed` 只认小写 `'error'`，写 `PENDING`/`FAILED` 画布不显示生成动画/失败卡片。提交回填同时带 `generationStartTime`。

各子类型的终态回填（**所有类型失败态一律不清已有媒体结果**，前端注释明说「保留，勿清空」）：

| 子类型 | 生成中 `status` | `SUCCESS` 回填 | 失败回填 | `dataField` |
| --- | --- | --- | --- | --- |
| image | `PENDING` | `status:'SUCCESS'` + `inputImageUrls` | `status:'FAILED'` + `errorMessage` | `inputImageUrls` |
| video | `PENDING` | `status:'SUCCESS'` + `inputVideoUrls` + `mediaSource:'generated'` | `status:'FAILED'` + `errorMessage` | `inputVideoUrls` |
| audio / music | `running` | `status:'SUCCESS'` + `taskId:null` + `inputAudioUrls`（`resultData` 兼容数组与 `{audioUrl}` 对象两种形状） | `status:'error'` + `error`/`errorMessage`；**保留 `taskId`**（失败卡片展示用）、不清 `inputAudioUrls` | `inputAudioUrls` |
| text | `PENDING`（+`isGenerating:true`） | `result` = `resultData.join('\n\n')` + `status:'SUCCESS'` + `isGenerating:false` + `taskId:null` | `status:'FAILED'` + `isGenerating:false` + `errorMessage` + `taskId:null` | `result` |

回填只告警不抛错：生成本身已成功，找不到节点/写回失败只在 stderr 打 `[gen]` 警告，不影响 stdout 结果。`lyrics` 同步返回、无 taskId、不经此状态机（可选 `--node` 回填见其小节）。注意带 `--wait` 时 stdout 的 `status` 是**轮询词表**（`SUCCESS`/`FAILED`），节点 `data.status` 才按上表分家；stdout 另带**归一化 `phase` 字段**（`submitted`/`success`/`failed`），agent 不想记两套词表就看它。⚠️ 任务生成失败（FAILED）时 `gen --wait` 仍 exit 0——判断成败要解析 `status`/`phase`，别只看退出码。

> 不加 `--wait` 时节点会停在 `PENDING`/`running`（阶段 4 没人做），直到网页端打开该画布恢复轮询才更新——CLI 侧用 **`neowow poll <taskId> --apply`** 补做终态回填（按返回项的 `nodeKey`/`dataType` 自动分派回填词表）。

## 引用素材（连线 + 非连线，全子命令统一）

画布节点的引用素材有两个来源，生成时**合并参与提交**（镜像网页端 `allReference*Urls` 计算）：

| 来源 | 节点字段 | 谁维护 |
| --- | --- | --- |
| **连线素材** | `data.connectedImageUrls` / `connectedVideoUrls` / `connectedAudioUrls` | 连线派生态——`edge create/delete` 自动重算，**任何人都不要手写** |
| **非连线素材（手动引用）** | `data.manualReferences: [{type:'image'\|'video'\|'audio', url, name}]` | 网页端参考区手动添加；CLI 的 `--ref`/`--ref-video`/`--ref-audio` 即新增手动引用 |

CLI 行为（每个 `gen` 都先读节点再提交）：

- **提交前自动现算 `connected*`（重要）**：`connected*`（连线派生的参考素材）是「仅在连线增删时刷新」的快照。CLI 在每次 `gen` 提交前会**按当前会话的边 + 上游节点数据重新计算**该节点的 `connected*`（复用 `edge create/delete` 同一套 `computeConnected`），用现算值覆盖存量快照后再提交。这样「先连边、后生成上游」的自然顺序下不会拿到空/陈旧参考图：上游 `gen` 出图后，下游 `gen` 会自动捞到新图，**不再静默降级成 `TEXT_TO_VIDEO` 或用过期首帧白扣积分**。快照与现算不一致时 stderr 告警（`参考素材已按当前会话现算刷新…`），`--dry-run` 输出带 `staleRefsRefreshed` 字段列出被刷新的键。无边支撑的「幽灵 `connected*`」也会一并被清掉。
- **提交引用 = 连线（现算）+ 已有手动 + 本次 CLI 传入**，有序去重；图片按模型 `max_reference_images` 截断（超限 stderr 告警）。
- **本次 CLI 新增的 URL 回填进 `manualReferences`**（已在 `connected*` 里的不重复写入——镜像网页端历史还原的去重规则），画布参考区才显示。
- **节点已有引用会自动参与**：`gen video` 不传 `--ref` 但节点连着图片节点 → 自动 `IMAGE_TO_VIDEO` 用连线图作首帧（与网页端一致，且因提交前现算，上游图新鲜有效）；`gen music` 参考音频优先级 = 连线 > 手动 > 本次 `--ref-audio`（`--audio-url` 为显式覆盖口）。
- **上游文本节点（`inputTexts`）自动并入提交 prompt**：image/video/universal 是 texts 在前、用户 prompt 在后（`\n` 连接）；text 节点相反（prompt 在前、`\n\n` 连接）。节点 `data.prompt` 只存用户原文。

### 生成前确认：`--dry-run` 与 `--refs-only`（全 gen 子命令通用）

生成扣积分。**默认工作流**（agent 代用户操作时）：用户没明确指定模型/引用 → 先预览、经确认再提交。

**默认模型推荐（用户无特殊要求时,把推荐项放确认选项第一位）**：

| 场景 | 首选 | 命令参数 | 说明 |
| --- | --- | --- | --- |
| 生图 | **Neo Image 2 official** | `--model gpt-image-2-official --size 2K --quality medium` | 质量档 `low`/`medium`(中)/`high`，支持 1K/2K/4K |
| 生图（备选） | **Neo Nano Pro** | `--model gemini-3-pro-image-preview --size 2K` | 无质量档，支持 2K/4K，参考图上限 10 |
| 生视频 | **Seedance 2.0（全能参考）** | `gen video --universal --model neo-video-2-0` | 分辨率默认即 `720p`，支持多模态参考/有声视频 |

**生视频模式默认规则（硬性）**：除非用户强行指定其他模式/模型（明确要求首尾帧严格一致、点名非全能模型等），**一律优先全能参考 `--universal`**。只有一张分镜图也走 `--universal --ref <图>`（图进顶层 `imageUrls` 当参考），不要因为「手上只有一张图」就自行退回首尾帧 `IMAGE_TO_VIDEO`。

**列表与可提交性是两回事（已实测）**：`models image` 默认拉全量列表（`scenarioType=1`，含 `gpt-image-2-official` 及其质量档/尺寸）；画布 UI 用的 `scenario 2` 只是展示子集，后端 `generate-image` **不按场景硬校验**——全量列表里的模型画布节点都能直接提交出图。真正的不可用（如会员档位不够）由后端在提交时报错。视频推荐模型 `neo-video-2-0` 在 `models video --universal` 列表内。

**报积分以 `--dry-run` 的 `estimate` 为准（已实测踩坑）**：`models image` 列表里的 `points_cost_per_image` 只是**无矩阵匹配时的兜底基础价**，带 `--size`/`--quality` 时实际单价来自 `size_pricing_config` 的 `quality_size` 组合键（例：某模型基础价 200，`medium_2k` 实际 89——拿基础价报会虚高一倍多）。CLI 已内置这套预估（口径=网页端计价链：`quality_size` 组合键 > `size` 键 > 基础价兜底，另加参考图超额费 × 张数）：`gen image --dry-run` 输出 `estimate`（`points` 总预估 / `perImage` 单张 / `referenceOverage` 参考图超额 / `pricingKey` 命中的计价键），正式提交前同样打到 stderr。预估未计会员折扣，实扣可能更低。**全能视频**（`gen video --universal`）的 `--dry-run` 也附 `estimate`（口径=网页端 `videoPointsCost.js`：单价挂「分辨率→宽高比」配置，有参考视频且模型配了带参考视频单价时按「生成时长+`--total-duration`」×带参考视频单价计价，另附 `basePoints`=同计费时长×基础单价的对比价，即网页端发送按钮上被划掉的原价）；非全能视频计价在 `models video --full` 的计价矩阵里（按分辨率+比例的每秒积分 × 时长），语音 v2 见下文 seed-audio 的 `estimate`。

| 选项 | 作用 |
| --- | --- |
| `--dry-run` | 只输出「将要提交什么」的单行 JSON：`endpoint` / 完整 `body` / `refs`（每类引用分列 `connected`/`manual`/`cli`/`used`）/ `model`（显示名与关键能力位，如 `supportAudio`/`max_reference_images`）；图片、全能视频与 seed-audio 另附 `estimate` 积分预估（报价用它，见上）。**不提交、不扣积分、不写节点**。 |
| `--refs-only` | 放弃「连线 + 手动」自动合并，**只用本次 CLI 显式传入的 `--ref`/`--ref-video`/`--ref-audio`**——用户从预览清单里挑子集时用它 + 明确 URL 重跑。 |

```bash
# ① 预览：模型 + 引用清单 + 完整提交体 + estimate 积分预估（免费）
neowow gen image --node "$N" --prompt "…" --model gemini-2.5-flash-image --dry-run | jq '{model, refs}'
# ② 用户确认/改选后正式提交：全量引用直接去掉 --dry-run；只用部分引用则：
neowow gen image --node "$N" --prompt "…" --model gemini-2.5-flash-image \
  --refs-only --ref "<用户选中的url>" --wait
```

注意：`--refs-only` 只影响**本次提交用哪些引用**，不会从节点上删除已有的 `manualReferences`/连线（那是画布状态，删除引用用网页端参考区或 `edge delete`）。

### `neowow gen image [flags]`

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--node <nodeKey>` | 是 | 目标节点 id（建节点见 [./node.md](./node.md)） |
| `--prompt <文本>` | 是 | 提示词 |
| `--model <modelName>` | 是 | 模型机器名，图片填模型对象的 `model_name`（先 `neowow models image` 发现），如 `gemini-2.5-flash-image` |
| `--ar, --aspect <W:H>` | 否 | 长宽比，默认 `16:9`（也可 `auto`） |
| `--size <档>` | 否 | 分辨率档，默认 `2K`（如 `1K`/`2K`；注意 `gemini-2.5-flash-image` 仅支持 `1K`） |
| `-n, --numImages <n>` | 否 | 出图数量，默认 `1`（提交 body 是字符串，回填 `batchSize` 是数字） |
| `--ref <url>` | 否 | 参考图 URL，可重复多次 → 提交 body `imageUrls` 数组 |
| `--quality <档>` | 视模型 | 画质档（模型 `quality` 枚举里选）→ 提交 `quality`，回填 `outputQuality`。**模型带质量档（`models image` 的 `quality` 非空）时必传**，缺传/传错直接报错并列出可选档（镜像网页端：有档模型提交体必带 quality）；无质量档的模型传了会被忽略 |
| `--camera '<json>'` | 否 | 运镜参数 JSON → 提交 `cameraParameter`（模型支持才传） |
| `--color-palette '<json>'` | 否 | 调色盘 JSON → 提交 `colorPalette` |
| `--outputFormat <fmt>` | 否 | 输出格式，默认 `jpeg`（如 `jpeg`/`png`，取决于模型 `supported_output_formats`） |
| `--transparent` / `--no-transparent` | 否 | **透明背景**开关（对应画布图片节点设置栏的「透明」开关）→ 提交 `transparentBackground`，回填节点 `transparentBackground`。**仅白名单模型下发**：`gpt-image-2.5-flare` / `gpt-image-2.5-sunburst`（镜像网页端 `TRANSPARENT_SUPPORTED_MODELS`；模型列表接口无对应能力位）——白名单模型**恒带该字段**（`true`/`false` 都发）；白名单外传了只忽略并提示、不带字段。两个都不传时**沿用节点 `data.transparentBackground`**（网页端开关的持久化状态，默认关）；`--no-transparent` 强制关。两者互斥（同时给报用法错误 exit=2）。`--dry-run` 输出 `transparentBackground`（`true`/`false`/`null`=模型不支持）与 `model.supportTransparent` |
| `--wait` | 否 | 轮询到终态再返回（布尔，默认关） |

固定提交项（不可调）：`syncMode:false`、`showPrompt:true`、`sourceType:'USER_DIRECT'`。

回填的 `modelName` 是网页端模型徽标**显示名**（`model_display_name`，by-scenario 查表 best-effort，查不到用机器名兜底）；`model` 仍是机器名。

**输出**：stdout 单行 JSON。
- 不带 `--wait`：含 `kind`(`"image"`) / `nodeKey` / `taskId` / `status`(`"PENDING"`) / `backfilled` / `waited`(`false`)；白名单模型另含 `transparentBackground`(布尔，本次提交值)。
- 带 `--wait`：含 `kind` / `nodeKey` / `taskId` / `status`(终态) / `resultData`(URL 数组) / `dataField`(`"inputImageUrls"`) / `backfilled`(布尔，终态是否成功回填进节点；`false`=生成成功但写节点失败，见 stderr) / `waited`(`true`)；白名单模型另含 `transparentBackground`。

### `neowow gen video [flags]`

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--node <nodeKey>` | 是 | 目标节点 id |
| `--model <modelName>` | 是 | 模型机器名，视频填模型对象的 `value`（先 `neowow models video` 发现） |
| `--prompt <文本>` | 否 | 提示词，默认空串 `''` |
| `--ar, --aspect <W:H>` | 否 | 长宽比，默认 `16:9` |
| `--resolution <档>` | 否 | 分辨率，**默认 `720p`**（全能/普通统一） |
| `--duration <秒>` | 否 | 时长，默认 `5`（普通模式提交为字符串，全能模式提交为数字） |
| `--ref <url>` | 否 | 参考图 URL，可重复 ✅ 给了就按模式转图生视频（见下「三种模式」） |
| `--multi-ref` | 否 | **多图参考模式**（布尔，等价 `--generation-type REFERENCE_TO_VIDEO`）：全部 `--ref` 走 `imageUrls` 数组，不带首尾帧 |
| `--generation-type <T>` | 否 | 生成类型，默认 `TEXT_TO_VIDEO`（取值 `TEXT_TO_VIDEO`/`IMAGE_TO_VIDEO`/`REFERENCE_TO_VIDEO`）。⚠️ `UNIVERSAL_TO_VIDEO` **只能经 `--universal` 触发**——直接传会落进普通分支，发出缺 `videoReferType`/`totalDuration` 的坏 body |
| `--no-audio` | 否 | 关闭声音。是否生效看模型 `supportAudio` 三态（见下「generateAudio 三态」） |
| `--audio-url <url>` | 否 | 参考音频（单个，模型带 `supportAudioUpload` 能力时前端会传）→ 提交 `audioUrl`（非全能模式） |
| `--draft` | 否 | **草稿开关**（布尔，提交 `draft:true`；对应画布首尾帧/多图参考面板的草稿开关）。**只在首尾帧 / 多图参考 / 文生视频模式生效**（全能/延长/编辑面板无此开关，传了只告警忽略），且**模型须 `supportDraft=true`**（`models video` 透出；不支持的模型直接报错 exit=2，网页端该开关不会出现）。开关打开后**分辨率固定为该生成类型的最后一档**（网页端 `availableResolutions` 只剩它并自动选中）——`--resolution` 传了别的会被改成该档并提示。结果节点写 `draft:true` + `enableDraft:true`。要出样片**更常用的是直接选样片模型**（见下「草稿 / 样片」） |
| `--universal` | 否 | **全能参考模式**（布尔，见下「全能模式」） |
| `--extend` | 否 | **视频延长模式**（布尔，见下「视频延长」；模型从 `models video --extend` 发现；与 `--universal`/`--edit`/`--multi-ref` 互斥） |
| `--edit` | 否 | **视频编辑模式**（布尔，见下「视频编辑」；模型从 `models video --edit` 发现；互斥同上） |
| `--edit-video <url>` | 否 | 编辑模式的**待编辑视频**：提到 `referenceVideoUrls[0]`，不在引用里则并入手动引用。不传则首个视频（连线 > 手动 > `--ref-video`）即待编辑视频 |
| `--ref-video <url>` | 否 | 全能/延长/编辑模式参考视频，可重复 → 顶层 `referenceVideoUrls` |
| `--ref-audio <url>` | 否 | 全能/延长/编辑模式参考音频，可重复 → 顶层 `audioUrl`（数组）。延长模型 `featureConfig.supportReferenceAudio` 显式为 `false/0` 时拒绝（网页端同款禁发） |
| `--refer-type <t>` | 否 | 全能/延长参考类型，默认 `feature`（提交 `videoReferType`） |
| `--total-duration <秒>` | 否 | **参考视频总时长（秒）**，参与计价——**仅 `refVideoBilling=1` 的模型**生效（`models video --universal\|--extend\|--edit` 每项透出该字段；前端已删硬编码白名单改按此字段）：全能/延长模式带参考视频未传时告警（`totalDuration=0` 可能影响计费/校验），`refVideoBilling≠1` 恒提交 `totalDuration:0` 并忽略本参数；编辑模式**不下发** `totalDuration`，本参数只作「待编辑视频之外的参考视频总秒数」参与预估。模型列表查不到该模型时按旧白名单兜底并提示 |
| `--output-format <fmt>` | 否 | 视频输出格式 `mp4`/`mov`（五种模式通用，提交 `outputFormat`）。**仅白名单模型下发**（`doubao-seedance-2-5-260628`），未传用默认 `mp4`；白名单外忽略并提示、不带字段（镜像网页端 `videoOutputSettings.js`） |
| `--bitrate-mode <档>` | 否 | 码率档位 `standard`/`high`（提交 `bitrateMode`）。**仅白名单模型下发**（`neo-video-2-0` / `neo-video-2-0-fast` / `doubao-seedance-2-0-mini-260615` / `doubao-seedance-2-5-260628`），未传用默认档（seedance-2.5 为 `high`，其余 `standard`）；白名单外忽略并提示 |
| `--wait` | 否 | 轮询到终态再返回（布尔） |

**五种模式与各自 wire 字段**（都在基础 body `nodeKey/sessionId/modelName/prompt/aspectRatio/resolution/duration` 之上追加）。**模式选型默认规则：从零生成视频时，非用户强行指定，一律 `--universal` 全能参考**（单图也当参考喂 `--universal --ref`）；首尾帧/多图参考仅在用户明确要求时使用；**已有视频要「接着往后生成」用 `--extend`，要「改画面/换风格/替换元素」用 `--edit`**（对应画布视频节点的「视频延长」「视频编辑」两个 tab）：

| 模式 | 触发 | 追加的 wire 字段 |
| --- | --- | --- |
| 首尾帧（图生视频） | 有 `--ref` 且非 `--multi-ref`/`--universal`/`--extend`/`--edit` | `generationType:'IMAGE_TO_VIDEO'`、`firstFrameImageUrl`=第 1 张 ref、`lastFrameImageUrl`=第 2 张（若有）。⚠️ **不再发送 `imageUrls`** |
| 多图参考 | `--multi-ref`（或 `--generation-type REFERENCE_TO_VIDEO`；需至少一个 `--ref`） | `generationType:'REFERENCE_TO_VIDEO'`、`imageUrls:[全部 ref]`，**无首尾帧字段** |
| 全能参考 | `--universal` | `generationType:'UNIVERSAL_TO_VIDEO'`、`videoReferType`、`imageUrls`/`referenceVideoUrls`/`audioUrl`（顶层扁平数组）、`totalDuration`、`duration` 数字、`generateAudio:true` 恒开 |
| **视频延长** | `--extend`（需至少一个视频引用） | 与全能同构：`generationType`=模型配置 `generationTypes[0].value`（线上 seedance-2.5 实际为 `'VIDEO_EXTEND'`；查不到模型时兜底 `'EXTEND_TO_VIDEO'`，与网页端兜底一致）、`videoReferType:'feature'`、`imageUrls`/`referenceVideoUrls`/`audioUrl`、`totalDuration`、`duration` 数字（缺省模型 `durationRange.min`）、`generateAudio:true` 恒开 |
| **视频编辑** | `--edit`（需至少一个视频引用；`referenceVideoUrls[0]` 即待编辑视频） | `generationType`=模型配置 `generationTypes[0].value`（缺省 `'VIDEO_TO_VIDEO'`）、`imageUrls`/`referenceVideoUrls`/`audioUrl`、`duration`=**待编辑视频秒数**（`--duration`，缺省 `null`）、`generateAudio:true`。**无 `videoReferType`、无 `totalDuration`** |
| （文生视频） | 无 `--ref` 且非以上模式 | `generationType`=`--generation-type`（默认 `TEXT_TO_VIDEO`） |

五种模式都会经 `--output-format`/`--bitrate-mode` 的白名单逻辑追加 `outputFormat`/`bitrateMode`（见选项表）。**四个模式 flag 互斥**（`--universal`/`--extend`/`--edit`/`--multi-ref` 同时给报用法错误 exit=2）。

**generateAudio 三态**（非全能模式；模型元数据从级联列表按 `value` 查，best-effort）：

- `supportAudio=2`：必开——提交 `generateAudio:true`，`--no-audio` **被忽略并在 stderr 告警**。
- `supportAudio=1`：开关——默认 `generateAudio:true`，`--no-audio` 可关（提交 `false`）。
- `supportAudio=0` 或未知：**不带该字段**。
- 模型元数据查不到（列表拉取失败等）：退回旧行为——默认带 `generateAudio:true`，`--no-audio` 则不带。

**全能模式（`--universal`）**：用全能模型（如 `neo-video-2-0` / `neo-video-2-0-fast` Seedance 2.0，从 `neowow models video --universal` 发现）做多模态参考生成。提交体严格按真实 wire 格式（`UniversalSection.vue` handleGenerate，**已抓包+实测验证**）：

1. **参考素材走顶层扁平字段**：`--ref`→`imageUrls:[...]`、`--ref-video`→`referenceVideoUrls:[...]`、`--ref-audio`→`audioUrl:[...]`（数组）。⚠️ **不是**嵌套 `references:{...}`——那是前端组件层的死代码，后端不认、会静默丢弃参考图。
2. **必带 `generationType:'UNIVERSAL_TO_VIDEO'` + `videoReferType:'feature'` + `totalDuration`**（CLI 自动加；缺 generationType 后端报 `生成类型不能为空`）。`totalDuration` = **参考视频总时长秒数、参与计价**——但**仅 `refVideoBilling=1` 的模型**统计（模型对象顶层字段，`models video --universal` 透出；镜像网页端 `videoPointsCost.js` `isRefVideoBillingModel`，前端已删硬编码白名单）；`refVideoBilling≠1` 网页端恒传 `0`，CLI 同口径强制 `0`。计入时长的模型网页端由视频 metadata 求和，CLI 读不到远端时长，带 `--ref-video` 时请用 `--total-duration` 显式传。模型列表里查不到该模型时 CLI 退回旧白名单（`neo-video-2-0` / `doubao-seedance-2-5-260628` / `neo-video-2-0-fast` / `doubao-seedance-2-0-mini-260615` / `MiniMax-H3` / `wan3.0-video`）兜底并在 stderr 提示。
3. **`duration` 提交为数字**（如 `15`，非字符串）；分辨率默认 `720p`，`--ar`/`--duration` 不传则 `16:9`/`5`。**`generateAudio` 恒 `true`**（前端硬编码），`--no-audio` 被忽略并告警。
4. **回填到节点的是 `universal*` 字段**：`universalModel` / `universalAspectRatio` / `universalResolution` / `universalDuration` + `imageUploadMode:'universal'`（否则画布重载落回首尾帧模式），非连线参考写 **`manualReferences: [{type:'image'|'video'|'audio', url}]`**。⚠️ 别回填 `connectedImageUrls`——那是连线派生状态，画布任何连线增删都会整体重算把它抹掉。

**视频延长（`--extend`）**：对应画布视频节点「视频延长」tab（`ExtendSection.vue` handleGenerate），把已有视频接着往后生成。模型从 `neowow models video --extend` 发现（独立端点 `/agent/user/video/models/extend`，`requestType=1`），`--model` 填每项 `value`。

1. **必须有待延长的视频**：`--ref-video <url>`，或节点已有连线 / 手动视频引用；没有则报用法错误（exit=2）。可再加 `--ref <图>` / `--ref-audio <音>` 作参考；延长模型 `featureConfig.supportReferenceAudio` 显式 `false/0` 时带音频参考直接拒绝。**`featureConfig.comboLimits` 组合上限**（按「有视频/有音频」命中 `image_video_audio` > `image_video` > `image_audio` > `image_only` 桶的 `max_images/max_videos/max_audios`）超限提交前拦截——网页端同款禁发。
2. **wire 与全能同构**：`generationType` 取模型配置 `generationTypes[0].value`（线上实测 `VIDEO_EXTEND`，`models video --extend` 每项 `generationType` 可见；查不到模型才兜底 `EXTEND_TO_VIDEO`）+ `videoReferType:'feature'` + 顶层 `imageUrls`/`referenceVideoUrls`/`audioUrl` + `totalDuration` + `duration` 数字 + `generateAudio:true` 恒开（`--no-audio` 被忽略并告警）。
3. **分辨率 / 宽高比 / 时长缺省取模型配置**（镜像网页端切模型时的默认值）：`--resolution` 缺省=模型 `resolutions[0]`；`--ar` 缺省=该分辨率 `aspectRatios[0]`；`--duration` 缺省=`durationRange.min`。显式传的值须在模型枚举 / 时长范围内，越界提交前报错（exit=2）；枚举匹配大小写不敏感并归一成枚举原值（线上编辑模型有 `720P`/`1080P` 大写枚举，写 `720p` 也能过）。模型列表查不到该模型时不校验、退回 `720p`/`16:9`/`5`。
4. **`totalDuration`**：`refVideoBilling=1` 的模型 = `--total-duration`（参考视频总秒数，未传告警），否则恒 `0`。`--dry-run` 附 `estimate`（口径同全能：有参考视频按「生成时长+参考视频时长」×带参考视频单价，另附 `basePoints` 划线原价）。
5. **回填到节点的是 `extend*` 字段**：`extendModel` / `extendResolution` / `extendAspectRatio` / `extendDuration` + `imageUploadMode:'extend'`（否则画布重载落回首尾帧 tab）；显式 `--output-format`/`--bitrate-mode` 才回填 `extendOutputFormat`/`extendBitrateMode`；**非连线引用写 `extendManualReferences`**（延长面板只读这个键，不读 `manualReferences`——三个面板的手动引用互不可见，`--dry-run` 的 `manualKey` 字段标出本次用的键）。

**视频编辑（`--edit`）**：对应画布视频节点「视频编辑」tab（`EditingSection.vue` handleGenerate），按提示词改已有视频的画面。模型从 `neowow models video --edit` 发现（独立端点 `/agent/user/video/models/editing`，`requestType=2`，无 `/byLogin` 变体），`--model` 填每项 `value`。

1. **`referenceVideoUrls[0]` 即待编辑视频**（网页端 `editingVideoUrl`=视频引用列表首个，画布上标「编辑视频」角标）：用 `--edit-video <url>` 指定（提到首位；不在引用中则并入手动引用），或不传则按「连线 > 手动 > `--ref-video`」的首个视频。其余视频/图/音都是参考。没有视频报用法错误（exit=2）。`comboLimits` 组合上限同延长。
2. **wire**：`generationType` 取模型配置 `generationTypes[0].value`（缺省 `VIDEO_TO_VIDEO`）+ 顶层 `imageUrls`/`referenceVideoUrls`/`audioUrl` + `generateAudio:true`；**无 `videoReferType`、无 `totalDuration`**。
3. **`duration` = 待编辑视频的时长（秒）**：网页端用 mediabunny 探测自动填、参与计价/校验；CLI 读不到远端时长，**请用 `--duration <秒>` 显式传**，缺省提交 `null` 并在 stderr 提示。`--resolution`/`--ar` 缺省与越界校验同延长；编辑模式**没有生成时长选项**（输出时长跟随待编辑视频）。
4. **计价**（`--dry-run` 的 `estimate`，镜像 `editingTotalPointsCost`）：待编辑视频本身即参考视频——按（其时长 + 其他参考视频总时长）× 带参考视频单价（无该单价回退基础单价）；「其他参考视频总时长」仅 `refVideoBilling=1` 模型计入、由 `--total-duration` 传（编辑模式该值不下发、只影响预估）。
5. **回填到节点的是 `editing*` 字段**：`editingModel` / `editingResolution` / `editingAspectRatio` + `imageUploadMode:'editing'`；显式输出选项回填 `editingOutputFormat`/`editingBitrateMode`；**非连线引用写 `editingManualReferences`**。

普通模式回填的 `modelName` 用级联列表的显示名 `.name`（查不到用机器名）；成功回填补 `mediaSource:'generated'`。

**草稿 / 样片（`data.draft`）**：画布视频节点的「样片模式」有两条路，结果都是**草稿视频**（画布左上角「草稿」角标、工具栏出现「转正式」；历史记录 `videoRef.draft=true`）：

1. **样片模型**（推荐）：`models video` 里 `draftModel:true` 的项——模型 `value` 以 `-draft` 结尾、显示名含「样片」（如 `doubao-seedance-2-5-260628-draft`「Seedance 2.5 (样片模式)」），`formalModel` 是对应的正式模型 value。选它生成**不用传 `draft`**，五种模式通用（CLI 按模型名判定，stderr 提示「样片模型」）。
2. **`--draft` 草稿开关**：见选项表，限普通模式 + `supportDraft` 模型 + 分辨率固定最后一档。

CLI 提交时按上述启发式回填 `data.draft`（`true`/`false`），**终态再以后端为准**：`--wait` / `poll --apply` 到 `SUCCESS` 时查 `query-asset-ref` 的 `videoRef.draft` 写回 `data.draft`（镜像网页端 `syncDraftFlagFromServer`；查询失败沿用提交时判断）。草稿看过满意后用 **`neowow gen formal --node <该节点>`** 转正式（见下）。

**输出**：stdout 单行 JSON。
- 不带 `--wait`：含 `kind`(`"video"`) / `nodeKey` / `taskId` / `status`(`"PENDING"`) / `mode`(`"universal"`/`"extend"`/`"edit"`/`"IMAGE_TO_VIDEO"`/…) / `universal`(布尔) / `draft`(布尔，提交时判定) / `backfilled`(布尔) / `waited`(`false`)。
- 带 `--wait`：含 `kind` / `nodeKey` / `taskId` / `status` / `resultData` / `dataField`(`"inputVideoUrls"`) / `mode` / `universal`(布尔) / `draft`(布尔，终态以后端 `videoRef.draft` 为准) / `backfilled`(布尔，终态是否成功回填) / `waited`(`true`)。
- `--dry-run`：另含 `mode` / `manualKey`（本次读写的手动引用键）/ `draft` / `model`（普通模式透出 `supportDraft`/`draftModel`；延长/编辑模式透出 `generationType`/`durationRange`/`refVideoBilling`/`featureConfig`）。

### `neowow gen formal [flags]`

**草稿（样片）视频转正式**，对应画布视频节点工具栏「转正式」（`VideoGenerationNode.vue` `handleDraftToFormal`）。流程与网页端一致：① 核对草稿（`GET query-asset-ref` 的 `videoRef.draft`，`data.draft` 只是提交时的启发式）→ ② 预估积分（`POST estimate-draft-to-formal`，不扣分、不建任务、不锁价）→ ③ **在草稿节点右侧新建一个「正式视频」video 节点并连线**（草稿节点 `video` 出口 → 新节点 `image` 入口；源节点在组内则同组并登记 `childNodeIds`；新节点继承草稿的提示词/模式/引用/宽高比/时长，**分辨率换成目标值、样片模型换成对应正式模型**，`draft:false` + `sourceNodeId` + `draftSourceTaskId`）→ ④ `POST draft-to-formal`（`nodeKey`=新节点）拿新 `taskId` → ⑤ 回填新节点 `taskId`/`PENDING`；`--wait` 再轮询到终态回填 `inputVideoUrls`。**草稿节点本身保留不动。** 扣积分：先 `--dry-run` 看预估给用户确认。

> 画布里的草稿只能走 `/agent/story-canvas/draft-to-formal`；通用的 `/agent/user/video/draft-to-formal` 不会把正式视频挂回节点。转正式目前只有 Seedance 2.5、只能转 **1080p**（网页端固定只给 1080P 一项）。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--node <nodeKey>` | 是 | 草稿视频所在的 video 节点（`data.draft=true`、`status=SUCCESS`） |
| `--task <taskId>` | 否 | 草稿任务 id，默认取节点 `data.taskId`。节点上只存最近一次，要转历史里某次草稿用 `gen history <nodeKey>` 里 `draft=true` 的记录的 `taskId` |
| `--resolution <档>` | 否 | 目标分辨率，默认 `1080p`（小写提交）。目前只支持 `1080p`，传别的 CLI 提示后按原样提交、由后端校验 |
| `--target <nodeKey>` | 否 | 不新建节点，把正式视频挂到**已有的 video 节点**（不能是草稿节点自身、不能是上传/转换节点、不能正在生成中）。会把继承参数 + `PENDING` 写进该节点，**不建连线** |
| `--dry-run` | 否 | 只核对草稿 + 预估积分 + 输出将要新建的节点/连线与提交体，**不建节点、不提交、不扣分** |
| `--wait` | 否 | 轮询新任务到终态并回填新节点（同 `gen video --wait`；`--interval`/`--timeout` 同 `poll`） |
| `-p, --project <sessionId>` | 条件 | 项目作用域，同其他 gen 子命令 |

提交前拦截（exit=2，不建节点不扣分）：节点不是 video / 没有 `taskId` / 后端说不是草稿（`videoRef.draft≠true`）/ 草稿任务未 `SUCCESS` / `--target` 非法。预估接口报错直接抛（网页端此时也拦住不让提交）。`draft-to-formal` 提交失败时新建的节点会被标成 `status:'failed'` + `errorMessage`（网页端同款），不需要可 `neowow node delete <nodeKey>`。

**输出**：stdout 单行 JSON，含 `kind`(`"formal"`) / `sourceNodeKey` / `sourceTaskId`(草稿 taskId) / `nodeKey`(**正式视频节点**，新建或 `--target`) / `created`(布尔) / `edgeId`(新建时) / `taskId`(新任务) / `resolution` / `estimate`(`points` 实扣 / `original` 原价 / `discountRate` / `raw` 后端原样) / `status` / `phase` / `backfilled` / `waited`；`--wait` 另含 `resultData` / `dataField`(`"inputVideoUrls"`) / `draft`(应为 `false`)。`--dry-run`：`kind` / `dryRun:true` / `sourceNodeKey` / `sourceTaskId` / `resolution` / `endpoint` / `body` / `estimate` / `draftVerified`(`"server"`=后端核对 / `"local"`=后端查不到、凭节点 `data.draft`) / `target`（`create`、`nodeKey`、新建时的 `position`/`parentNode`/`edgeId`/`data`）/ `formalModel`(换成的正式模型)。

```bash
# 草稿满意后转正式：先 dry-run 看预估积分与将新建的节点，确认后去掉 --dry-run
neowow gen formal --node <草稿视频节点> --dry-run | jq '{points: .estimate.points, newNode: .target.nodeKey}'
neowow gen formal --node <草稿视频节点> --wait
# stdout: {"kind":"formal","sourceNodeKey":"…","nodeKey":"<新正式节点>","created":true,"taskId":"…","status":"SUCCESS",
#          "resultData":["https://…mp4"],"dataField":"inputVideoUrls","draft":false,"waited":true}
```

### `neowow gen audio [flags]`

语音合成（异步，**双引擎**）：

- **默认 minimax v1**：`POST generate-audio`，`--sound` 必填（音色从 `neowow models voice` 发现）。
- **seed-audio v2**：`--engine seed`（或 `--engine seed-audio-1.0`），**或带 `--ref-audio`/`--ref-image` 时自动切换**——`POST /agent/story-canvas/generate-audio-v2`，模型固定 `seed-audio-1.0`。可纯文本描述角色声线、情绪、台词与环境声，也可加 **≤3 条参考音频 或 1 张参考图（二者互斥，SeedAudioPanel 同款约束）**，无需 `--sound`。场景配音与模板迁移见 [SeedAudio 示例](../examples/seed-audio.md)。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--node <nodeKey>` | 是 | 目标节点 id |
| `--text <文本>` | 是 | v1 为朗读文本；v2 为完整声音场景提示词（角色、声线、情绪、台词、环境声），提交为 `textPrompt`，可包含换行 |
| `--engine <e>` | 否 | 引擎：缺省 minimax v1；`seed` / `seed-audio-1.0` 走 v2 |
| `--sound <音色id>` | v1 是 | 音色 id（`--soundId` 等价，二选一即可）。v2 引擎不需要 |
| `--rate <r>` | 否 | v1 语速，默认 `1.0`（提交字符串，区间 [0.5,2]） |
| `--pitch <p>` | 否 | v1 音调，默认 `0`（提交数字，区间 [-12,12]） |
| `--volume <v>` | 否 | v1 音量，默认 `1.0`（提交字符串，区间 (0,10]） |
| `--emotion <e>` | 否 | v1 情绪，默认 `neutral`（`happy`/`sad`/`angry`/`fearful`/`disgusted`/`surprised`/`neutral`） |
| `--ref-audio <url>` | 否 | v2 参考音频，可重复（**≤3，超出截断并告警**）→ `audioUrls`；给了自动切 v2。**与 `--ref-image` 互斥** |
| `--ref-image <url>` | 否 | v2 参考图（单张）→ `imageUrl`；给了自动切 v2。**与 `--ref-audio` 互斥** |
| `--format <fmt>` | 否 | v2 输出格式 → `audioConfig.format`，仅 `wav`/`mp3`/`pcm`/`ogg_opus`（缺省 wav 由服务端补） |
| `--sample-rate <n>` | 否 | v2 采样率 → `audioConfig.sampleRate`，仅 `8000`/`16000`/`24000`/`32000`/`44100`/`48000`（缺省 24000） |
| `--speech-rate <n>` | 否 | v2 语速 → `audioConfig.speechRate`，区间 `[-50,100]`（缺省 0；参与计费折算） |
| `--loudness-rate <n>` | 否 | v2 响度 → `audioConfig.loudnessRate`，区间 `[-50,100]`（缺省 0） |
| `--pitch-rate <n>` | 否 | v2 音调 → `audioConfig.pitchRate`，区间 `[-12,12]`（缺省 0） |
| `--wait` | 否 | 轮询到终态再返回（布尔） |

v1 固定提交项：`type:'VOICE'`、`tone:[]`。v2 的 `audioConfig` 由上述 `--format/--sample-rate/--speech-rate/--loudness-rate/--pitch-rate` 组装，全缺省则不带该字段；**值域在 CLI 侧先校验（枚举/区间同 SeedAudioPanel），坏值不提交不扣分**。这 5 个 flag 误用在 v1（minimax）上会被忽略并 stderr 告警。

**Seed 使用要点**：显式写 `--engine seed`，`--model seed-audio-1.0` 不切换音频引擎。情绪、停顿、角色间差异写入 `--text`；`--emotion/--rate/--volume/--pitch` 是 MiniMax 参数，不能用来控制 Seed。`--speech-rate` 等输出参数作用于整段，不是逐角色设置。CLI 当前不继承节点已有的 `voiceModel/seedAudioPrompt/seedAudioConfig`；复现网页效果时传入文本及完整的五项输出配置。

**v2 引用规则（镜像 SeedAudioPanel）**：参考音频 = 连线（`connectedAudioUrls`）＋手动（`manualReferences`）＋本次 `--ref-audio`，合并去重后取前 3；参考图只有手动来源（audio 节点入线仅限 audio 类型，图片靠 `--ref-image` 或网页端素材库），单张，显式 `--ref-image` 优先于节点残留引用。**参考音频与参考图互斥**——同时存在直接报错（`引用素材冲突`，exit 2）；节点上有残留引用时用 `--refs-only` 只认本次显式传参。

**v2 计费预估**：`--dry-run` 输出附 `estimate`（`points` 预估积分 / `billedSeconds` 计费秒数 / `exceedsMax` 是否触顶），正式提交前也会打到 stderr。口径与服务端预扣一致（`audioCostEstimate.js`）：中文 5 字/秒、英文 2.5 词/秒折算时长，除以语速系数 `max(0.5, 1+speechRate/100)`，130 积分/分钟，单次封顶 120 秒——超长文本音频**仍完整生成**，只按 2 分钟计费。

**回填键（按引擎分家，都带 `audioMode:'voice'`）**：v1 写 `prompt/soundId/rate/pitch/volume/emotion` + `voiceModel:'minimax'`；v2 写 `seedAudioPrompt`（+有配置时 `seedAudioConfig`）+ `voiceModel:'seed-audio-1.0'`。生成中状态是 `status:'running'` + `generationStartTime`（见上「状态词表分家」）。

**输出**：stdout 单行 JSON。
- 不带 `--wait`：含 `kind`(`"audio"`) / `nodeKey` / `taskId` / `status`(`"running"`) / `engine`(`"minimax"` 或 `"seed-audio-1.0"`) / `backfilled`(布尔) / `waited`(`false`)。
- 带 `--wait`：含 `kind` / `nodeKey` / `taskId` / `status`(轮询终态 `SUCCESS`/`FAILED`) / `resultData` / `dataField`(`"inputAudioUrls"`) / `backfilled`(布尔，终态是否成功回填) / `waited`(`true`)。

### `neowow gen music [flags]`

音乐生成（异步）。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--node <nodeKey>` | 是 | 目标节点 id |
| `--prompt <曲风>` | 否 | 曲风描述，默认空串 `''` |
| `--lyrics <文本>` | 否 | 歌词，默认空串 |
| `--instrumental` | 否 | 纯音乐（布尔，提交 `instrumental:true`）。**歌词强制清空**——即便同时给了 `--lyrics` 也按空串提交（对齐网页端行为） |
| `--ref-audio <url>` | 否 | 新增手动参考音频（可重复；回填进 `manualReferences`）。实际提交的参考曲优先级 = `--audio-url` 显式覆盖 ＞ 连线 ＞ 手动/本次 `--ref-audio` |
| `--audio-url <url>` | 否 | 参考曲 URL 显式覆盖口（单个，绕过连线/手动合并），默认空串 |
| `--wait` | 否 | 轮询到终态再返回（布尔） |

**回填键**：`musicPrompt` / `musicLyrics` / `instrumental` + `audioMode:'music'`（音乐面板读这几个键；⚠️ 不写 `prompt`——那是语音 tab 的朗读框，写了会污染）。生成中状态 `status:'running'` + `generationStartTime`。

**输出**：stdout 单行 JSON。
- 不带 `--wait`：含 `kind`(`"music"`) / `nodeKey` / `taskId` / `status`(`"running"`) / `backfilled`(布尔) / `waited`(`false`)。
- 带 `--wait`：含 `kind` / `nodeKey` / `taskId` / `status`(轮询终态) / `resultData` / `dataField`(`"inputAudioUrls"`) / `backfilled`(布尔，终态是否成功回填) / `waited`(`true`)。

### `neowow gen lyrics [flags]`

歌词生成。**唯一同步子命令**：提交即返回，无 taskId、不轮询（需要项目作用域 `sessionId`）。可选 `--node`：把结果按**音乐面板键**回填进节点（`musicLyrics` + 返回里有则 `songTitle`/`styleTags`，并写 `audioMode:'music'`）。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--prompt <文本>` | 否 | 创作提示词，默认空串 `''` |
| `--lyrics <文本>` | 否 | 已有歌词/参考，默认空串 |
| `--title <标题>` | 否 | 歌名，默认空串 |
| `--node <nodeKey>` | 否 | 回填目标 audio 节点（返回有 `lyrics` 才回填） |

**输出**：stdout 单行 JSON，含 `kind`(`"lyrics"`) / `sync`(`true`) / `songTitle` / `styleTags` / `lyrics` / `taskCode` / `backfilledNode`(回填的 nodeKey 或 `null`)。

### `neowow gen text [flags]`

文本生成（text 节点跑 LLM，异步）。提交 `POST /agent/story-canvas/generate-text` 拿 `taskId`，走同一条 `batch-query-status` 轮询。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--node <nodeKey>` | 是 | 目标 text 节点 id |
| `--prompt <文本>` | 是 | 提示词 |
| `--type <T>` | 否 | 生成类型，默认 `STORY_DESCRIPTION` |
| `--model-config-id <id>` | 否 | 文本模型配置 id → 提交 `textModelConfigId` |
| `--ref <url>` | 否 | 参考图，可重复 → `imageUrls` |
| `--ref-video <url>` | 否 | 参考视频，可重复（**≤5，超出截断**）→ `videoUrls` |
| `--audio-url <url>` | 否 | 参考音频（单个）→ `audioUrl` |
| `--wait` | 否 | 轮询到终态再返回（布尔） |

**回填**：提交后写 `{prompt, status:'PENDING', isGenerating:true, taskId}`；`SUCCESS` 写 `result`（`resultData` 文本数组 `join('\n\n')`）+ `status:'SUCCESS'` + `isGenerating:false` + `taskId:null`；失败写 `status:'FAILED'` + `isGenerating:false` + `errorMessage` + `taskId:null`。

**输出**：stdout 单行 JSON。
- 不带 `--wait`：含 `kind`(`"text"`) / `nodeKey` / `taskId` / `status`(`"PENDING"`) / `backfilled`(布尔) / `waited`(`false`)。
- 带 `--wait`：含 `kind` / `nodeKey` / `taskId` / `status` / `resultData`(文本数组) / `dataField`(`"result"`) / `backfilled`(布尔，终态是否成功回填) / `waited`(`true`)。

### `neowow gen history <nodeKey> [flags]`

节点的**生成历史记录**：`GET /agent/story-canvas/list-generations`（网页端节点「历史生成」弹框同源）。只读、不扣积分。每条记录含该次提交的 `taskId`/`status`/`dataType`/`createTime`/模型/prompt/`resultData`（结果 URL 数组）——**节点 `data` 只存最近一次结果，历次出图/出视频都在这里**；配合 `poll <taskId> --apply` 可续查/回填任意一次。

**位置参数**：- **`<nodeKey>`**（必填，也可 `--node <nodeKey>`）。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--status <S>` | 否 | 按状态过滤：`SUCCESS` / `FAILED` / `PENDING`（wire 层还可能出现 `RUNNING`/`PROCESSING`）。默认空 = 全部 |
| `--full` | 否 | 返回后端原始记录（含 `imageRef`/`videoRef`/`musicRef` 全量参数：negativePrompt/引用 URL/长宽比等）。默认精简投影 |
| `-p, --project <sessionId>` | 条件 | 项目作用域，同其他 gen 子命令 |

**输出**：stdout 单行 JSON，含 `kind`(`"history"`) / `nodeKey` / `status`(过滤条件，`"all"`=未过滤) / `count` / `records`。slim 每条：`taskId` / `status` / `dataType` / `createTime` / `model`(显示名优先) / `prompt`(按类型从 `imageRef`/`videoRef`/音频 ref 链取) / `resultData` / 视频记录另有 `draft`(布尔，`videoRef.draft`，`true`=草稿/样片，可 `gen formal --node <nodeKey> --task <taskId>` 转正式) / 失败时 `errorMessage`。

```bash
# 查节点全部生成历史（已实测）
neowow gen history <nodeKey> | jq -r '.records[] | "\(.createTime) \(.status) \(.taskId) \(.resultData[0] // "")"'
# 只看成功的 + 拿某次历史结果 URL
neowow gen history <nodeKey> --status SUCCESS | jq -r '.records[0].resultData[]'
```

### `neowow poll <taskId> [taskId...] [flags]`

对一个或多个已有 taskId 批量轮询，直到全部到终态（`SUCCESS`/`FAILED`）。常用于先批量 `gen ... `（不 `--wait`）提交、攒一把 taskId 后统一等。默认只查状态；**带 `--apply` 才把终态回填进节点**（等价 `gen --wait` 的第 4 步）——不带它节点会停在 `PENDING`/`running`，直到网页端打开该画布恢复轮询才更新。

**位置参数**：- **`<taskId>`**（必填，可多个）：要轮询的任务 id。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--interval <秒>` | 否 | 轮询间隔秒，默认 `5`（内部 ×1000 转毫秒；网页端固定 10s） |
| `--timeout <秒>` | 否 | 总超时秒，默认 `600`（网页端无总超时）；超时抛错（stderr `[neowow]`，exit 非 0），错误信息带各任务当前状态快照与续查命令。**超时后任务仍在后端跑**，可稍后再 `neowow poll <taskId> --apply` 续查回填 |
| `--once` | 否 | **只查一轮当前状态即返回**（非终态也 exit 0，不阻塞）——「gen status」用法。输出多一个 `once:true` |
| `--apply` | 否 | 终态回填进节点：按返回项的 `nodeKey`/`dataType` 自动分派各节点类型的回填词表（见上文「状态词表」表格）。需要项目作用域（`-p <sessionId>` 或已 `project use` 绑定）。可与 `--once` 组合（只回填已终态的任务） |

**输出**：stdout 单行 JSON，含 `count`(任务数) / `tasks`(数组)；带 `--apply` 时另有 `applied`(数组，每项 `{taskId,nodeKey,kind,ok}`，视频成功项另带 `draft`——回填时按后端 `videoRef.draft` 校准了节点 `data.draft`)。`tasks[]` 每项来自 `batch-query-status`：`taskId` / `nodeKey` / `dataType` / `status` / `resultData`(URL 数组) / `errorMessage`；非终态时还可能带 **`queuedByConcurrencyLimit`**(bool) / **`aheadCount`**(number)——并发超限排队，仓库版 api 契约文档（发布包不含） §轮询端点。`--once` 时可用 jq 判排队：`jq '.tasks[] | select(.queuedByConcurrencyLimit == true) | {taskId, aheadCount}'`。

> 进度走 stderr：每次重试打 `[poll] N 个任务进行中 已等 <x>s/<总>s，<interval>s 后重试…`；有任务并发超限排队时追加 `（其中 M 个并发超限排队中，最前的前方还有 K 个）`——排队意味着还没开始跑，长视频建议加大 `--timeout`。超时错误里的状态快照也会标出 `(排队中,前方N个)`。状态查询遇到网络抖动/网关发版会指数退避自动重试（连续 5 次失败才放弃）。

## 示例

```bash
# case 1: 最简——文生图，同步等到出图（赛博朋克猫，分镜默认模型，1K 仅此模型支持）
neowow gen image --node <nodeKey> \
  --prompt "赛博朋克猫，霓虹灯，雨夜街头，电影感" \
  --model gemini-2.5-flash-image --ar 16:9 --size 1K --n 1 --wait
# stderr: [gen] 提交… / [poll] 1 个任务进行中…
# stdout: {"kind":"image","nodeKey":"<uuid>","taskId":"<id>","status":"SUCCESS",
#          "resultData":["https://…png"],"dataField":"inputImageUrls","waited":true}

# case 2: 不等待——只提交+回填 PENDING，拿 taskId 后续再 poll
TID=$(neowow gen image --node <nodeKey> --prompt "雪山日出" \
        --model gemini-2.5-flash-image --ar 16:9 --size 1K \
        | node -e "process.stdin.on('data',d=>console.log(JSON.parse(d).taskId))")
neowow poll "$TID"                      # 默认 5s 间隔 / 600s 超时

# case 3: 图生视频（首尾帧）——两张 --ref 自动转 IMAGE_TO_VIDEO，只发 firstFrame/lastFrame
neowow gen video --node <nodeKey> --model <videoModelValue> \
  --prompt "镜头缓慢推近" --resolution 1080p --duration 5 \
  --ref "https://…first.png" --ref "https://…last.png" --wait

# case 3c: 视频延长——先 dry-run 看模型默认档/引用/预估，确认后去掉 --dry-run；--total-duration=参考视频总秒数（refVideoBilling=1 模型才计价）
XM=$(neowow models video --extend | jq -r '.models[0].value')
neowow gen video --node <nodeKey> --model "$XM" --extend \
  --ref-video "https://…/clip.mp4" --total-duration 8 \
  --prompt "延长 @视频1，镜头继续向前推进，人物走出画面" --dry-run
neowow gen video --node <nodeKey> --model "$XM" --extend \
  --ref-video "https://…/clip.mp4" --total-duration 8 --duration 5 \
  --prompt "延长 @视频1，镜头继续向前推进，人物走出画面" --wait
# stdout: {"kind":"video","mode":"extend",…,"resultData":["https://…mp4"],"dataField":"inputVideoUrls","waited":true}

# case 3d: 视频编辑——--edit-video 指定待编辑视频（提到 referenceVideoUrls[0]），--duration 传它的秒数（参与计价）
EM=$(neowow models video --edit | jq -r '.models[0].value')
neowow gen video --node <nodeKey> --model "$EM" --edit \
  --edit-video "https://…/clip.mp4" --duration 8 \
  --prompt "把 @视频1 的白天改成雨夜，霓虹反光" --wait

# case 3b: 多图参考视频——--multi-ref 时全部 --ref 走 imageUrls（REFERENCE_TO_VIDEO）
neowow gen video --node <nodeKey> --model <videoModelValue> --multi-ref \
  --prompt "以这些角色为参考" --ref "https://…a.png" --ref "https://…b.png" --wait

# case 3e: 样片（草稿）→ 转正式：先用样片模型（draftModel=true）便宜出样片，满意后 gen formal 出 1080p 正式片
DM=$(neowow models video | jq -r '.models[] | select(.draftModel==true) | .value' | head -1)
neowow gen video --node <nodeKey> --model "$DM" --prompt "镜头缓慢推近" --ref "https://…first.png" --wait
# stdout: {…,"draft":true,…}   ← 画布上该节点带「草稿」角标
neowow gen formal --node <nodeKey> --dry-run | jq .estimate.points      # 预估积分，给用户确认
neowow gen formal --node <nodeKey> --wait                                # 右侧新建「正式视频」节点并连线，结果回填到新节点

# case 1b: 透明底出图（仅 gpt-image-2.5 系列；两个开关都不传时沿用节点 data.transparentBackground）
neowow gen image --node <nodeKey> --prompt "一枚金色徽章，无背景" \
  --model gpt-image-2.5-flare --size 2K --quality medium --transparent --wait

# case 4: 语音合成（minimax v1，指定音色与情绪）
neowow gen audio --node <nodeKey> --sound <音色id> \
  --text "欢迎来到 NeoWoW 画布" --emotion happy --rate 1.0 --wait

# case 4b: 语音合成（seed-audio v2，参考音频克隆音色，无需 --sound）
neowow gen audio --node <nodeKey> --engine seed \
  --text "欢迎来到 NeoWoW 画布" --ref-audio "https://…voice-sample.mp3" --wait

# case 4c: seed-audio v2 全参数（先 dry-run 看预估积分与提交体，确认后去掉 --dry-run）
#   注意：--ref-audio(≤3) 与 --ref-image(1) 互斥，二选一
neowow gen audio --node <nodeKey> --engine seed \
  --text "那一夜，雨没有停。" \
  --ref-image "https://…character.png" \
  --format mp3 --sample-rate 24000 --speech-rate -10 --loudness-rate 20 --pitch-rate 0 \
  --dry-run
# stdout: {"kind":"audio","dryRun":true,…,"body":{…"imageUrl":"…","audioConfig":{…}},
#          "estimate":{"points":5,"billedSeconds":2,"exceedsMax":false}}

# case 5: 纯音乐（--instrumental 时歌词强制清空）
neowow gen music --node <nodeKey> --prompt "史诗交响，恢弘大气" --instrumental --wait

# case 6: 歌词（同步，不轮询；--node 可选，按音乐面板键回填）
neowow gen lyrics --prompt "关于夏天的告别" --title "蝉鸣" --node <audioNodeKey>
# stdout: {"kind":"lyrics","sync":true,"songTitle":"…","styleTags":[…],"lyrics":"…","taskCode":"…","backfilledNode":"<nodeKey>"}

# case 7: 文本生成（text 节点跑 LLM，异步 + --wait）
neowow gen text --node <textNodeKey> --prompt "为这段分镜写 3 句旁白" --wait
# stdout: {"kind":"text","nodeKey":"…","taskId":"…","status":"SUCCESS",
#          "resultData":["…"],"dataField":"result","waited":true}

# case 8: 批量轮询多个已提交任务（默认 --interval 5 --timeout 600，可显式覆盖）
neowow poll <taskId1> <taskId2> <taskId3> --interval 5 --timeout 600
```
