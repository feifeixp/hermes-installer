# `neowow node` — 画布节点的增删改查

`neowow node` 是对画布**节点**（node）的一组增删改查命令。它本身没有逐节点的 REST 端点——`create / update / delete` 三种写操作在内部统一打包成 `POST /agent/story-canvas/batch-operation` 的 `actions[]` 发送（仓库版 api 契约文档（发布包不含）），逐条核对 `results[].success`；`list` 则是读取整盘会话再本地过滤。节点 id（UUID v4，由本工具生成）同时也是后续 `neowow gen` 的 `nodeKey`。

入口与全局约定（输出契约、鉴权、项目作用域 `-p/--project` 或 `.neowow/project.json`、环境变量）见 [./project.md](./project.md) 顶部说明，本篇不复述。

> 本文件即完整选项真源；速查用 `neowow node --help`（离线，不发请求）。仓库版另有 `lib/node.mjs` 源码与 api/ 端点契约（含尺寸公式），发布包不含。

## 子命令
| 子命令 | 作用 |
| --- | --- |
| `neowow node create -t <type> ...` | 新建一个节点（默认坐标 0,0、尺寸 280×280） |
| `neowow node get <nodeKey>` | 单节点**完整详情**（含全部 `data.*`：taskId/引用/生成结果） |
| `neowow node update <nodeKey> ...` | 整份取回 + 增量改某节点的 `data` 后写回 |
| `neowow node delete <nodeKey> [<nodeKey>...]` | 删除一个或多个节点 |
| `neowow node list` / `ls` | 列出当前会话的节点（精简视图，可按类型过滤） |

> 缺省子命令是 `list`：`neowow node`（首参不是已知子命令时）等价于 `neowow node list`。`list` 与 `ls` 是别名。

公共选项（任意子命令可用）：

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `-p, --project <sessionId>` | 条件 | 指定项目会话 id；省略则用当前目录绑定的项目，二者都无则报错 |

类型枚举 `-t/--type`（`lib/sizing.mjs` `NODE_TYPES`，与 仓库版 api 契约文档（发布包不含） 一致）：
`text` · `image` · `video` · `audio` · `mediaInput` · `group` · `comment` · `videoComposition` · `sceneComposer` · `worldModel`

### `neowow node create -t <type> [flags]`

新建节点。`measured`（画布上的渲染尺寸）按优先级决定：显式 `--media-w` + `--media-h` ＞ `--aspect "W:H"` ＞ 默认 `280×280`。短边恒钉 280，长边按长宽比放大、无上限（公式仓库版 api 契约文档（发布包不含））。CLI **只发 `measured`、不发 `data._initialMeasured`**——前端保存时本来就会剥掉该键，画布加载时由 `measured` 重建，wire 形状与网页端一致（仓库版 api 契约文档（发布包不含））。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `-t, --type <type>` | 是 | 节点类型，取上面 10 个枚举之一 |
| `--x <n>` | 否 | 画布 x 坐标，默认 `0` |
| `--y <n>` | 否 | 画布 y 坐标，默认 `0` |
| `--aspect <W:H>` | 否 | 长宽比，自动算 `measured`（短边 280）；别名 `--ar`、`--aspectRatio`。分隔符支持 `:` `/` `x` `×`，如 `16:9` |
| `--media-w <n>` | 条件 | 媒体内在宽（像素）；与 `--media-h` **成对**给才生效，优先级高于 `--aspect`。别名 `--mediaW` |
| `--media-h <n>` | 条件 | 媒体内在高（像素）；与 `--media-w` 成对。别名 `--mediaH` |
| `-s, --set <k=v>` | 否 | 写入 `data.<k>` 顶层（支持 `a.b=1` 深路径）；可重复。与 `-u` 同通道，共用拒写表（见下） |
| `-u, --update <k=v>` | 否 | 同 `-s`，写入 `data.<k>` 顶层；可重复。两者可混用，同键时 `-s` 后应用、覆盖 `-u` |
| `--data <json>` | 否 | 一次性合并一整段 JSON 进 `data`（先于 `-s`/`-u` 铺底）。**不过拒写表**，是覆写运行期字段的唯一逃生通道 |
| `--prompt <文本>` | 否 | 等价于 `-s prompt=<文本>`，即写入 `data.prompt`（最后应用，覆盖 `-s`/`-u` 的同键值） |
| `--content <文本>` | 否 | **text 节点专用**：写入 `data.result`——文本节点在画布上展示的正文。非 text 节点报错 |
| `--name <文本>` | 否 | 设置 `data.label`（节点中文标签） |

> `-s/--set` 与 `-u/--update` **写的是同一个地方：`data.*` 顶层**。生成参数的真源就在 `data` 顶层（如 `data.prompt` / `aspectRatio` / `batchSize` / `resolution`）——历史上的 `data.params` 通道已废除，前端全库不读它。两者共用一张**拒写表**，命中直接报错：
> - `params` / `params.*` → ❌ 前端不读的死键，生成参数直接写顶层（如 `-s prompt=...`）
> - `label` / `name` → ❌ 展示名请用 `--name`
> - 运行期字段 `_initialMeasured` / `taskId` / `status` / `isGenerating` / `uploadProgress` / `uploadError` / `type`（含其深路径）→ ❌ 由 gen 状态机与画布维护，误写会破坏节点状态；确需覆写用 `--data '{"status":...}'` 逃生
> 值会被自动还原类型：`true/false/null`、纯数字、`[...]`/`{...}` JSON 串都会转成原生类型，其余按字符串。`k` 支持点路径（如 `-s foo.bar=1` → `data.foo.bar`）。应用顺序：`--data` 铺底 → `-u` → `-s` → `--prompt`/`--name`/`--content`。
>
> ⚠️ **text 节点的正文在 `data.result`，不在 `data.prompt`**：画布把 `result` 当内容展示；`prompt` 只是「让 LLM 生成」的提示词（`gen text` 的输入）。把写好的脚本/文案放进节点用 `--content <文本>`（等价 `-s result=<文本>`），别塞 `--prompt`——否则画布上节点是空的。

**输出**：stdout 单行 JSON，含 `action`（`"create"`）/ `nodeKey`（新节点 UUID，即后续 gen 的 nodeKey）/ `type` / `measured`（`{width,height}`）/ `position`（`{x,y}`）/ `results`（batch 返回的逐条结果数组，每项含 `action`/`objectType`/`objectId`/`success`）。

### `neowow node update <nodeKey> [flags]`

改某节点。先按 `nodeKey` 在会话里取回当前节点，把**整份 `data` 原样带上**再叠加增量改动后整体 `update`（后端要求 update 必须整发 data，仓库版 api 契约文档（发布包不含））。

**位置参数**：
- **`<nodeKey>`**（必填）：要改的节点 id；也可用 `--id <nodeKey>` 给。找不到该节点会报错。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `-s, --set <k=v>` | 否 | 写入/覆盖 `data.<k>` 顶层（支持深路径）；可重复。拒写表同 create（`params`/`params.*`、`label`/`name`、运行期字段） |
| `-u, --update <k=v>` | 否 | 同 `-s`，写入/覆盖 `data.<k>` 顶层；可重复 |
| `--data <json>` | 否 | 合并一整段 JSON 进 `data`（不过拒写表，覆写运行期字段的逃生通道） |
| `--prompt <文本>` | 否 | 写入 `data.prompt`（LLM 生成用的提示词，**不是**文本节点的正文） |
| `--content <文本>` | 否 | **text 节点专用**：写入 `data.result`（画布展示的正文）。非 text 节点报错 |
| `--name <文本>` | 否 | 设置 `data.label` |
| `--x <n>` / `--y <n>` | 否 | 重定位节点（改 `node.position`）；只给一个时另一轴保留原值 |

**输出**：stdout 单行 JSON，含 `action`（`"update"`）/ `nodeKey` / `position` / `results`（逐条 batch 结果）。

### `neowow node delete <nodeKey> [<nodeKey>...]`

删一个或多个节点。可用位置参数堆叠多个 id，也可用 `--id <nodeKey>`（与位置参数合并去重）。至少要给一个，否则报错。

**位置参数**：
- **`<nodeKey>...`**（必填，可多个）：要删除的节点 id 列表。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--id <nodeKey>` | 条件 | 另一种给单个 id 的方式；与位置参数可同时给 |

**输出**：stdout 单行 JSON，含 `action`（`"delete"`）/ `nodeKeys`（被删 id 数组）/ `results`（逐条 batch 结果）。

### `neowow node get <nodeKey>`

单节点完整详情：返回该节点的整个对象（`id`/`type`/`position`/`measured`/**全部 `data.*`**——`taskId`、`connected*`、`manualReferences`、生成结果 `inputImageUrls` 等都在这）。gen 后验证结果、排查引用用它，**不要再 `project get` 全量 dump 整盘画布**。

**输出**：stdout 单行 JSON，含 `sessionId` / `node`（完整节点对象）。找不到节点时报错 exit 非 0。

### `neowow node list` / `ls` [flags]

列出当前会话的节点，返回精简视图（不含完整 data）。读取整盘会话后本地按类型过滤。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `-t, --type <type>` | 否 | 只列该类型的节点（枚举同 create） |

**输出**：stdout 单行 JSON，含 `scope`（`"session=<sessionId>"`）/ `count`（条数）/ `nodes`（数组，每项含 `nodeKey` / `type` / `label` / `status` / `position`）。

## 示例

```bash
# case 1: 最简——在当前绑定项目里建一个默认 280×280 的 image 节点
neowow node create -t image

# case 2: 指定坐标 + 16:9 自动算 measured（→ {width:498,height:280}）
neowow node create -t image --x 320 --y 120 --aspect 16:9
# stdout: {"action":"create","nodeKey":"<uuid>","type":"image","measured":{"width":498,"height":280},
#          "position":{"x":320,"y":120},"results":[{"action":"create","objectType":"node","objectId":"<uuid>","success":true}]}

# case 3: 用真实媒体宽高算尺寸（成对给 --media-w/--media-h，优先于 --aspect）
neowow node create -t video --media-w 1080 --media-h 1920   # 竖屏 → {width:280,height:498}

# case 4: -s/-u 都写 data 顶层——生成参数（prompt/model/aspectRatio…）与业务字段同一通道
neowow node create -t image \
  --x 320 --y 120 --aspect 16:9 \
  --prompt "赛博朋克猫，霓虹灯，雨夜街头，电影感" \
  -s model=gemini-2.5-flash-image \
  -s aspectRatio=16:9 \
  --name 分镜A               # ✅ -s model=.. → data.model；展示名走 --name（-s/-u label=.. 会被拒）

# case 5: 一段 JSON 直接铺底 data，再用 -s/-u 叠加微调（-s size=1K → data.size）
neowow node create -t image --data '{"negativePrompt":"模糊"}' -s size=1K

# case 6: 改节点——补负向提示词 + 改提示词（都写 data 顶层：data.negativePrompt / data.prompt）
neowow node update 7f3c... -u negativePrompt=低画质 --prompt "夜晚的城市，电影感，超清"

# ❌ 反例：命中拒写表会直接报错
neowow node update 7f3c... -s params.model=gemini-2.5-flash-image   # 报错：data.params 是死键，直接 -s model=...
neowow node update 7f3c... -u label=封面                            # 报错：展示名请用 --name
neowow node update 7f3c... -s status=SUCCESS                        # 报错：运行期字段；确需覆写用 --data '{"status":"SUCCESS"}'

# case 7: 删除一个/多个节点
neowow node delete 7f3c...
neowow node delete 7f3c... a91b... --id c4d2...

# case 8: 列出当前会话所有节点 / 只看 image 节点
neowow node list
neowow node ls -t image

# case 9: 在指定项目（非当前绑定）里建节点
neowow node create -t text -p 2070376818284032000 --name 旁白脚本
```
