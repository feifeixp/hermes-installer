# neowow review —— 素材校验（Seedance2.0 真人合规验证）

对应画布节点面板的「批校验」弹框（EditingSection / UniversalSection / ExtendSection 的
batch-review-dialog）：把节点引用的图片/视频/音频逐个提交真人合规校验，通过后回写「已审核」
状态——之后网页端缩略图角标直接显示绿色已审核，生成时不再被合规校验卡住。

```bash
# 节点批校验：连线素材 + 手动素材全量校验，通过项回写审核状态
neowow review --node <nodeKey> [--force] [--dry-run] [--concurrency 3] [-p <sessionId>]

# 直接校验 URL（不回写节点，适合 upload 后立即预检）
neowow review --url <url> [--url <url>...]
```

## 首次使用：--agree 同意《素材权益承诺书》

网页端首次校验会弹《素材权益承诺书》确认框（承诺素材具备合法权益、真人素材已获授权）。
CLI 的对应物是 `--agree`：

- 未同意时执行 review 会报错退出（exit 2，errCode=AGREEMENT_REQUIRED），**把承诺书要点转告用户、
  经用户确认后**再加 `--agree` 重跑；
- 同意状态记入 `~/.neowow/config.json`（`assetAgreementAccepted: true`），之后不再询问；
- `--dry-run` 不提交任何请求，无需同意。

## 行为细节（与网页端弹框逐条对齐）

| 行为 | 说明 |
| --- | --- |
| 素材收集 | 连线素材按当前会话**现算**（同 gen 的 connected* 刷新，不吃过期快照）+ 节点手动素材数组（`manualReferences` / `editingManualReferences` / `extendManualReferences`），按 URL 去重 |
| 已审核跳过 | `connectedReviewedMap[url]` / 手动项 `reviewed:true` 的直接记通过，不重复提交；`--force` 全量重跑 |
| 并发 | 默认 3 个在途（同网页端），`--concurrency` 可调（1–8） |
| 图片归一化 | 提交前查 OSS `image/info`：宽或高 >6000px、或 >30MB 时改用 `x-oss-process=image/resize` 缩放 URL 提交（查询失败则原样提交）；视频/音频原样提交 |
| 端点 | `POST /agent/ark-asset-review/submit`，body `{ imageUrl }`（图/视频/音频都走该字段，仓库版 api 契约文档（发布包不含）） |
| 回写 | 通过的**连线素材**：上游节点 `data.reviewed=true`（真持久层）+ 本节点 `connectedReviewedMap[url]=true`；**手动素材**：所在数组项 `reviewed:true`。全部改动合成一次 batch-operation |
| 失败处理 | 单项未通过不中断其余项；回写失败只在 stderr 告警（校验结果有效，下次会重新提交未记住的项） |

## 输出

stdout 单行 JSON（进度走 stderr）：

```json
{
  "sessionId": "…", "nodeKey": "…",
  "total": 5, "checked": 3, "passed": 3,
  "failed": [{ "label": "图片2", "url": "…", "error": "含未授权真人内容" }],
  "skippedReviewed": 2,
  "allPassed": false,
  "writeBack": { "updatedNodes": ["node-a", "node-b"], "upstreamMarked": ["node-a"] },
  "items": [{ "label": "图片1", "type": "image", "source": "connected", "url": "…", "status": "passed" }]
}
```

- `allPassed:true` 表示节点全部素材（含此前已审核的）均通过——可作为生成前的门禁：
  `neowow review --node $NODE && neowow gen video …`（注意有未通过项时命令本身仍 exit 0，
  agent 应看 JSON 的 `allPassed` / `failed`）。
- `--dry-run` 输出 `{ dryRun:true, total, wouldCheck, skippedReviewed, items }`，不发任何请求。

## 典型链路

```bash
# 上传后先预检，再挂到节点上
neowow upload ./face.png image            # → 拿到 URL
neowow review --url https://…/face.png --agree

# 生成前把节点素材一次校验干净
neowow review --node node-xxx --dry-run   # 先看清单
neowow review --node node-xxx             # 校验并回写（已 --agree 过）
```
