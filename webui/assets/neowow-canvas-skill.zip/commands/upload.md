# `neowow upload` — 本地文件直传 OSS（MD5 去重 + 图片回吐 measured，可选直接建节点）

把本地的图片 / 视频 / 音频 / `.spz` 直传到 OSS，拿回一个可用的 URL；命中相同 MD5 时免传复用旧 URL。图片会额外取宽高算出 `measured`（节点尺寸）。加 `--create-node` 时直接在画布上建一个**上传节点**（`data.type='upload'`，URL 落在对应 `inputXxxUrls`，无左输入口）。

> 入口与全局约定见 [./project.md](./project.md) 顶部说明，本篇不复述；本命令的 stderr 前缀是 `[upload]`。
> 本文件即完整选项真源；速查用 `neowow upload --help`（离线，不发请求）。仓库版另有 `lib/upload.mjs` 源码与 api/ 端点契约，发布包不含。前置登录见 [./login.md](./login.md)。

## 子命令

`upload` 是单一动作命令（无子命令）。形态：

```
neowow upload <文件> [image|video|audio|worldModel] [--create-node] [--duration <秒>]
```

### `neowow upload <文件> [type] [flags]`

**位置参数**
- **`<文件>`**（必填）：本地文件路径。读不到时报“文件不存在或不可读”。等价于 `-f, --file`。
- **`[type]`**（可选）：媒体类型，枚举 `image` / `video` / `audio` / `worldModel`。等价于 `-t, --type`。不传则**按扩展名推断**：
  - `image`：`jpg/jpeg/png/webp/gif`
  - `video`：`mp4/webm/mov`
  - `audio`：`mp3/wav/ogg/m4a/aac`
  - `worldModel`：`spz`
  - 推不出来时报错，要求显式指定。

**大小硬校验**（读入文件后立即检查，超限直接报错、不发任何请求；镜像前端 `mediaUploadLimits.js` 的 `MEDIA_MAX_SIZE`——前端同样会拒，CLI 不拦会传出网页端传不出来的「超规格」素材）：

| 类型 | 上限 |
| --- | --- |
| image | 60 MB |
| video | 200 MB |
| audio | 50 MB |
| worldModel | 300 MB |

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `-f, --file <path>` | 否 | 文件路径的具名写法（与第 1 个位置参数等价）。 |
| `-t, --type <v>` | 否 | 媒体类型，枚举 `image` / `video` / `audio` / `worldModel`（与第 2 个位置参数等价）。不传按扩展名推断。 |
| `--create-node` | 否 | 布尔开关。上传后直接在画布建一个上传节点（仅支持 `image` / `video` / `audio`，`worldModel` 会报错）。默认不建节点，只回吐 URL。 |
| `--duration <秒>` | 否 | 仅 `video`：时长随预签名请求（`/agent/oss/upload-url`）以 `durationMs`（毫秒）上报，CLI 自动把秒换算成毫秒。前端上传视频时会自动读时长上报、下游合成链路会读；CLI 解不了视频容器，需要时**显式传**。 |
| `-p, --project <sessionId>` | 条件 | 仅 `--create-node` 时生效：指定写入的项目（会话）。不传则用当前目录 `.neowow/project.json`（`neowow project use` 绑定，见 [./project.md](./project.md)）。 |
| `--x <n>` | 否 | 仅 `--create-node` 时生效：新节点 x 坐标，默认 `0`。 |
| `--y <n>` | 否 | 仅 `--create-node` 时生效：新节点 y 坐标，默认 `0`。 |

**输出**：stdout 单行 JSON。

不带 `--create-node`（直传，来自 `uploadFile`）：含 `url`（OSS URL）/ `mediaType`（解析出的类型）/ `dataField`（该类型对应的 data 字段名，`image→inputImageUrls`、`video→inputVideoUrls`、`audio→inputAudioUrls`、`worldModel→spzUrl`）/ `reused`（布尔，`true`=命中 MD5 复用、未真正上传）/ `measured`（仅图片为 `{width,height}`，其它类型为 `null`）。

带 `--create-node`：在上面字段基础上**追加** `nodeKey`（新节点 id / uuid）与 `sessionId`（写入的项目）。

> stderr 进度（前缀 `[upload]`）：命中 MD5 时打印“命中相同 MD5，复用：<url>”；否则打印“上传 → <https URL>”。⚠️ `image-record/save` 登记失败是**致命错误**（整条命令失败、exit 非 0），对齐前端 `oss.js`：不登记则 MD5 去重失效（下次重复上传）、`reviewed` 状态缺失。

#### MD5 去重（reused）
> ⚠️ **`worldModel`（`.spz`）当前传不了**：上传已改走后端预签名（`POST /agent/oss/upload-url`），其扩展名白名单暂未放行 `.spz`，会直接报「不支持的文件类型」。图/视频/音频不受影响。

上传前先 `GET /agent/image-record/query?imageMd5=<md5>`：命中则 `reused:true` 直接复用旧 URL，跳过取预签名地址与 OSS PUT；未命中走 `POST /agent/oss/upload-url` 预签名直传后 `reused:false`，并 `POST /agent/image-record/save` 登记 `md5→url`（save 失败即整体失败，见上）。文件名固定为 `<md5>.<ext>`，天然去重（后端也按扩展名做类型白名单，无后缀会被拒）。

#### 图片回吐 measured
仅当 `mediaType==='image'` 时，对 OSS URL 追加 `?x-oss-process=image/info` 取真实宽高，按短边恒 280、长边按长宽比的规则算出 `measured`（如 1920×1080 → `{width:498,height:280}`）。视频 / 音频 / worldModel 不取尺寸，`measured` 为 `null`。

#### `--create-node`：直接建上传节点
节点 `type` 取 `image|video|audio`（**不是 `mediaInput`**），节点 `data` 被打成上传节点：`data.type='upload'`、`data.mediaSource='upload'`、并把 URL 写进 `data[dataField]=[url]`（如 `inputImageUrls:[url]`）。同时写 `data.label`（=**去扩展名的文件名**，空则兜底「图片上传/视频上传/音频上传」）与 `data.fileName`（原始文件名）——镜像前端 `applyUploadedNodeData`，否则画布上节点没名字。图片节点同时落 `measured`。

> ⚠️ `data.type='upload'` 的节点**没有左输入口**，不能作为连线 target（仓库版 api 契约文档（发布包不含））。✅ 想要可被连入的占位输入，请改用 `neowow node create`（见 [./node.md](./node.md)）。❌ `worldModel`（`.spz`）暂不支持 `--create-node`，只能直传拿 URL。

## 示例

```bash
# case 1: 最简——按扩展名推断为 image，直传拿 URL（不建节点）
neowow upload ./cat.png
# → {"url":"https://wlpaas.oss-accelerate.aliyuncs.com/dify/dev/<uid>/workflow/images/<md5>.png",
#    "mediaType":"image","dataField":"inputImageUrls","reused":false,"measured":{"width":498,"height":280}}

# case 2: 第二次传同一文件——命中 MD5，免传复用（reused=true）
neowow upload ./cat.png
# stderr: [upload] 命中相同 MD5，复用：https://…/<md5>.png
# stdout: {"url":"https://…/<md5>.png","mediaType":"image","dataField":"inputImageUrls","reused":true,"measured":{"width":498,"height":280}}

# case 3: 显式指定类型（扩展名不规范 / 想强制）
neowow upload ./clip.bin video
neowow upload -f ./voice.dat -t audio

# case 4: 直传并直接在当前绑定项目建一个 image 上传节点，指定坐标
neowow upload ./poster.jpg --create-node --x 320 --y 120
# → {"url":"https://…/<md5>.jpg","mediaType":"image","dataField":"inputImageUrls",
#    "reused":false,"measured":{"width":498,"height":280},
#    "nodeKey":"<uuid>","sessionId":"2070376818284032000"}

# case 5: 建节点时用 -p 覆盖项目（不依赖当前目录绑定）
neowow upload ./bgm.mp3 --create-node -p 2070376818284032000

# case 5b: 上传视频并带时长（随预签名请求上报 durationMs，下游合成链路会读）
neowow upload ./clip.mp4 --duration 12.5 --create-node

# case 6: 用 NEOWOW_API_KEY 临时鉴权 + piped 取 url 字段
NEOWOW_API_KEY=$API_KEY neowow upload ./shot.png | node -e 'process.stdin.on("data",d=>console.log(JSON.parse(d).url))'
```
