# `neowow update` — 自更新

CLI 与 skill 文档一起从发布 CDN 拉最新版换装本机安装，一条命令完成。**更新是显式动作**：完全静默的自动替换刻意不做（会话中途换版本会破坏可复现性，agent 跑批量任务时尤其危险）——"自动"体现在被动提醒自动出现（见下）。

## 用法

```bash
neowow update            # 有新版：下载 tgz → SHA-256 校验 → 换装已安装的 skill 目录；无新版：{"upToDate":true}
neowow update --check    # 只对比版本不安装：{"current","latest","updateAvailable","base"}
```

## 机制

- **版本源**：`<CDN>/latest.json`（pack.sh 发版时生成），含 `version`（构建指纹 `vX.Y.Z+git哈希.打包时间`）与内容寻址包名 + SHA-256。
- **版本比较**：按构建指纹尾部打包时间戳比新旧；本地是源码运行（无指纹）时视为可更新。
- **换装目标**：`~/.claude/skills/neowow-canvas` 与 `~/.agents/skills/neowow-canvas` 里**已存在且含 SKILL.md** 的目录（防误删非本 skill 目录，同 setup.sh 口径）。两处都装了就都更新；一处都没有则报错，首次安装走 install.sh。
- **完整性**：下载后本地重算 SHA-256 与 `latest.json` 比对，不符拒装。解包用系统 `tar`（macOS / Linux / Windows 10+ 都内置）。
- **`~/.neowow/bin/neowow` 启动器与登录凭据不受影响**（路径不变、只换目录内容）。

## 被动提醒（"自动"的部分）

任意命令执行完后，CLI 每 **24 小时**最多检查一次新版（2.5s 超时、失败静默、绝不影响命令本身），发现新版在 stderr 打一行：

```
[update] 新版本 v0.2.0+abc1234.20260801T120000Z 可用（当前 …）：neowow update 一键更新
```

**Agent 看到这行提醒时：告知用户有新版本，经确认后执行 `neowow update`**（正在跑批量生成任务时先跑完再更）。

## 相关环境变量

| 变量 | 作用 |
| --- | --- |
| `NEOWOW_NO_UPDATE_CHECK=1` | 关闭被动提醒（`neowow update` 本身不受影响） |
| `NEOWOW_UPDATE_BASE` | 覆盖更新源（默认发布 CDN；测试/私有镜像用） |

节流状态存 `<配置目录>/update-check.json`（独立于凭据文件）。源码运行（无构建指纹）不做被动提醒，不打扰开发。
