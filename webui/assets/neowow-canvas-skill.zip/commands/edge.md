# `neowow edge` — 节点连线（边）的创建与删除

入口与全局约定（输出契约、鉴权头 `api-key`、项目作用域 `-p/--project` 或 `.neowow/project.json`、环境变量）见 [./project.md](./project.md) 顶部说明，本篇不复述。

`neowow edge` 在画布上把两个节点连成一条有向边（`source → target`）。边和节点一样走后端的 `batch-operation`（把边放进 `actions[].edges`）。需要先 [登录](./login.md) 且当前有项目作用域（`-p/--project <sessionId>` 或当前目录已 `neowow project use` 绑定）。

建边时若不显式给 handle，会按节点类型自动推断输入/输出 handle，并默认做类型校验 + 成环检测；想跳过校验用 `--no-validate`。新建边 id 为 `e-<source>-<target>`，但**幂等按 `(source, target)` 判断而非按 id**：画布上还存在粘贴产生的 `e-<时间戳>-<rand>` 等非规范 id 边（前端复制粘贴路径），只比 id 会在同一对节点间建出平行边——同一对节点已有边时直接**复用那条真实边**并返回 `action:"sync"`（不报错、不新建），否则 `action:"create"`。删除时也可只给两端节点，在会话里查真实边。

> **关键（参考素材同步）**：建边时 CLI 会**自动重算 target 节点的 `data.connectedImageUrls`/`connectedVideoUrls`/`connectedAudioUrls`/`connectedReviewedMap`/`inputTexts`** —— 把所有入边上游节点的素材 URL 按 handle 分类去重写进 target.data，上游 `data.reviewed` 为真的 URL 记进 `connectedReviewedMap[url]=true`（空则为 `null`），镜像前端 `useEdgeOperations.js` 连线收集逻辑。**生成时的参考图/`references` 就来自这个字段**：只建边不写它，画布看不到参考图、重新生成也不带参考。上游素材**已生成**后再连边（或连过后再 `edge create` 同一对触发 `sync`）即可刷新。**删边同样会用剩余边重算回收这些字段**（见 delete 一节）。`--no-sync` 对建边/删边都生效，跳过该回写。

> 本文件即完整选项真源；速查用 `neowow edge --help`（离线，不发请求）。仓库版另有 `lib/edge.mjs` 源码与 api/ 端点契约，发布包不含。

## 子命令
| 子命令 | 作用 |
| --- | --- |
| `neowow edge create ...` | 在 source→target 之间建一条边（默认子命令，可省略 `create`） |
| `neowow edge delete ...` | 删除边（按 `--id` 或 `--source`/`--target` 在会话里找真实边，可能多条），并回收重算 target 的 `connected*` |
| `neowow edge list` | 连线拓扑一览（slim 投影）；`--node <nodeKey>` 只看与某节点相关的边 |

> 别名：`create` 亦可写作 `add`；`delete` 亦可写作 `rm`；`list` 亦可写作 `ls`。不带子命令时（首参不在已知子命令内）默认走 `create`。

### `neowow edge create [flags]`

在 `source` 节点的输出口与 `target` 节点的输入口之间建一条有向边。

**选项**
| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `-s, --source <nodeKey>` | 是 | 源节点 id（边从它的**输出** handle 拖出）✅ source 是「上游/出」 |
| `-t, --target <nodeKey>` | 是 | 目标节点 id（边连到它的**输入** handle）✅ target 是「下游/入」 |
| `--source-handle <h>` | 否 | 源输出 handle；缺省时按 source 节点类型自动推断（见下表） |
| `--target-handle <h>` | 否 | 目标输入 handle；缺省时按 target 节点类型自动推断（见下表） |
| `--no-validate` | 否 | 布尔，跳过类型校验 + 成环检测（仍会尝试推断 handle）。默认关闭（即默认校验） |
| `--no-sync` | 否 | 布尔，跳过 target 节点 `connected*`/`inputTexts` 的重算回写。边已存在且 `--no-sync` 时输出 `action:"noop"` |
| `-p, --project <sessionId>` | 条件 | 覆盖当前绑定项目；未绑定时必填 |

**handle 自动推断**（未显式给 handle 时按节点类型查表；`source` 取输出 handle，`target` 取输入 handle）：

| 节点类型 | 输出 handle（source 用） | 输入 handle（target 用） |
| --- | --- | --- |
| `mediaInput` | `media` | （无输入） |
| `text` | `text` | `prompt` |
| `image` | `image` | `image` |
| `video` | `video` | `image` ⚠️（输入 handle 字面就叫 `image`，但接受视频） |
| `audio` | `audio` | `prompt` |
| `videoComposition` | `video` | `media` |
| `sceneComposer` | `image` | `media` |
| `worldModel` | `image` | `media` |

> ⚠️ video→video 一条边是 `sourceHandle:'video'`、`targetHandle:'image'`（video 的输入 handle 名就是 `image`）。
> 自动推断要求会话里能找到 source/target 两个节点；若找不到且你又没显式给 `--source-handle`/`--target-handle`，会报「会话里找不到 source/target 节点，无法自动推断 handle」——**此时必须显式同时给 `--source-handle` 和 `--target-handle`**。仅加 `--no-validate` 不够：缺 handle 时仍会进入推断流程，并因找不到节点报同一错误（`--no-validate` 只关掉类型/成环校验，不会跳过 handle 推断）。

**正向类型校验**（默认开启，源类型 → 允许的目标类型；不在允许集内即拒绝，确认无误可加 `--no-validate`）：

| 源类型 | 允许的目标类型 |
| --- | --- |
| `image` | `text`, `image`, `imageLayerEdit`, `video`, `videoComposition`, `sceneComposer`, `worldModel` |
| `video` | `text`, `image`, `imageLayerEdit`, `video`, `videoComposition`, `sceneComposer`, `worldModel` |
| `text` | `text`, `image`, `imageLayerEdit`, `video`, `audio` |
| `audio` | `text`, `video`, `videoComposition`, `audio` |
| `videoComposition` | `text`, `video` |
| `sceneComposer` | `image`, `video` |
| `worldModel` | `image`, `video` |

> `mediaInput` 作为源**不设**正向类型限制（正向表里没有 `mediaInput` 键）。
> ❌ 自环（`source === target`）始终被拒：`拒绝连接：自环`。
> ❌ **无输出/输入口的类型被拦**（镜像网页端 `isValidConnection`：handle 必须 ∈ `getNodeOutputs`/`getNodeInputs`）：source 类型必须在输出 handle 表内——`comment`/`group` 无输出口，不能作 source；target 类型必须在输入 handle 表内——`comment`/`group`/`mediaInput` 无输入口，不能作 target。这类边在画布上物理不可能存在，建了会渲染异常。
> ❌ target 节点 `data.type === 'upload'` 或 `'converted'` 被拒：这类节点无左输入口，不能作 target（`拒绝连接：目标节点 <id> 是 <type> 节点，无左输入口`）。

**成环检测**（默认开启）：若沿现有边从 `target` 能到达 `source`，则新边会闭环。成环边**后端照存**，是前端加载反序列化时才丢弃（`serialization.js` `deserializeEdges`），存进去就会污染数据——所以 CLI 默认本地拦截并报 `拒绝连接：会形成闭环`。加 `--no-validate` 可跳过。

**输出**：stdout 单行 JSON，含 `action`（新建为 `"create"`；边已存在、仅重算回写时为 `"sync"`；已存在且 `--no-sync` 时为 `"noop"`）/ `edgeId`（新建为 `e-<source>-<target>`；复用已有边时为其真实 id）/ `source` / `target` / `sourceHandle` / `targetHandle` / `connected`（本次回写的完整对象：`connectedImageUrls`/`connectedVideoUrls`/`connectedAudioUrls`/`connectedReviewedMap`/`inputTexts`，各自无则 `null`；`--no-sync` 或 target 不在会话时整体为 `null`）/ `results`（batch-operation 的回执数组）。

### `neowow edge list [flags]`

连线拓扑一览（读取整盘会话后本地投影，不写任何东西）。查「画布现在怎么连的」用它，**不要 `project get` 全量 dump**。

**选项**

| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--node <nodeKey>` | 否 | 只列与该节点相关的边（source 或 target 命中） |

**输出**：stdout 单行 JSON，含 `sessionId` / `count` / `edges`（数组，每项 `edgeId` / `source` / `target` / `sourceHandle` / `targetHandle`）。

### `neowow edge delete [flags]`

删除边，并**回收重算**受影响 target 的参考素材字段。流程（镜像前端删边行为，`useEdgeOperations.js` 删边路径）：

1. 加载会话，按 `--id` 精确匹配、或按 `(source, target)` 匹配**真实存在的边**——兼容粘贴产生的 `e-<时间戳>-<rand>` 等非规范 id；同一对节点间若有多条平行边会**全部命中、全部删除**。
2. 对每个受影响的 target 节点，用**剩余边**重算 `connectedImageUrls`/`connectedVideoUrls`/`connectedAudioUrls`/`connectedReviewedMap`/`inputTexts` 并与删除**同批**回写（`--no-sync` 跳过）。只删边不回收 → target 残留幽灵参考图，且网页端兜底只遍历仍有入边的节点，救不回。
3. 会话里找不到匹配边时（可能本就不存在，或「上次删边成功、但重算那步失败」后重试）：按给定 `--id`（或推导的 `e-<source>-<target>`）发一次**幂等删除**；**若带了 `--target`（会话里现算即删除后状态），仍会补做该 target 的 `connected*` 回收**并列入 `synced`——避免部分失败重试后幽灵参考图永久残留。仅凭 `--id` 且边已不在会话时无法定位 target，跳过回收并在 stderr 告警（`synced` 为 `[]`）。

**选项**
| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--id <edgeId>` | 条件 | 边 id。给了它就不用给 source/target |
| `-s, --source <nodeKey>` | 条件 | 与 `-t/--target` 搭配，按 `(source, target)` 在会话里找真实边（不是拼 id） |
| `-t, --target <nodeKey>` | 条件 | 同上 |
| `--no-sync` | 否 | 布尔，跳过删除后对 target 节点 `connected*` 字段的回收重算 |
| `-p, --project <sessionId>` | 条件 | 覆盖当前绑定项目；未绑定时必填 |

> `--id` 与（`--source` + `--target`）二选一；两者都缺会报「用法：neowow edge delete --id <edgeId> 或 --source <s> --target <t>」。删除不做类型/成环校验。

**输出**：stdout 单行 JSON，含 `action`(=`"delete"`) / `edgeIds`（实际删除的边 id **数组**，可能多条）/ `synced`（被回收重算 `connected*` 的 target 节点 id 列表；`--no-sync`、或幂等兜底又无法定位 target 时为 `[]`）/ `results`。

## 示例
```bash
# case 1: 最简，自动推断 handle + 默认校验（text → image）
neowow edge create --source <textNodeKey> --target <imageNodeKey>
# → {"action":"create","edgeId":"e-<text>-<image>","source":"<text>","target":"<image>",
#    "sourceHandle":"text","targetHandle":"image","connected":{"connectedImageUrls":null,...,"inputTexts":["..."]},"results":[...]}

# case 2: 短别名 + 显式 handle（video → video，注意 target-handle 字面是 image）
neowow edge create -s <videoA> -t <videoB> --source-handle video --target-handle image

# case 3: 跳过类型/成环校验强连（确认无误时）
neowow edge create -s <imageNodeKey> -t <audioNodeKey> --no-validate

# case 4: 指定项目作用域建边（不依赖当前目录绑定）
neowow edge create -s <a> -t <b> -p 2070376818284032000

# case 5: 删除——按 (source,target) 在会话里找真实边（含非规范 id 边，可能多条），删除后回收重算 target 的 connected*
neowow edge delete --source <textNodeKey> --target <imageNodeKey>
# → {"action":"delete","edgeIds":["e-<text>-<image>"],"synced":["<imageNodeKey>"],"results":[...]}

# case 6: 删除——直接给 edge id
neowow edge delete --id e-<text>-<image>

# case 7: 只删边、不回收 target 的参考素材字段（少见，确知后续会自行重算时用）
neowow edge delete --source <a> --target <b> --no-sync
```
