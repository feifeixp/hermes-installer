# `neowow project` — 项目（= sessionId）的增删改查与绑定（含 `neowow folder` 文件夹）

> 入口统一写 `neowow <command>`（实际为 `node bin/neowow.mjs <command>`，安装后可直接 `neowow`）。输出契约：成功 → stdout 单行 JSON；进度/错误 → stderr（前缀 `[gen]`/`[poll]`/`[upload]`/`[login]`）；exit 0 成功 / 非 0 失败。除 `login` 外都需先登录（API Key 存 `~/.neowow/config.json` 或 `NEOWOW_API_KEY`，鉴权头是字面 `api-key`）。

`project` 管理「画布里的一个项目」。在 NeoWoW 后端里，**一个项目 == 一个 `sessionId` 字符串**（没有 `projectUuid`/`canvasId`；`nodeKey` 是节点 id，不是项目 id，别混）。本命令组覆盖 create / list / get / update / delete / clone，外加 use / unuse 两个本地绑定动作。项目可归入**画布文件夹**（顶层命令 `neowow folder`，同在 `lib/project.mjs`，见 [下文](#neowow-folder--画布文件夹)）。

作用域与绑定：`node`/`edge`/`gen` 等命令需要知道操作哪个项目，解析顺序为 `-p/--project <sessionId>` > 当前目录 `.neowow/project.json` > 报错。`neowow project use <sessionId>` 就是把 `sessionId` 写进当前目录的 `.neowow/project.json`（按 cwd 生效，不同目录互不影响），`unuse` 删除它。`create --use` 可在创建时一步绑定。前置登录见 [./login.md](./login.md)。

> 本文件即完整选项真源；速查用 `neowow project --help`（离线，不发请求）。仓库版另有 `lib/project.mjs` 源码与 api/ 端点契约，发布包不含。
> 不带子命令时（如 `neowow project`）默认走 `list`。

## 子命令
| 子命令 | 作用 |
| --- | --- |
| `neowow project create "<标题>" [flags]` | 新建项目（会话），返回新 `sessionId`，可 `--folder` 直接建进文件夹 |
| `neowow project list` / `ls` | 分页列出（**默认 v3**：根视图=文件夹+根级项目，`--folder` 下钻；`--v1` 走旧端点） |
| `neowow project get [<sessionId>]` | 拉取项目详情（含 `nodes`/`edges`） |
| `neowow project update [<sessionId>] [flags]` | 改项目元信息（标题/描述/封面） |
| `neowow project delete <sessionId>` ｜ `delete --yes` | 删除项目（不可逆；缺 sessionId 时须 `--yes` 才删绑定项目） |
| `neowow project clone [<sessionId>]` | 克隆项目，返回新 `sessionId` |
| `neowow project use <sessionId>` | 把项目绑定到当前目录（写 `.neowow/project.json`） |
| `neowow project unuse` | 解绑当前目录的默认项目 |
| `neowow folder create/delete/rename/move` | 画布文件夹管理（顶层命令，见 [下文](#neowow-folder--画布文件夹)） |

> 别名：`ls` == `list`。下文涉及的 flag 短/长别名（来自 `lib/project.mjs` 的 `parseArgs` aliases）：`-t`=`--title`，`-d`=`--desc`（亦可写 `--description`），`-n`=`--page-num`=`--pageNum`，`-s`=`--page-size`=`--pageSize`，`--cover`=`--coverImageUrl`，`--folder`=`--folderId`，`--sort-field`=`--sortField`，`--sort-order`=`--sortOrder`。

> ⚠️ **并发注意**：网页端开着同一画布时先别用 CLI 动它——网页端刷新会用旧快照全量覆盖后端、物理删除 CLI 写入（详见 [../SKILL.md](../SKILL.md) 核心模型「并发约束」）。

---

### `neowow project create "<标题>" [flags]`
新建一个项目（POST `/agent/story-canvas/session/create`），返回后端分配的 `sessionId` 字符串。

**位置参数**
- **`<标题>`**（必填，可改用 `-t`）：项目标题。缺标题（既无位置参数也无 `-t`）报错。

**选项**
| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `-t, --title <s>` | 条件 | 标题；与位置参数二选一（位置参数优先级低于 `-t`，源码取 `title \|\| _[0]`，但有 `-t` 即用之）。 |
| `-d, --desc <s>` | 否 | 描述；`--description` 是同义别名。默认空字符串 `''`。 |
| `--folder <folderId>` | 否 | 直接建进指定文件夹（请求体带 `folderId`）；别名 `--folderId`。文件夹 id 来自 `neowow folder create` 或 `project list` 的 `folders[].folderId`。 |
| `--use` | 否 | 创建后立即把新 `sessionId` 绑定到当前目录 `.neowow/project.json`。布尔 flag，放末尾或写 `--use=true`。 |

**输出**：stdout 单行 JSON，含 `action`(=`create`) / `sessionId`(新建的字符串) / `title` / `folderId`(建进的文件夹，未指定为 `null`) / `bound`(布尔，是否已绑定)。

---

### `neowow project list [flags]`（别名 `ls`）
分页列出（**默认 v3**：GET `/agent/story-canvas/session/list/v3`，与网页端主列表同源）。v3 的两级视图：

- **根视图**（不带 `--folder`）：返回**文件夹 + 根级项目**混合列表——**已归入文件夹的项目被排除**，要看它们必须用 `--folder <folderId>` 下钻。
- **文件夹视图**（`--folder <folderId>`）：只返回该文件夹内的项目。

后端用 `itemType` 区分列表项：`0`=文件夹、`1`=项目；CLI 已按它拆成 `folders` 与 `projects` 两个数组。

**选项**
| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `-n, --page-num <n>` | 否 | 页码；别名 `--pageNum`/`--page-num`。默认 `1`。 |
| `-s, --page-size <n>` | 否 | 每页条数；别名 `--pageSize`/`--page-size`。默认 `20`。 |
| `--folder <folderId>` | 否 | 下钻查看该文件夹内的项目；别名 `--folderId`。不传=根视图。 |
| `-t, --title <s>` | 否 | 标题**模糊**过滤（后端 `title` 子串查询）。 |
| `--project-type <0\|1>` | 否 | 项目类型过滤：`0`=个人（非协作）/ `1`=协作。不传查全部。别名 `--projectType`。 |
| `--sort-field <f>` | 否 | 排序字段：`createTime` \| `updateTime`。默认 `updateTime`。别名 `--sortField`。 |
| `--sort-order <o>` | 否 | 排序方向：`asc` \| `desc`。默认 `desc`。别名 `--sortOrder`。 |
| `--v1` | 否 | 布尔逃生口：走旧端点 GET `/agent/story-canvas/session/list`（`queryType` 语义），配 `--queryType <1\|2\|3>`（`1`=自己的非协作 / `2`=自己创建的协作 / `3`=被邀请，默认 `1`）。 |

**输出**（默认 v3）：stdout 单行 JSON，含 `scope`(=`root` 或 `folder=<folderId>`) / `count`(总数，取响应壳 `totalCount`，缺则用本页条数) / `pageIndex` / `pageSize`(均来自响应壳) / `folders`(文件夹数组，项含 `folderId`/`name`/`projectCount`/`createTime`/`updateTime`) / `projects`(项目数组，**后端原始项**，含 `sessionId`/`title`/`description`/`imageUrl`/`projectType`/`folderId`/`createTime`/`updateTime` 等)。

**输出**（`--v1`）：`scope`(=`v1 queryType=N`) / `count` / `pageIndex` / `pageSize` / `projects`（无 `folders`）。

> 分页 meta 取自响应壳（`totalCount`/`pageIndex`/`pageSize`），不是 `data` 内层；直接打后端时按原始字段解析，仓库版 api 契约文档（发布包不含）。

---

### `neowow project get [<sessionId>]`
拉取项目详情（GET `/agent/story-canvas/session/{sessionId}`），返回顶层含 `nodes`/`edges` 的完整画布数据。

**位置参数**
- **`<sessionId>`**（条件必填）：省略时回落到当前目录绑定的项目；都没有则报错 `SESSION_NOT_BOUND`。

**选项**
| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `--share-token <t>` | 否 | 分享 token，作为 query `?token=` 拼到请求（访问他人分享的画布时用）。 |

**输出**：stdout 单行 JSON，为后端会话详情原样透传，顶层含 `sessionId` / `title` / `description` / `imageUrl` / `createTime` / `updateTime` / `nodes` / `edges`。

---

### `neowow project update [<sessionId>] [flags]`
改项目元信息（PUT `/agent/story-canvas/session/update`）。只发送显式给出的字段。

**位置参数**
- **`<sessionId>`**（条件必填）：省略时用 `--session` 或当前目录绑定；都没有则报错。

**选项**
| 选项 | 必填 | 说明 |
| --- | --- | --- |
| `-t, --title <s>` | 否 | 新标题（仅在给出时写入请求体 `title`）。 |
| `-d, --desc <s>` | 否 | 新描述（写入 `description`）；别名 `--description`。 |
| `--cover <url>` | 否 | 封面图地址；别名 `--coverImageUrl`，写入请求体 `coverImageUrl`。 |
| `--session <id>` | 否 | 显式指定 sessionId（位置参数缺省时的回落项之一）。 |

**输出**：stdout 单行 JSON，含 `action`(=`update`) / `sessionId` / `updated`(本次实际更新的字段名数组，如 `["title","description"]`)。

---

### `neowow project delete <sessionId>` ｜ `delete --yes`
删除项目（DELETE `/agent/story-canvas/session/{sessionId}`）。**不可逆——整个画布（全部节点/连线/引用）一并删除**。

**位置参数 / 选项**
- **`<sessionId>`**：要删的项目。**与 get/update 不同，delete 默认不回落到绑定项目**——防止空变量（`project delete ""`）静默删库。
- **`--yes`**：无 `<sessionId>` 时，明确确认「删除当前目录绑定的项目」。仅此一种情况才走绑定回落。

三种情形：给了 `<sessionId>` → 直接删（`target:"explicit"`）；没给但有绑定且带 `--yes` → 删绑定项目（`target:"bound"`）；没给、没 `--yes` → **拒绝并报错**（有绑定时提示显式指定或加 `--yes`；无绑定时报用法错误，exit 2）。

**输出**：stdout 单行 JSON，含 `action`(=`delete`) / `sessionId` / `deleted`(=`true`) / `target`(`"explicit"`|`"bound"`)。

> 删除项目不会自动 `unuse`：若刚删的就是当前目录绑定的项目，记得再跑 `neowow project unuse`。

---

### `neowow project clone [<sessionId>]`
克隆项目（POST `/agent/story-canvas/session/clone`），返回新 `sessionId`。

**位置参数**
- **`<sessionId>`**（条件必填）：要克隆的源项目；省略时用当前目录绑定。

**输出**：stdout 单行 JSON，含 `action`(=`clone`) / `from`(源 sessionId) / `sessionId`(新建的 sessionId)。

---

### `neowow project use <sessionId>`
把 `sessionId` 写进当前目录 `.neowow/project.json`，作为 `node`/`edge`/`gen` 的默认项目。纯本地操作，不发请求。

**位置参数**
- **`<sessionId>`**（必填）：要绑定的项目 id。缺失报错 `用法：neowow project use <sessionId>`。

**输出**：stdout 单行 JSON，含 `action`(=`bind`) / `sessionId` / `path`(写入的 `.neowow/project.json` 绝对路径)。

---

### `neowow project unuse`
删除当前目录的 `.neowow/project.json` 绑定。纯本地操作。

**输出**：stdout 单行 JSON，含 `action`(=`unbind`) / `unbound`(=`true`) / `path`(绑定文件路径) / `removed`(布尔，文件原本是否存在)。

---

## `neowow folder` — 画布文件夹

顶层命令（不是 `project folder`），实现同在 `lib/project.mjs`。文件夹只有一层组织语义：项目要么在根目录、要么在某个文件夹里；`project list` 根视图会排除文件夹内项目，靠 `--folder <folderId>` 下钻。仓库版 api 契约文档（发布包不含） §文件夹。

| 子命令 | 作用 | 端点 |
| --- | --- | --- |
| `neowow folder create "<名称>"` | 新建文件夹，返回 `folderId` | POST `/agent/story-canvas/folder/create` |
| `neowow folder delete <folderId>`（别名 `rm`） | 删除文件夹 | DELETE `/agent/story-canvas/folder/{folderId}` |
| `neowow folder rename <folderId> "<新名称>"` | 重命名 | PUT `/agent/story-canvas/folder/rename` |
| `neowow folder move --to <folderId\|root> <sessionId...>` | 批量移动项目进/出文件夹 | POST `/agent/story-canvas/folder/move` |

### `neowow folder create "<名称>"`
**位置参数**：`<名称>`（必填，亦可 `--name`）。
**输出**：`action`(=`create`) / `folderId`(后端分配的文件夹业务 id) / `folderName`。

### `neowow folder delete <folderId>`
**位置参数**：`<folderId>`（必填）。别名 `rm`。
**输出**：`action`(=`delete`) / `folderId` / `deleted`(=`true`)。

### `neowow folder rename <folderId> "<新名称>"`
**位置参数**：`<folderId>` 与 `<新名称>`（都必填，按顺序取）。
**输出**：`action`(=`rename`) / `folderId` / `folderName`(新名称)。

### `neowow folder move --to <folderId|root> <sessionId...>`
把一个或多个项目移动到目标文件夹；`--to root` **或省略 `--to`** = 移回根目录（请求体 `folderId:null`）。请求体为 `{ sessionIds, folderId }`。
**位置参数**：`<sessionId...>`（至少一个）。
**输出**：`action`(=`move`) / `sessionIds`(数组) / `folderId`(目标文件夹 id，移回根目录时为 `null`)。

## 示例
```bash
# case 1: 最简创建（标题用位置参数）
neowow project create "CLI 测试画布"
# → {"action":"create","sessionId":"2070376818284032000","title":"CLI 测试画布","bound":false}

# case 2: 创建并立即绑定到当前目录（写 .neowow/project.json）
neowow project create "CLI 测试画布" -d "用于联调的临时画布" --use
# → {"action":"create","sessionId":"2070376818284032000","title":"CLI 测试画布","bound":true}

# case 3: 列表（默认 v3 根视图 = 文件夹 + 根级项目；文件夹内项目被排除）
neowow project list -n 1 -s 5
# → {"scope":"root","count":12,"pageIndex":1,"pageSize":5,
#    "folders":[{"folderId":"f_...","name":"分镜","projectCount":3,...}],"projects":[...]}

# case 3b: 下钻某文件夹 / 按标题模糊过滤 / 按创建时间升序
neowow project list --folder f_xxx                       # → {"scope":"folder=f_xxx",...}
neowow project list --title 短剧 --sort-field createTime --sort-order asc

# case 3c: 旧端点逃生口（queryType 语义）
neowow project list --v1 --queryType 3
# → {"scope":"v1 queryType=3","count":12,"pageIndex":1,"pageSize":20,"projects":[...]}

# case 4: 用 jq 从列表里挑出第一个 sessionId 直接绑定（管道）
sid=$(neowow project list -s 1 | jq -r '.projects[0].sessionId')
neowow project use "$sid"          # ✅ 之后 node/edge/gen 无需再 -p
# → {"action":"bind","sessionId":"2070...","path":"/abs/cwd/.neowow/project.json"}

# case 5: 看绑定项目的详情（省略 sessionId → 用绑定的）
neowow project get | jq '{title, nodes: (.nodes|length)}'

# case 6: 临时覆盖绑定，查另一个项目的详情（不改 .neowow/project.json）
neowow project get 2070376818284032000

# case 7: 只改标题与封面
neowow project update -t "新名字" --cover https://cdn.example.com/c.png
# → {"action":"update","sessionId":"2070...","updated":["title","coverImageUrl"]}

# case 8: 克隆当前绑定项目，得到一份副本
neowow project clone | jq -r '.sessionId'

# case 9: 删除指定项目后解绑（删除不会自动 unuse）
neowow project delete 2070376818284032000
neowow project unuse
# → {"action":"unbind","unbound":true,"path":".../.neowow/project.json","removed":true}

# case 10: 文件夹全流程——建文件夹 → 建项目进文件夹 → 移动 → 重命名 → 移回根目录
fid=$(neowow folder create "分镜素材" | jq -r .folderId)
neowow project create "第 1 集" --folder "$fid"           # 直接建进文件夹
neowow folder move --to "$fid" 2070111 2070222            # 批量移入
neowow folder rename "$fid" "分镜素材·终版"
neowow folder move --to root 2070111                      # 移回根目录（folderId:null）
neowow project list --folder "$fid"                       # 下钻看文件夹内项目
```

> 紧接着的常见链路：`neowow project use` 绑定后即可 `neowow node create -t image ...` 建节点、`neowow gen image --node <nodeKey> --wait` 出图。节点/连线见 [./node.md](./node.md) 与 [./edge.md](./edge.md)，生成见 [./gen.md](./gen.md)，登录见 [./login.md](./login.md)。
