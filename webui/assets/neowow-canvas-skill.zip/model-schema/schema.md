# 模型 schema 字段

模型发现仓库版 api 契约文档（发布包不含）。本页说明返回的模型对象里，哪些字段决定提交时各参数的合法取值。

## 图片模型（`models/by-scenario`，CLI 默认 `scenarioType='1'` 全量；画布 UI 用 `'2'` 子集，提交不受场景限制）

`useImageGeneration.js`

| 字段 | 用途 / 映射 |
| --- | --- |
| `model_name` | 提交时的 `modelName`；也写进节点 `data.model` |
| `model_display_name` | 展示名；写进节点 `data.modelName`（展示用） |
| `supported_aspect_ratios: string[]` | 合法 `aspectRatio`，含 `'auto'` |
| `supported_sizes: string[]` | 合法 `size`（如 `'1K'/'2K'/'4K'`） |
| `quality: string[]` | 合法 `quality`；**非空时 `gen image` 的 `--quality` 必传**（镜像网页端：有质量档模型提交体必带 quality），缺传/传错 CLI 提交前报错 |
| `image_count_options: [min, max]` | 合法 `numImages` 区间（注意提交时 `numImages` 为字符串） |
| `size_pricing_config` | **计价矩阵**（后端可能给 JSON 字符串，slim 投影已解析成对象）。key 是 `quality_size` 组合（如 `medium_2k`）或纯 `size`（如 `2k`），value 是单张积分。**单价匹配顺序：`quality_size` 组合键 > `size` 键 > `points_cost_per_image` 兜底**（网页端 `useImageGeneration.js` 同款链） |
| `points_cost_per_image` | 兜底基础价——仅在计价矩阵无匹配时生效，**不能直接当报价** |
| `points_cost_per_reference_image` / `free_reference_image_count` / `reference_image_billing_mode` | 参考图超额费：超出免费张数后每张加价（`billing_mode=2` 时不论超几张只加一次）。总价 = 张数 × (单张 + 超额费)，`gen image --dry-run` 的 `estimate` 已按此算好 |

> ⚠️ 命名易混：节点 `data.model` 存的是 `model_name`（机器名），`data.modelName` 存的是 `model_display_name`（展示名）；而**提交 `generate-image` 时的 `modelName` 字段填的是机器名 `model_name`**。以本表为准。CLI（`neowow gen image`）回填同此映射：`modelName` 写显示名（by-scenario 查表 best-effort，查不到用机器名兜底）。

## 视频模型（`models/cascading/v2`，画布 `requestType='2'`）

**dev 实测结构**：`data[]` 每项是一个模型对象。⚠️ **视频模型的 id 字段是 `value`，不是 `model_name`**（`model_name`/`model_display_name` 是图片模型的字段）。

| 字段 | 用途 |
| --- | --- |
| `value` | **模型 id**——提交 `generate-video` 的 `modelName` 用它（实测如 `doubao-seedance-1-0-pro-fast-251015`、`neo-video-2-0`、`kling-v3`、`veo-3.1-fast-generate-001`） |
| `name` | 展示名（如 `Seedance 1.0 Fast`）——节点 `data.modelName` 回填用它（CLI 按 `value` 查级联树 best-effort，查不到用机器名兜底） |
| `provider` | 供应商（DOUBAO / MiniMax / …） |
| `isUniversalModel` | `true` → 全能模型。⚠️ 但全能模式的时长/计价/`supportAudioGeneration` 等**专属配置不在级联列表里**——模型发现用下节的 universal 独立端点；提交体是**顶层扁平字段**（不是嵌套 `references`，仓库版 api 契约文档（发布包不含）） |
| `membershipRequired` + `allowedMembershipLevelCodes` | 是否需会员及等级（不满足会提交失败） |
| `durationRange:{min,max,step}` | 合法 `duration` 区间（如 4-15、3-10） |
| `supportAudio` | **三态**，决定提交 `generateAudio` 字段：`2`=必开（恒 `true`，关不掉）/ `1`=开关（可 `true/false`）/ `0` 或缺失=不带该字段 |
| `supportFirstLastFrame` / `supportReferenceToVideo` / `supportAudioUpload` | 能力开关（`supportAudioUpload`=支持单个参考音频 `audioUrl`） |
| `supportDraft` | `true` → 普通模式有**草稿开关**（提交 `draft:true`，分辨率固定最后一档；CLI `gen video --draft`）。缺失/false 时开关不出现 |
| （派生）`draftModel` / `formalModel` | **样片模型**：`value` 以 `-draft` 结尾或 `name` 含「样片」（如 `doubao-seedance-2-5-260628-draft`「Seedance 2.5 (样片模式)」）。选它生成的都是草稿（不用传 `draft`），`formalModel`=去掉后缀的正式模型 value（转正式新节点用它）。CLI `models video` 按此派生，后端原样数据无这两个键 |
| `generationTypes:[{ value, resolutions:[{ value, aspectRatios:[{value}] }] }]` | **级联**：类型 → 分辨率 → 长宽比 |

- `generationTypes[].value` ∈ `TEXT_TO_VIDEO | IMAGE_TO_VIDEO | REFERENCE_TO_VIDEO`（universal 模型另含 UNIVERSAL）。
- `resolutions[].value` 如 `720p / 1080p / 4K`；`aspectRatios[].value` 如 `16:9` —— **很多模型只给 `auto`**（如 Seedance/Kling/Vidu/Wan/Hailuo），此时 `aspectRatio` 传 `"auto"`；Veo、Seedance 2.0 才给具体比例。
- **提交要点**：`modelName=模型.value`；`resolution` 取该 `generationType` 下的 `resolutions[].value`；`aspectRatio` 取对应 `aspectRatios[].value`（只有 `auto` 就传 `"auto"`）；`duration` 落在 `durationRange` 内。
- 挑模型：优先 `isUniversalModel=false` 且 `membershipRequired=false` 的（提交体最简单），实测 `doubao-seedance-1-0-pro-fast-251015` 可直接 IMAGE_TO_VIDEO（720p / auto / dur 3-10）。

## 全能（universal）视频模型（`models/universal`，画布 `requestType='2'`）

全能模式的模型发现走**独立端点**（`creation.js` `getUniversalVideoModels`，网页端 universal tab 同源）：

```
GET /agent/user/video/models/universal[/byLogin]?requestType=2
```

- CLI：`neowow models video --universal`（见 [commands/models.md](../commands/models.md)）。
- 返回含 universal **专属**的时长范围/计价/`supportAudioGeneration` 配置——这些在级联列表（`cascading/v2`）里没有，所以**从级联列表挑 `isUniversalModel=true` 不等价**。
- 模型 id 同样在 `value`（如 `neo-video-2-0` / `neo-video-2-0-fast`），传给 `gen video --universal --model`。

## 音频

音色（`soundId`）、情感枚举等见 [node-types/audio.md](../node-types/audio.md) 与 仓库版 api 契约文档（发布包不含）。音色列表端点 `GET /agent/v1/sound/list`（CLI `neowow models voice`，取每项 `.id`）见 [commands/models.md](../commands/models.md)。seed-audio v2 引擎（`generate-audio-v2`，模型固定 `seed-audio-1.0`）不需要音色 id，仓库版 api 契约文档（发布包不含）。
